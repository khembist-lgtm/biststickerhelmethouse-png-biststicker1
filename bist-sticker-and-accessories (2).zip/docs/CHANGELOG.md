# Changelog

## [1.1.0] - 2026-08-10 - Centralized Firestore Database Architecture Fix

### Critical Fixes
- **Root Cause Resolution**: Fixed product restore across different browsers by migrating data source from local browser storage / server file to centralized Cloud Firebase Firestore.
- **Single Source of Truth**: Connected both Storefront and Admin panel to Google Firebase Firestore (`ai-studio-biststickerandac-750edb13-9cba-48ca-8aa4-d83ba641c7aa`).
- **Atomic Operations**: Product, Category, Hero Slide, and Settings mutations now execute direct atomic `setDoc` and `deleteDoc` calls to Firestore.
- **Cross-Browser Real-Time Sync**: Integrated `onSnapshot` listeners to broadcast deletions, additions, and edits in real time to all connected browsers.
- **Removed Fallback Re-Seeding**: Removed automatic restoration of demo products when products array is empty.
- **Security Rules Updated**: Configured Firestore security rules for persistent CRUD permissions on catalog collections.
