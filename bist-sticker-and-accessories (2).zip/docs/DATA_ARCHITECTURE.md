# Centralized Data Architecture Specification

## Overview & Source of Truth

The application uses **Google Firebase Firestore** as its **SINGLE CENTRALIZED PRODUCTION SOURCE OF TRUTH**. All customer storefront views and admin management panels across all devices, browsers, and sessions operate on the same Firestore database instance.

### Primary Database Instance
- **Service**: Google Cloud Firebase Firestore
- **Database ID**: `ai-studio-biststickerandac-750edb13-9cba-48ca-8aa4-d83ba641c7aa`
- **Firebase Project ID**: `peak-thought-tds98`
- **Region**: `asia-southeast1`

---

## Firestore Collections Schema

1. **`products` Collection** (`/products/{productId}`)
   - **Fields**: `id` (string), `name` (string), `categoryId` (string), `category` (string), `price` (number), `originalPrice` (number), `description` (string), `images` (array), `features` (array), `isFeatured` (boolean), `isNew` (boolean), `isBestSeller` (boolean), `stock` (number), `sku` (string)
   - **Delete Behavior**: When a product is deleted in Admin, `deleteDoc(doc(db, 'products', productId))` is executed directly on Firestore. The document is permanently removed.
   - **No Auto-Restoration**: An empty `products` collection yields an empty list. Mock/demo products are NEVER automatically re-inserted or restored on page load.

2. **`categories` Collection** (`/categories/{categoryId}`)
   - Stores catalog categories (`stickers`, `helmets`, `accessories`, etc.)

3. **`heroSlides` Collection** (`/heroSlides/{slideId}`)
   - Stores store frontpage banner hero slider content.

4. **`settings` Collection** (`/settings/site`)
   - Stores shop metadata, phone numbers, location address, social links.

5. **`orders` Collection** (`/orders/{orderId}`)
   - Stores incoming customer orders submitted through checkout.

---

## Real-Time Synchronization Across Browsers

The app uses Firestore `onSnapshot` listeners (`subscribeToStoreChanges` in `src/lib/firestoreSync.ts`).
When **Browser A** performs a `delete`, `create`, or `update` on any Firestore document:
1. Firestore document is immediately updated/deleted in the database.
2. Firestore pushes real-time document delta events to **Browser B**, **Mobile Phone**, **Incognito windows**, and all other active sessions.
3. React state is updated automatically via live subscription.

---

## Deployment Data Safety Rules

1. **Source Code vs User Data**: Frontend builds compile application logic only. User products and uploaded data live completely outside build outputs in Firestore.
2. **Re-deploying or republishing** the applet will NEVER clear, reset, or overwrite Firestore user data.
3. **No Fallback Seeding**: Mock data is only seeded during explicit first-time database initialization (`_meta_/initialized` document check). Once initialized, deleted items remain deleted permanently.
