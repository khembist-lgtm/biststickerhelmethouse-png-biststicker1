import React from 'react';
import { ShoppingCart, MessageCircle, Eye, Heart } from 'lucide-react';
import { Product, SiteSettings } from '../types';
import { formatNPR, formatWhatsAppUrl, generateProductWhatsAppMessage } from '../lib/api';

interface ProductCardProps {
  product: Product;
  settings: SiteSettings;
  onAddToCart: (product: Product) => void;
  onViewDetails: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  settings,
  onAddToCart,
  onViewDetails,
  onToggleWishlist,
  isWishlisted,
}) => {
  const primaryImage = product.images?.[0] || 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=600';

  const whatsappMessage = generateProductWhatsAppMessage(settings.shopName, product);
  const whatsappUrl = formatWhatsAppUrl(settings.whatsappNumber, whatsappMessage);

  return (
    <div className="group bg-[#f8f7f4] border-t-2 border-[#1a1a1a] pt-4 pb-3 flex flex-col justify-between transition-all duration-300 relative">
      {/* Image & Badges Overlay */}
      <div className="relative h-52 sm:h-60 bg-[#e5e4e1] overflow-hidden mb-3">
        <img
          src={primaryImage}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out mix-blend-multiply opacity-95"
          loading="lazy"
        />

        {/* Discount Badge */}
        {product.discount && product.discount > 0 ? (
          <span className="absolute top-2 left-2 bg-[#ff3300] text-white text-[10px] font-black px-2 py-0.5 uppercase font-mono-meta tracking-wider">
            -{product.discount}%
          </span>
        ) : null}

        {/* Wishlist Button Overlay */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-2 right-2 p-2 transition-all duration-200 shadow-sm ${
            isWishlisted
              ? 'bg-[#ff3300] text-white'
              : 'bg-[#f8f7f4]/90 hover:bg-[#1a1a1a] text-[#1a1a1a] hover:text-white border border-[#1a1a1a]/10'
          }`}
          title={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
        >
          <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Product Information */}
      <div className="space-y-3 flex-1 flex flex-col justify-between">
        <div>
          {/* Category & Stock */}
          <div className="flex items-center justify-between font-mono-meta text-[10px] uppercase tracking-wider text-[#1a1a1a]/60 mb-1">
            <span>{product.category}</span>
            <span className={product.stockStatus === 'In Stock' ? 'text-emerald-700 font-bold' : 'text-amber-700 font-bold'}>
              {product.stockStatus}
            </span>
          </div>

          {/* Product Title */}
          <h3
            onClick={() => onViewDetails(product)}
            className="text-sm font-black text-[#1a1a1a] group-hover:text-[#ff3300] transition-colors duration-200 line-clamp-2 cursor-pointer font-sans uppercase tracking-wide leading-snug"
          >
            {product.name}
          </h3>

          {/* Price Tag */}
          <div className="mt-2 flex items-baseline gap-2 font-mono-meta">
            <span className="text-base sm:text-lg font-bold text-[#1a1a1a]">
              {formatNPR(product.price)}
            </span>
            {product.oldPrice && product.oldPrice > product.price && (
              <span className="text-xs text-[#1a1a1a]/40 line-through">
                {formatNPR(product.oldPrice)}
              </span>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-2 border-t border-[#1a1a1a]/10">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onViewDetails(product)}
              className="flex items-center justify-center gap-1 bg-[#1a1a1a]/5 hover:bg-[#1a1a1a] hover:text-white text-[#1a1a1a] text-[10px] font-black uppercase tracking-wider py-2 transition-colors border border-[#1a1a1a]/10"
            >
              <Eye className="w-3 h-3" />
              <span>Details</span>
            </button>

            <button
              onClick={() => onAddToCart(product)}
              className="flex items-center justify-center gap-1 bg-[#1a1a1a] text-white hover:bg-black text-[10px] font-black uppercase tracking-wider py-2 transition-colors"
            >
              <ShoppingCart className="w-3 h-3 text-[#ff3300]" />
              <span>Add Cart</span>
            </button>
          </div>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center justify-center gap-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-[10px] font-black uppercase tracking-wider py-2 transition-colors"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Order on WhatsApp</span>
          </a>
        </div>
      </div>
    </div>
  );
};

