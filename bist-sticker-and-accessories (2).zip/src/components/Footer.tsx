import React from 'react';
import { Phone, MapPin, MessageCircle } from 'lucide-react';
import { SiteSettings } from '../types';
import { formatWhatsAppUrl } from '../lib/api';

interface FooterProps {
  settings: SiteSettings;
  onSelectCategory: (cat: string) => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ settings, onSelectCategory, onOpenAdmin }) => {
  const directWhatsAppUrl = formatWhatsAppUrl(
    settings.whatsappNumber,
    `Hello ${settings.shopName}, I noticed your website and would like to order.`
  );

  const handleNavClick = (targetId: string, categoryName?: string) => {
    if (categoryName) {
      onSelectCategory(categoryName);
      const el = document.getElementById('featured-products');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else {
      const el = document.getElementById(targetId);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-[#1a1a1a] text-[#f8f7f4] border-t-2 border-[#f8f7f4]/20 text-xs relative overflow-hidden">
      <div className="max-w-[1600px] mx-auto px-6 sm:px-10 py-12 sm:py-16 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              {settings.logoUrl && settings.logoUrl.trim() !== '' ? (
                <img
                  src={settings.logoUrl}
                  alt={settings.shopName}
                  className="h-10 w-auto object-contain"
                />
              ) : (
                <div>
                  <span className="block text-2xl font-black tracking-tighter text-[#f8f7f4] uppercase font-sans leading-none">
                    Bist<span className="text-[#ff3300]">.</span>
                  </span>
                  <span className="block font-mono-meta text-[10px] font-bold text-[#ff3300] tracking-widest uppercase mt-1">
                    Sticker & Accessories
                  </span>
                </div>
              )}
            </div>

            <p className="text-[#f8f7f4]/70 text-xs leading-relaxed font-sans">
              "{settings.tagline}" — {settings.footerText}
            </p>

            {/* Social Links */}
            <div className="flex items-center gap-2 pt-2 font-mono-meta">
              {settings.facebookUrl && (
                <a
                  href={settings.facebookUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 bg-[#242424] border border-[#f8f7f4]/20 flex items-center justify-center text-[#f8f7f4] hover:bg-[#ff3300] hover:text-white transition-colors text-[10px] font-bold"
                  title="Facebook"
                >
                  FB
                </a>
              )}
              {settings.tiktokUrl && (
                <a
                  href={settings.tiktokUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 bg-[#242424] border border-[#f8f7f4]/20 flex items-center justify-center text-[#f8f7f4] hover:bg-[#ff3300] hover:text-white transition-colors text-[10px] font-bold"
                  title="TikTok"
                >
                  TT
                </a>
              )}
              {settings.instagramUrl && (
                <a
                  href={settings.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 bg-[#242424] border border-[#f8f7f4]/20 flex items-center justify-center text-[#f8f7f4] hover:bg-[#ff3300] hover:text-white transition-colors text-[10px] font-bold"
                  title="Instagram"
                >
                  IG
                </a>
              )}
              <a
                href={directWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 bg-[#ff3300] text-white flex items-center justify-center hover:bg-[#d92b00] transition-colors"
                title="WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3 font-mono-meta">
            <h4 className="text-[11px] font-bold uppercase text-[#f8f7f4] tracking-[0.2em] border-b border-[#f8f7f4]/20 pb-2">
              NAVIGATION
            </h4>
            <ul className="space-y-2 text-[11px] uppercase">
              <li>
                <button
                  onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                  className="text-[#f8f7f4]/70 hover:text-[#ff3300] transition-colors"
                >
                  01 // Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('featured-products')}
                  className="text-[#f8f7f4]/70 hover:text-[#ff3300] transition-colors"
                >
                  02 // Catalogue
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('categories')}
                  className="text-[#f8f7f4]/70 hover:text-[#ff3300] transition-colors"
                >
                  03 // Categories
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('about')}
                  className="text-[#f8f7f4]/70 hover:text-[#ff3300] transition-colors"
                >
                  04 // Philosophy
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('services')}
                  className="text-[#f8f7f4]/70 hover:text-[#ff3300] transition-colors"
                >
                  05 // Services
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('contact')}
                  className="text-[#f8f7f4]/70 hover:text-[#ff3300] transition-colors"
                >
                  06 // Studio Location
                </button>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div className="space-y-3 font-mono-meta">
            <h4 className="text-[11px] font-bold uppercase text-[#f8f7f4] tracking-[0.2em] border-b border-[#f8f7f4]/20 pb-2">
              SECTIONS
            </h4>
            <ul className="space-y-2 text-[11px] uppercase text-[#f8f7f4]/70">
              {[
                'Bike Stickers',
                'Helmet',
                'Bike Accessories',
                'Number Plates',
                'PPF',
                'Keyrings',
                'Neon Sign Board',
                'Bus & Truck Stickers',
              ].map((cat) => (
                <li key={cat}>
                  <button
                    onClick={() => handleNavClick('', cat)}
                    className="hover:text-[#ff3300] transition-colors text-left"
                  >
                    {cat}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Details */}
          <div className="space-y-3 font-mono-meta">
            <h4 className="text-[11px] font-bold uppercase text-[#f8f7f4] tracking-[0.2em] border-b border-[#f8f7f4]/20 pb-2">
              CONTACT
            </h4>
            <ul className="space-y-3 text-[11px]">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#ff3300] shrink-0 mt-0.5" />
                <span className="text-[#f8f7f4]/80">{settings.address}, Nepal</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#ff3300] shrink-0" />
                <a href={`tel:${settings.phone}`} className="hover:text-[#ff3300] transition text-[#f8f7f4]">
                  {settings.phone}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <a
                  href={directWhatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-emerald-300 transition text-emerald-400 font-bold"
                >
                  WhatsApp: {settings.whatsappDisplay}
                </a>
              </li>
            </ul>

            <div className="pt-2">
              <button
                onClick={onOpenAdmin}
                className="text-[10px] bg-[#ff3300] text-white px-3 py-1.5 font-bold uppercase tracking-wider hover:bg-[#d92b00] transition-colors"
              >
                Website Admin Panel
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-[#f8f7f4]/15 flex flex-col sm:flex-row items-center justify-between gap-3 text-[10px] font-mono-meta uppercase text-[#f8f7f4]/50">
          <p>© {new Date().getFullYear()} Bist Sticker and Accessories. All rights reserved.</p>
          <p className="text-[#f8f7f4]/70">
            Kailali, Far-Western Nepal
          </p>
        </div>
      </div>
    </footer>
  );
};

