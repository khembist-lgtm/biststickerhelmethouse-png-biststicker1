import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, MessageCircle, ArrowRight } from 'lucide-react';
import { HeroSlide, SiteSettings } from '../types';
import { formatWhatsAppUrl } from '../lib/api';

interface HeroSliderProps {
  slides: HeroSlide[];
  settings: SiteSettings;
}

export const HeroSlider: React.FC<HeroSliderProps> = ({ slides, settings }) => {
  const activeSlides = slides.filter((s) => s.isActive).sort((a, b) => a.order - b.order);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (activeSlides.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % activeSlides.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [activeSlides.length]);

  if (activeSlides.length === 0) return null;

  const currentSlide = activeSlides[currentIndex] || activeSlides[0];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? activeSlides.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % activeSlides.length);
  };

  const directWhatsAppUrl = formatWhatsAppUrl(
    settings.whatsappNumber,
    `Hello ${settings.shopName}, I noticed your store showcase and would like to inquire about bike custom stickers, helmets & PPF.`
  );

  return (
    <div className="relative w-full bg-[#f8f7f4] text-[#1a1a1a] border-b border-[#1a1a1a]/10 overflow-hidden">
      <div className="max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-12 min-h-[640px]">
        {/* Main Content Area */}
        <div className="lg:col-span-8 p-6 sm:p-10 lg:p-14 flex flex-col justify-between relative">
          <div>
            {/* Meta Eyebrow */}
            <div className="font-mono-meta text-[11px] uppercase tracking-[0.2em] text-[#1a1a1a]/60 mb-4 sm:mb-6 flex items-center justify-between">
              <span>{currentSlide.smallText || 'LUXURY PERFORMANCE BRANDING'}</span>
              <span className="text-[10px] text-[#1a1a1a]/40 font-mono-meta">0{currentIndex + 1} / 0{activeSlides.length}</span>
            </div>

            {/* Giant Main Display Title */}
            <h1 className="text-4xl sm:text-6xl lg:text-7xl xl:text-8xl font-black tracking-tighter uppercase leading-[0.88] text-[#1a1a1a] mb-6 font-sans">
              DEFINING <br />
              THE <span className="font-serif-italic capitalize text-[#1a1a1a]">Elite</span> RIDE<span className="text-[#ff3300]">.</span>
            </h1>

            <p className="text-sm sm:text-base text-[#1a1a1a]/70 max-w-xl font-medium leading-relaxed mb-8">
              {currentSlide.description || 'Precision-engineered vinyl wraps, certified helmets, PPF body shields & custom sticker solutions in Attariya, Nepal.'}
            </p>

            {/* Product Feature Cards Grid (3 Columns) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 border-t border-[#1a1a1a]/15">
              <div className="space-y-2 border-t-2 border-[#1a1a1a] pt-3">
                <h3 className="text-xs font-black uppercase tracking-wider text-[#1a1a1a]">Helmet Systems</h3>
                <p className="text-[11px] text-[#1a1a1a]/60 leading-snug">Certified safety meets individual expression. Custom wraps for riders.</p>
                <a href="#featured-products" className="inline-block border-b border-[#1a1a1a] pb-0.5 text-[10px] font-black uppercase tracking-wider text-[#1a1a1a] hover:text-[#ff3300] hover:border-[#ff3300] transition-colors">
                  Explore Collection
                </a>
              </div>

              <div className="space-y-2 border-t-2 border-[#1a1a1a] pt-3">
                <h3 className="text-xs font-black uppercase tracking-wider text-[#1a1a1a]">Graphic Kits</h3>
                <p className="text-[11px] text-[#1a1a1a]/60 leading-snug">Precision-cut vinyl graphics engineered for high endurance.</p>
                <a href="#featured-products" className="inline-block border-b border-[#1a1a1a] pb-0.5 text-[10px] font-black uppercase tracking-wider text-[#1a1a1a] hover:text-[#ff3300] hover:border-[#ff3300] transition-colors">
                  View Designs
                </a>
              </div>

              <div className="space-y-2 border-t-2 border-[#1a1a1a] pt-3">
                <h3 className="text-xs font-black uppercase tracking-wider text-[#1a1a1a]">Body Shields</h3>
                <p className="text-[11px] text-[#1a1a1a]/60 leading-snug">Invisible protection. Industrial-grade PPF wraps & installations.</p>
                <a href="#featured-products" className="inline-block border-b border-[#1a1a1a] pb-0.5 text-[10px] font-black uppercase tracking-wider text-[#1a1a1a] hover:text-[#ff3300] hover:border-[#ff3300] transition-colors">
                  Shield Specs
                </a>
              </div>
            </div>
          </div>

          {/* Bottom Shelf Metadata Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-8 mt-10 border-t border-[#1a1a1a]/10 items-center">
            <div>
              <h4 className="font-mono-meta text-[10px] uppercase text-[#1a1a1a]/50 tracking-wider mb-0.5">Location</h4>
              <p className="text-xs font-bold text-[#1a1a1a]">Attariya, Kailali, Nepal</p>
            </div>

            <div>
              <h4 className="font-mono-meta text-[10px] uppercase text-[#1a1a1a]/50 tracking-wider mb-0.5">Availability</h4>
              <p className="text-xs font-bold text-[#1a1a1a]">Sun - Fri / 08:00 - 19:00</p>
            </div>

            <div>
              <h4 className="font-mono-meta text-[10px] uppercase text-[#1a1a1a]/50 tracking-wider mb-0.5">Service Line</h4>
              <p className="text-xs font-bold text-[#1a1a1a]">{settings.phone}</p>
            </div>

            <div>
              <a
                href={directWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-black w-full inline-flex items-center justify-center gap-2 rounded-none text-center shadow-sm"
              >
                <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>Consult on WhatsApp</span>
              </a>
            </div>
          </div>
        </div>

        {/* Right Featured Showcase Image Pane */}
        <div className="lg:col-span-4 bg-[#e5e4e1] relative overflow-hidden border-l border-[#1a1a1a]/10 min-h-[380px] lg:min-h-full group">
          <img
            src={currentSlide.image}
            alt={currentSlide.title}
            className="w-full h-full object-cover object-center mix-blend-multiply opacity-90 group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute top-4 right-4 bg-[#1a1a1a] text-white px-3 py-1 font-mono-meta text-[10px] uppercase tracking-widest">
            BIST PERFORMANCE
          </div>

          {activeSlides.length > 1 && (
            <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center bg-[#f8f7f4]/90 backdrop-blur-md p-2 border border-[#1a1a1a]/10">
              <button
                onClick={handlePrev}
                className="p-2 hover:bg-[#1a1a1a] hover:text-white transition-colors"
                aria-label="Previous slide"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="font-mono-meta text-[10px] uppercase font-bold text-[#1a1a1a]">
                {currentSlide.title}
              </span>
              <button
                onClick={handleNext}
                className="p-2 hover:bg-[#1a1a1a] hover:text-white transition-colors"
                aria-label="Next slide"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

