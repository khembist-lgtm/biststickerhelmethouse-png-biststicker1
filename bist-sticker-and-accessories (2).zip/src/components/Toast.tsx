import React from 'react';
import { CheckCircle, AlertCircle, X } from 'lucide-react';

interface ToastProps {
  toast: { message: string; type: 'success' | 'error' } | null;
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ toast, onClose }) => {
  if (!toast) return null;

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-5 py-3 rounded-xl shadow-2xl transition-all duration-300 bg-zinc-900 text-white border border-zinc-800">
      {toast.type === 'success' ? (
        <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
      ) : (
        <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
      )}
      <span className="text-sm font-medium pr-2">{toast.message}</span>
      <button
        onClick={onClose}
        className="text-zinc-400 hover:text-white p-1 rounded-lg hover:bg-zinc-800 transition"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
};
