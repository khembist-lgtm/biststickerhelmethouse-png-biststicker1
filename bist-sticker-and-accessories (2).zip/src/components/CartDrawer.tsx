import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  MessageCircle, 
  ArrowRight, 
  CheckCircle,
  Truck
} from 'lucide-react';
import { CartItem, SiteSettings } from '../types';
import { formatNPR, generateCartWhatsAppMessage, formatWhatsAppUrl, submitOrder } from '../lib/api';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  settings: SiteSettings;
  onOrderSuccess: (msg: string) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  settings,
  onOrderSuccess,
}) => {
  if (!isOpen) return null;

  const [isCheckoutStep, setIsCheckoutStep] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [cityArea, setCityArea] = useState('Attariya, Kailali');
  const [orderNotes, setOrderNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!customerName.trim() || !customerPhone.trim() || !deliveryAddress.trim()) {
      alert('Please fill in your name, phone number, and delivery address.');
      return;
    }

    setIsSubmitting(true);

    const customerInfo = {
      name: customerName,
      phone: customerPhone,
      address: deliveryAddress,
      cityArea,
      notes: orderNotes,
    };

    // 1. Generate WhatsApp order text
    const message = generateCartWhatsAppMessage(
      settings.shopName,
      customerInfo,
      cartItems,
      subtotal
    );

    const whatsappUrl = formatWhatsAppUrl(settings.whatsappNumber, message);

    // 2. Log order to backend database
    const orderPayload = {
      id: `ord_${Date.now()}`,
      customerName,
      customerPhone,
      deliveryAddress,
      cityArea,
      orderNotes,
      items: cartItems.map((ci) => ({
        productId: ci.product.id,
        productName: ci.product.name,
        price: ci.product.price,
        quantity: ci.quantity,
      })),
      totalAmount: subtotal,
      status: 'Pending WhatsApp',
      createdAt: new Date().toISOString(),
    };

    await submitOrder(orderPayload);

    setIsSubmitting(false);
    onClearCart();
    setIsCheckoutStep(false);
    onClose();

    onOrderSuccess('Order created! Opening WhatsApp to complete your purchase...');

    // Open WhatsApp URL in new window/tab
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-zinc-950/80 backdrop-blur-md flex justify-end animate-fadeIn">
      <div className="w-full max-w-md bg-white/95 backdrop-blur-2xl h-full shadow-2xl border-l border-zinc-200/80 flex flex-col justify-between relative text-zinc-900">
        {/* Header - Immersive UI Gradient */}
        <div className="p-4 sm:p-5 border-b border-zinc-800/80 flex items-center justify-between bg-gradient-to-r from-zinc-950 via-zinc-900 to-black text-white shadow-md">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-600/30 border border-red-500/40 flex items-center justify-center glow-red-sm">
              <ShoppingBag className="w-4 h-4 text-red-400" />
            </div>
            <h2 className="text-sm font-black uppercase tracking-tight font-sans text-white">
              {isCheckoutStep ? 'Checkout via WhatsApp' : `Shopping Cart (${cartItems.length})`}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800/80 transition-all duration-200 hover:scale-105 active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {cartItems.length === 0 ? (
            <div className="text-center py-20 space-y-3">
              <ShoppingBag className="w-12 h-12 text-zinc-300 mx-auto" />
              <p className="text-sm font-bold text-zinc-600">Your cart is currently empty.</p>
              <p className="text-xs text-zinc-400 max-w-xs mx-auto">
                Explore our catalog of bike stickers, helmets, and accessories to add items to your cart.
              </p>
            </div>
          ) : !isCheckoutStep ? (
            /* Cart Items List */
            <div className="space-y-3">
              {cartItems.map((item) => (
                <div
                  key={item.product.id}
                  className="flex items-center gap-3 bg-zinc-50 p-3 rounded-2xl border border-zinc-200"
                >
                  <img
                    src={
                      item.product.images?.[0] ||
                      'https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=150'
                    }
                    alt=""
                    className="w-16 h-16 object-cover rounded-xl border border-zinc-200 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-zinc-900 line-clamp-1">
                      {item.product.name}
                    </h4>
                    <span className="text-xs font-black text-zinc-950 mt-1 block">
                      {formatNPR(item.product.price)}
                    </span>

                    {/* Quantity Modifiers */}
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex items-center border border-zinc-200 rounded-lg bg-white p-0.5">
                        <button
                          onClick={() =>
                            onUpdateQuantity(item.product.id, Math.max(1, item.quantity - 1))
                          }
                          className="p-1 text-zinc-600 hover:text-black"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2 text-xs font-bold">{item.quantity}</span>
                        <button
                          onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                          className="p-1 text-zinc-600 hover:text-black"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <button
                        onClick={() => onRemoveItem(item.product.id)}
                        className="p-1 text-zinc-400 hover:text-red-600 transition ml-auto"
                        title="Remove item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              <button
                onClick={onClearCart}
                className="text-xs text-zinc-500 hover:text-red-600 underline font-semibold pt-2"
              >
                Clear Cart
              </button>
            </div>
          ) : (
            /* WhatsApp Checkout Form */
            <form onSubmit={handleCheckoutSubmit} className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl text-xs text-emerald-900 flex items-start gap-2">
                <Truck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <span>
                  Provide your delivery details below. Clicking "Order via WhatsApp" opens WhatsApp with your pre-filled invoice.
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 uppercase mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Bist"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 uppercase mb-1">
                  Phone Number (Mobile/WhatsApp) *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. 9848412345"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 uppercase mb-1">
                  Delivery Address *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Main Chowk, Near Bank"
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 uppercase mb-1">
                  City / Location
                </label>
                <input
                  type="text"
                  value={cityArea}
                  onChange={(e) => setCityArea(e.target.value)}
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 uppercase mb-1">
                  Order Notes (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Bike model (Pulsar 220), custom sticker color preference..."
                  value={orderNotes}
                  onChange={(e) => setOrderNotes(e.target.value)}
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 text-xs text-zinc-900 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setIsCheckoutStep(false)}
                  className="text-xs text-zinc-500 hover:text-black underline font-semibold"
                >
                  ← Back to cart items
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer / Total & Submit */}
        {cartItems.length > 0 && (
          <div className="p-4 border-t border-zinc-200 bg-zinc-50 space-y-3">
            <div className="flex items-center justify-between text-sm font-black text-zinc-950">
              <span>Total Amount:</span>
              <span className="text-lg text-red-600 font-sans">{formatNPR(subtotal)}</span>
            </div>

            {!isCheckoutStep ? (
              <button
                onClick={() => setIsCheckoutStep(true)}
                className="w-full flex items-center justify-center gap-2 bg-zinc-950 hover:bg-zinc-800 text-white font-black py-3.5 px-4 rounded-xl shadow-lg transition"
              >
                <span>Proceed to Order Details</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleCheckoutSubmit}
                disabled={isSubmitting}
                className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3.5 px-4 rounded-xl shadow-lg transition disabled:opacity-50"
              >
                <MessageCircle className="w-5 h-5" />
                <span>{isSubmitting ? 'Processing...' : 'Send Order via WhatsApp'}</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
