import React from 'react';
import { 
  Sparkles, 
  Shield, 
  FileText, 
  Layers, 
  Zap, 
  Key, 
  Truck, 
  Sun, 
  Wrench,
  ArrowRight
} from 'lucide-react';
import { shopServices } from '../data/initialData';
import { formatWhatsAppUrl } from '../lib/api';
import { SiteSettings } from '../types';

interface ServicesSectionProps {
  settings: SiteSettings;
}

const iconMap: Record<string, React.ReactNode> = {
  Sparkles: <Sparkles className="w-5 h-5 text-[#ff3300]" />,
  Shield: <Shield className="w-5 h-5 text-[#ff3300]" />,
  FileText: <FileText className="w-5 h-5 text-[#ff3300]" />,
  Layers: <Layers className="w-5 h-5 text-[#ff3300]" />,
  Zap: <Zap className="w-5 h-5 text-[#ff3300]" />,
  Key: <Key className="w-5 h-5 text-[#ff3300]" />,
  Truck: <Truck className="w-5 h-5 text-[#ff3300]" />,
  Sun: <Sun className="w-5 h-5 text-[#ff3300]" />,
  Wrench: <Wrench className="w-5 h-5 text-[#ff3300]" />,
};

export const ServicesSection: React.FC<ServicesSectionProps> = ({ settings }) => {
  return (
    <section id="services" className="py-16 sm:py-20 bg-[#f8f7f4] border-b border-[#1a1a1a]/10">
      <div className="max-w-[1600px] mx-auto px-6 sm:px-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#1a1a1a]/10 gap-6">
          <div>
            <div className="font-mono-meta text-[11px] uppercase tracking-[0.2em] text-[#1a1a1a]/60 mb-2">
              TECHNICAL CRAFTSMANSHIP
            </div>
            <h2 className="text-3xl sm:text-5xl font-black text-[#1a1a1a] uppercase tracking-tighter font-sans">
              Specialized Studio Services<span className="text-[#ff3300]">.</span>
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-[#1a1a1a]/70 max-w-md font-medium leading-relaxed">
            Expert motorcycle customization, precision decal cutting, paint protection film fitting, and custom key making in Attariya, Kailali.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {shopServices.map((service) => {
            const whatsappUrl = formatWhatsAppUrl(
              settings.whatsappNumber,
              `Hello ${settings.shopName}, I would like to inquire about your service: ${service.title}.`
            );

            return (
              <div
                key={service.id}
                className="group bg-[#f8f7f4] border-t-2 border-[#1a1a1a] pt-5 pb-4 flex flex-col justify-between transition-all duration-300"
              >
                <div className="space-y-3">
                  <div className="w-10 h-10 bg-[#e5e4e1] flex items-center justify-center shrink-0 border border-[#1a1a1a]/10">
                    {iconMap[service.iconName] || <Sparkles className="w-5 h-5 text-[#ff3300]" />}
                  </div>

                  <div>
                    <h3 className="text-sm font-black text-[#1a1a1a] uppercase group-hover:text-[#ff3300] transition-colors duration-200 tracking-wider font-sans">
                      {service.title}
                    </h3>
                    <p className="text-[11px] text-[#1a1a1a]/60 mt-2 leading-relaxed font-sans">
                      {service.description}
                    </p>
                  </div>
                </div>

                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-6 inline-flex items-center gap-1.5 border-b border-[#1a1a1a] pb-0.5 text-[10px] font-black uppercase tracking-wider text-[#1a1a1a] group-hover:text-[#ff3300] group-hover:border-[#ff3300] transition-colors"
                >
                  <span>Inquire Service on WhatsApp</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

