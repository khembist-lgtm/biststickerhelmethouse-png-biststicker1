import React, { useState } from 'react';
import { 
  Plus, 
  Edit3, 
  Trash2, 
  Search, 
  Upload, 
  X, 
  Check, 
  AlertTriangle, 
  Image as ImageIcon,
  Sparkles,
  RefreshCw,
  CheckCircle2,
  HardDrive
} from 'lucide-react';
import { Product, Category } from '../../types';
import { formatNPR } from '../../lib/api';
import { uploadImageFile } from '../../lib/storage';
import { GoogleDriveImagePicker } from './GoogleDriveImagePicker';

interface AdminProductManagerProps {
  products: Product[];
  categories: Category[];
  onSaveProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  isAddModalOpenInitially?: boolean;
}

export const AdminProductManager: React.FC<AdminProductManagerProps> = ({
  products,
  categories,
  onSaveProduct,
  onDeleteProduct,
  isAddModalOpenInitially = false,
}) => {
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState('All');
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(
    isAddModalOpenInitially ? createEmptyProduct() : null
  );
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  
  // Upload state
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'uploaded' | 'error'>('idle');
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isDrivePickerOpen, setIsDrivePickerOpen] = useState(false);

  function createEmptyProduct(): Partial<Product> {
    return {
      id: `prod_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: '',
      slug: '',
      category: categories[0]?.name || 'Bike Stickers',
      price: 1000,
      oldPrice: 1200,
      discount: 16,
      description: '',
      images: ['https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=600'],
      stockStatus: 'In Stock',
      stockCount: 20,
      sku: `SKU-${Math.floor(1000 + Math.random() * 9000)}`,
      isFeatured: true,
      isActive: true,
      tags: [],
      createdAt: new Date().toISOString(),
    };
  }

  const filteredProducts = products.filter((p) => {
    const matchCat = selectedCat === 'All' || p.category.toLowerCase() === selectedCat.toLowerCase();
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.sku?.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const openProductModal = (prod?: Partial<Product>) => {
    setEditingProduct(prod || createEmptyProduct());
    setUploadStatus('idle');
    setUploadProgress(null);
    setUploadError(null);
  };

  const closeProductModal = () => {
    setEditingProduct(null);
    setUploadStatus('idle');
    setUploadProgress(null);
    setUploadError(null);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';

    if (!file.type.startsWith('image/')) {
      setUploadStatus('error');
      setUploadError('Image upload failed: Selected file must be an image (JPG, PNG, WebP, etc.).');
      return;
    }

    setUploadStatus('uploading');
    setUploadProgress(0);
    setUploadError(null);

    try {
      const docId = editingProduct?.id || `prod_${Date.now()}`;
      const res = await uploadImageFile(file, 'products', docId, (progress) => {
        setUploadProgress(progress);
      });

      setEditingProduct((prev) => ({
        ...prev,
        images: [res.url, ...(prev?.images || [])],
        storagePaths: [res.storagePath || '', ...(prev?.storagePaths || [])],
      }));

      setUploadStatus('uploaded');
      setUploadProgress(100);
    } catch (err: any) {
      console.error('[PRODUCT_IMAGE_UPLOAD_ERROR]', err);
      const errMsg = err?.message || String(err || 'Unknown error');
      setUploadStatus('error');
      setUploadProgress(null);
      setUploadError(errMsg.startsWith('Image upload failed:') ? errMsg : `Image upload failed: ${errMsg}`);
    } finally {
      if (e.target) {
        e.target.value = '';
      }
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (uploadStatus === 'uploading') return;

    if (!editingProduct?.name || !editingProduct?.price) {
      alert('Please fill in required fields (Product Name and Price).');
      return;
    }

    const finalProd: Product = {
      id: editingProduct.id || `prod_${Date.now()}`,
      name: editingProduct.name,
      slug: editingProduct.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      category: editingProduct.category || categories[0]?.name || 'Bike Stickers',
      price: Number(editingProduct.price) || 0,
      oldPrice: editingProduct.oldPrice ? Number(editingProduct.oldPrice) : undefined,
      discount: editingProduct.discount ? Number(editingProduct.discount) : undefined,
      description: editingProduct.description || '',
      images: editingProduct.images && editingProduct.images.length > 0
        ? editingProduct.images
        : ['https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=600'],
      storagePaths: editingProduct.storagePaths,
      stockStatus: editingProduct.stockStatus || 'In Stock',
      stockCount: Number(editingProduct.stockCount || 10),
      sku: editingProduct.sku || 'SKU-001',
      isFeatured: editingProduct.isFeatured ?? true,
      isActive: editingProduct.isActive ?? true,
      tags: editingProduct.tags || [],
      createdAt: editingProduct.createdAt || new Date().toISOString(),
    };

    onSaveProduct(finalProd);
    closeProductModal();
  };

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6 text-zinc-900">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-zinc-200 shadow-sm">
        <div>
          <h2 className="text-xl font-black uppercase font-sans tracking-tight">
            Product Inventory Manager ({products.length})
          </h2>
          <p className="text-xs text-zinc-500 mt-0.5">
            Add, edit, toggle stock or delete motorcycle accessories and stickers.
          </p>
        </div>

        <button
          onClick={() => openProductModal()}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black px-4 py-2.5 rounded-xl shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Product</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 bg-white p-4 rounded-2xl border border-zinc-200 shadow-sm">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Search by product name or SKU..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-zinc-50 border border-zinc-300 rounded-xl pl-9 pr-4 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-red-600"
          />
          <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-2.5" />
        </div>

        <select
          value={selectedCat}
          onChange={(e) => setSelectedCat(e.target.value)}
          className="bg-zinc-50 border border-zinc-300 text-xs font-bold rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
        >
          <option value="All">All Categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.name}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      {/* Product Table */}
      <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-zinc-950 text-white uppercase font-bold text-[10px] tracking-wider">
              <tr>
                <th className="p-3">Image</th>
                <th className="p-3">Product Name</th>
                <th className="p-3">Category</th>
                <th className="p-3">Price (NPR)</th>
                <th className="p-3">Stock</th>
                <th className="p-3">Featured</th>
                <th className="p-3">Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {filteredProducts.map((p) => (
                <tr key={p.id} className="hover:bg-zinc-50 transition">
                  <td className="p-3">
                    <img
                      src={p.images?.[0] || 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=100'}
                      alt=""
                      className="w-12 h-12 object-cover rounded-xl border border-zinc-200"
                    />
                  </td>
                  <td className="p-3 font-bold text-zinc-900 max-w-xs">
                    <div>{p.name}</div>
                    <span className="text-[10px] text-zinc-400 font-mono">SKU: {p.sku}</span>
                  </td>
                  <td className="p-3 font-semibold text-red-600">{p.category}</td>
                  <td className="p-3 font-black text-zinc-950">
                    {formatNPR(p.price)}
                    {p.oldPrice && (
                      <span className="block text-[10px] text-zinc-400 line-through font-normal">
                        {formatNPR(p.oldPrice)}
                      </span>
                    )}
                  </td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        p.stockStatus === 'In Stock'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {p.stockStatus}
                    </span>
                  </td>
                  <td className="p-3">
                    {p.isFeatured ? (
                      <span className="text-amber-600 font-bold flex items-center gap-1">
                        <Sparkles className="w-3 h-3" /> Yes
                      </span>
                    ) : (
                      <span className="text-zinc-400">No</span>
                    )}
                  </td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        p.isActive ? 'bg-zinc-900 text-white' : 'bg-zinc-200 text-zinc-600'
                      }`}
                    >
                      {p.isActive ? 'Active' : 'Disabled'}
                    </span>
                  </td>
                  <td className="p-3 text-right space-x-2">
                    <button
                      onClick={() => openProductModal(p)}
                      className="p-2 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-800 transition"
                      title="Edit Product"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeleteConfirmId(p.id)}
                      className="p-2 rounded-lg bg-red-50 hover:bg-red-600 hover:text-white text-red-600 transition"
                      title="Delete Product"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black uppercase text-zinc-900">Confirm Product Delete</h3>
            <p className="text-xs text-zinc-500">
              Are you sure you want to delete this product? This action cannot be undone.
            </p>
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 py-2.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteProduct(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Product Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-2xl relative text-zinc-900 border border-zinc-200">
            <button
              onClick={closeProductModal}
              className="absolute top-4 right-4 p-2 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-600"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-black uppercase font-sans tracking-tight mb-6">
              {editingProduct.id && products.some((p) => p.id === editingProduct.id)
                ? 'Edit Product'
                : 'Add New Product'}
            </h3>

            <form onSubmit={handleFormSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold uppercase text-zinc-700 mb-1">
                  Product Name *
                </label>
                <input
                  type="text"
                  required
                  value={editingProduct.name || ''}
                  onChange={(e) =>
                    setEditingProduct({ ...editingProduct, name: e.target.value })
                  }
                  placeholder="e.g. Pulsar NS Tanki Pad - Anti-Scratch Guard"
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold uppercase text-zinc-700 mb-1">Category *</label>
                  <select
                    value={editingProduct.category || categories[0]?.name}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, category: e.target.value })
                    }
                    className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 font-bold focus:outline-none focus:ring-2 focus:ring-red-600"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold uppercase text-zinc-700 mb-1">SKU Code</label>
                  <input
                    type="text"
                    value={editingProduct.sku || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, sku: e.target.value })}
                    className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-red-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold uppercase text-zinc-700 mb-1">
                    Price (NPR) *
                  </label>
                  <input
                    type="number"
                    required
                    value={editingProduct.price || 0}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, price: Number(e.target.value) })
                    }
                    className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 font-bold text-red-600 focus:outline-none focus:ring-2 focus:ring-red-600"
                  />
                </div>

                <div>
                  <label className="block font-bold uppercase text-zinc-700 mb-1">
                    Old Price (NPR)
                  </label>
                  <input
                    type="number"
                    value={editingProduct.oldPrice || ''}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        oldPrice: e.target.value ? Number(e.target.value) : undefined,
                      })
                    }
                    className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-red-600"
                  />
                </div>

                <div>
                  <label className="block font-bold uppercase text-zinc-700 mb-1">Discount %</label>
                  <input
                    type="number"
                    value={editingProduct.discount || ''}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        discount: e.target.value ? Number(e.target.value) : undefined,
                      })
                    }
                    className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-red-600"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold uppercase text-zinc-700 mb-1">Description</label>
                <textarea
                  rows={3}
                  value={editingProduct.description || ''}
                  onChange={(e) =>
                    setEditingProduct({ ...editingProduct, description: e.target.value })
                  }
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              {/* Image Upload & Management */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold uppercase text-zinc-700">
                    Product Images
                  </label>
                  <span className="text-[10px] text-zinc-500 font-medium">
                    {uploadStatus === 'uploading' ? (
                      <span className="text-amber-600 font-bold flex items-center gap-1">
                        <RefreshCw className="w-3 h-3 animate-spin" /> Uploading... {uploadProgress !== null ? `${uploadProgress}%` : ''}
                      </span>
                    ) : uploadStatus === 'uploaded' ? (
                      <span className="text-emerald-600 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Uploaded ✓
                      </span>
                    ) : (
                      'Firebase Storage SDK'
                    )}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-3 mb-2">
                  {editingProduct.images?.map((img, idx) => (
                    <div key={idx} className="relative w-16 h-16 rounded-xl overflow-hidden border border-zinc-300">
                      <img src={img} alt="" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() =>
                          setEditingProduct({
                            ...editingProduct,
                            images: editingProduct.images?.filter((_, i) => i !== idx),
                            storagePaths: editingProduct.storagePaths?.filter((_, i) => i !== idx),
                          })
                        }
                        className="absolute top-0.5 right-0.5 bg-red-600 text-white p-0.5 rounded-full"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}

                  <label className={`w-16 h-16 rounded-xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition ${
                    uploadStatus === 'uploading'
                      ? 'border-amber-400 bg-amber-50 cursor-not-allowed'
                      : uploadStatus === 'uploaded'
                      ? 'border-emerald-400 bg-emerald-50'
                      : 'border-zinc-300 hover:border-red-600 bg-zinc-50'
                  }`}>
                    {uploadStatus === 'uploading' ? (
                      <RefreshCw className="w-4 h-4 text-amber-600 animate-spin" />
                    ) : uploadStatus === 'uploaded' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Upload className="w-4 h-4 text-zinc-500" />
                    )}
                    <span className="text-[9px] text-zinc-500 mt-0.5">
                      {uploadStatus === 'uploading'
                        ? `${uploadProgress !== null ? `${uploadProgress}%` : '...'}`
                        : uploadStatus === 'uploaded'
                        ? 'Done'
                        : 'Upload'}
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                      disabled={uploadStatus === 'uploading'}
                    />
                  </label>

                  <button
                    type="button"
                    onClick={() => setIsDrivePickerOpen(true)}
                    className="w-16 h-16 rounded-xl border border-blue-200 bg-blue-50 hover:bg-blue-100 flex flex-col items-center justify-center text-blue-700 transition"
                    title="Select image from Google Drive"
                  >
                    <HardDrive className="w-4 h-4 text-blue-600 mb-0.5" />
                    <span className="text-[9px] font-bold">Drive</span>
                  </button>
                </div>

                {/* Progress Bar when uploading */}
                {uploadStatus === 'uploading' && uploadProgress !== null && (
                  <div className="w-full bg-zinc-100 rounded-full h-1.5 mb-2 overflow-hidden">
                    <div
                      className="bg-red-600 h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                )}

                {/* Error Banner */}
                {uploadError && (
                  <div className="mb-3 p-3 bg-red-50 border border-red-200 rounded-xl space-y-2 text-red-700 text-xs">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
                      <div className="flex-1 font-semibold break-words">{uploadError}</div>
                    </div>
                  </div>
                )}

                {/* Direct Image URL input */}
                <input
                  type="text"
                  placeholder="Or paste image URL..."
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      const val = (e.target as HTMLInputElement).value;
                      if (val) {
                        setEditingProduct({
                          ...editingProduct,
                          images: [...(editingProduct.images || []), val],
                        });
                        (e.target as HTMLInputElement).value = '';
                      }
                    }
                  }}
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block font-bold uppercase text-zinc-700 mb-1">Stock Status</label>
                  <select
                    value={editingProduct.stockStatus || 'In Stock'}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, stockStatus: e.target.value as any })
                    }
                    className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3 py-2 font-bold"
                  >
                    <option value="In Stock">In Stock</option>
                    <option value="Limited Stock">Limited Stock</option>
                    <option value="Out of Stock">Out of Stock</option>
                  </select>
                </div>

                <div className="flex items-center gap-4 pt-5">
                  <label className="flex items-center gap-2 cursor-pointer font-bold">
                    <input
                      type="checkbox"
                      checked={editingProduct.isFeatured ?? true}
                      onChange={(e) =>
                        setEditingProduct({ ...editingProduct, isFeatured: e.target.checked })
                      }
                      className="accent-red-600 w-4 h-4"
                    />
                    <span>Featured</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer font-bold">
                    <input
                      type="checkbox"
                      checked={editingProduct.isActive ?? true}
                      onChange={(e) =>
                        setEditingProduct({ ...editingProduct, isActive: e.target.checked })
                      }
                      className="accent-red-600 w-4 h-4"
                    />
                    <span>Active</span>
                  </label>
                </div>
              </div>

              <div className="pt-4 border-t border-zinc-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={closeProductModal}
                  disabled={uploadStatus === 'uploading'}
                  className="px-5 py-2.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-bold rounded-xl disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={uploadStatus === 'uploading'}
                  className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-black rounded-xl shadow disabled:opacity-50 flex items-center gap-2"
                >
                  {uploadStatus === 'uploading' ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Uploading Image...</span>
                    </>
                  ) : (
                    <span>Save Product</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Google Drive Image Picker Modal */}
      <GoogleDriveImagePicker
        isOpen={isDrivePickerOpen}
        onClose={() => setIsDrivePickerOpen(false)}
        onSelectImage={(dataUrl) => {
          setEditingProduct((prev) => {
            const currentImages = prev?.images || [];
            return {
              ...prev,
              images: [...currentImages, dataUrl],
            };
          });
          setUploadStatus('uploaded');
        }}
      />
    </div>
  );
};
