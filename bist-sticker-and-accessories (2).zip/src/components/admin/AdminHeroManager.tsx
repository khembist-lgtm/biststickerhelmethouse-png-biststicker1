import React, { useState } from 'react';
import { Plus, Edit3, Trash2, Upload, X, AlertTriangle, ArrowUp, ArrowDown, RefreshCw, CheckCircle2 } from 'lucide-react';
import { HeroSlide } from '../../types';
import { uploadImageFile } from '../../lib/storage';

interface AdminHeroManagerProps {
  slides: HeroSlide[];
  onSaveSlide: (slide: HeroSlide) => void;
  onDeleteSlide: (slideId: string) => void;
  isAddModalOpenInitially?: boolean;
}

export const AdminHeroManager: React.FC<AdminHeroManagerProps> = ({
  slides,
  onSaveSlide,
  onDeleteSlide,
  isAddModalOpenInitially = false,
}) => {
  const [editingSlide, setEditingSlide] = useState<Partial<HeroSlide> | null>(
    isAddModalOpenInitially ? createEmptySlide() : null
  );
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  
  // Upload state
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'uploaded' | 'error'>('idle');
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  function createEmptySlide(): Partial<HeroSlide> {
    return {
      id: `slide_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      smallText: 'BIST STICKER & ACCESSORIES',
      title: '',
      description: '',
      image: 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=1200',
      primaryBtnText: 'Shop Now',
      primaryBtnLink: '#featured-products',
      secondaryBtnText: 'WhatsApp Us',
      secondaryBtnLink: 'https://wa.me/9779848419968',
      order: slides.length + 1,
      isActive: true,
    };
  }

  const openSlideModal = (slide?: Partial<HeroSlide>) => {
    setEditingSlide(slide || createEmptySlide());
    setUploadStatus('idle');
    setUploadProgress(null);
    setUploadError(null);
  };

  const closeSlideModal = () => {
    setEditingSlide(null);
    setUploadStatus('idle');
    setUploadProgress(null);
    setUploadError(null);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';

    if (!file.type.startsWith('image/')) {
      setUploadStatus('error');
      setUploadError('Image upload failed: Selected file must be an image (JPG, PNG, WebP, etc.).');
      return;
    }

    setUploadStatus('uploading');
    setUploadProgress(0);
    setUploadError(null);

    try {
      const docId = editingSlide?.id || `slide_${Date.now()}`;
      const res = await uploadImageFile(file, 'heroSlides', docId, (progress) => {
        setUploadProgress(progress);
      });

      setEditingSlide((prev) => ({
        ...prev,
        image: res.url,
        storagePath: res.storagePath,
      }));

      setUploadStatus('uploaded');
      setUploadProgress(100);
    } catch (err: any) {
      console.error('[HERO_IMAGE_UPLOAD_ERROR]', err);
      const errMsg = err?.message || String(err || 'Unknown error');
      setUploadStatus('error');
      setUploadProgress(null);
      setUploadError(errMsg.startsWith('Image upload failed:') ? errMsg : `Image upload failed: ${errMsg}`);
    } finally {
      if (e.target) {
        e.target.value = '';
      }
    }
  };

  const handleRemoveImage = () => {
    setEditingSlide((prev) => ({
      ...prev,
      image: '',
      storagePath: undefined,
    }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (uploadStatus === 'uploading') return;

    if (!editingSlide?.title) {
      alert('Please enter slide heading title.');
      return;
    }

    const finalSlide: HeroSlide = {
      id: editingSlide.id || `slide_${Date.now()}`,
      smallText: editingSlide.smallText || 'BIST STICKER & ACCESSORIES',
      title: editingSlide.title,
      description: editingSlide.description || '',
      image: editingSlide.image || 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=1200',
      storagePath: editingSlide.storagePath,
      primaryBtnText: editingSlide.primaryBtnText || 'Shop Now',
      primaryBtnLink: editingSlide.primaryBtnLink || '#featured-products',
      secondaryBtnText: editingSlide.secondaryBtnText || 'WhatsApp Us',
      secondaryBtnLink: editingSlide.secondaryBtnLink || 'https://wa.me/9779848419968',
      order: Number(editingSlide.order || 1),
      isActive: editingSlide.isActive ?? true,
    };

    onSaveSlide(finalSlide);
    closeSlideModal();
  };

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6 text-zinc-900">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-zinc-200 shadow-sm">
        <div>
          <h2 className="text-xl font-black uppercase font-sans tracking-tight">
            Hero Banner Manager ({slides.length})
          </h2>
          <p className="text-xs text-zinc-500 mt-0.5">
            Replace homepage banner images, titles, descriptions, and CTA buttons directly.
          </p>
        </div>

        <button
          onClick={() => openSlideModal()}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black px-4 py-2.5 rounded-xl shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>Add Hero Slide</span>
        </button>
      </div>

      {/* Slide Cards List */}
      <div className="space-y-4">
        {slides
          .sort((a, b) => a.order - b.order)
          .map((slide) => (
            <div
              key={slide.id}
              className="bg-white border border-zinc-200 rounded-2xl p-4 shadow-sm flex flex-col md:flex-row items-start md:items-center gap-4 justify-between"
            >
              <img
                src={slide.image}
                alt=""
                className="w-full md:w-44 h-28 object-cover rounded-xl border border-zinc-200 shrink-0"
              />

              <div className="flex-1 space-y-1">
                <span className="text-[10px] font-extrabold text-red-600 uppercase tracking-widest bg-red-50 px-2 py-0.5 rounded-full">
                  {slide.smallText || 'BIST STICKER & ACCESSORIES'}
                </span>
                <h3 className="text-base font-black text-zinc-950 uppercase">{slide.title}</h3>
                <p className="text-xs text-zinc-500 line-clamp-1">{slide.description}</p>
                <div className="flex items-center gap-3 text-[11px] font-semibold text-zinc-400 pt-1">
                  <span>Primary: "{slide.primaryBtnText}"</span>
                  <span>Secondary: "{slide.secondaryBtnText}"</span>
                  <span className="font-mono text-zinc-600">Order: #{slide.order}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end md:self-center">
                <span
                  className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold ${
                    slide.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-zinc-200 text-zinc-600'
                  }`}
                >
                  {slide.isActive ? 'Active' : 'Disabled'}
                </span>

                <button
                  onClick={() => openSlideModal(slide)}
                  className="p-2 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-800 transition"
                  title="Edit Slide"
                >
                  <Edit3 className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setDeleteConfirmId(slide.id)}
                  className="p-2 rounded-lg bg-red-50 hover:bg-red-600 hover:text-white text-red-600 transition"
                  title="Delete Slide"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
      </div>

      {/* Delete Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black uppercase text-zinc-900">Delete Slide?</h3>
            <p className="text-xs text-zinc-500">
              This hero banner slide will be permanently deleted from homepage slider.
            </p>
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 py-2.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteSlide(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Slide Modal */}
      {editingSlide && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl relative text-zinc-900 border border-zinc-200 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setEditingSlide(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-600"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-black uppercase font-sans tracking-tight mb-4">
              {editingSlide.id && slides.some((s) => s.id === editingSlide.id)
                ? 'Edit Hero Slide'
                : 'Add Hero Slide'}
            </h3>

            <form onSubmit={handleFormSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold uppercase text-zinc-700 mb-1">
                  Small Top Tagline / Eyebrow
                </label>
                <input
                  type="text"
                  value={editingSlide.smallText || ''}
                  onChange={(e) =>
                    setEditingSlide({ ...editingSlide, smallText: e.target.value })
                  }
                  placeholder="e.g. BIST STICKER & ACCESSORIES"
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div>
                <label className="block font-bold uppercase text-zinc-700 mb-1">
                  Main Title Heading *
                </label>
                <input
                  type="text"
                  required
                  value={editingSlide.title || ''}
                  onChange={(e) => setEditingSlide({ ...editingSlide, title: e.target.value })}
                  placeholder="e.g. Style Your Ride. Make It Yours."
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 font-bold focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div>
                <label className="block font-bold uppercase text-zinc-700 mb-1">
                  Description Text
                </label>
                <textarea
                  rows={2}
                  value={editingSlide.description || ''}
                  onChange={(e) =>
                    setEditingSlide({ ...editingSlide, description: e.target.value })
                  }
                  placeholder="e.g. Premium bike stickers, helmets and motorcycle accessories in Attariya."
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              {/* Banner Image */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold uppercase text-zinc-700">
                    Hero Image Banner
                  </label>
                  <span className="text-[10px] text-zinc-500 font-medium">
                    {uploadStatus === 'uploading' ? (
                      <span className="text-amber-600 font-bold flex items-center gap-1">
                        <RefreshCw className="w-3 h-3 animate-spin" /> Uploading... {uploadProgress !== null ? `${uploadProgress}%` : ''}
                      </span>
                    ) : uploadStatus === 'uploaded' ? (
                      <span className="text-emerald-600 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Uploaded ✓
                      </span>
                    ) : (
                      'Firebase Storage SDK'
                    )}
                  </span>
                </div>

                <div className="flex items-center gap-3 mb-3">
                  {editingSlide.image ? (
                    <div className="relative w-28 h-18 rounded-xl overflow-hidden border border-zinc-300 shrink-0">
                      <img
                        src={editingSlide.image}
                        alt="Hero Banner Preview"
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={handleRemoveImage}
                        title="Remove image"
                        className="absolute top-1 right-1 bg-red-600 hover:bg-red-700 text-white p-1 rounded-full shadow transition"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="w-28 h-18 rounded-xl bg-zinc-100 border border-zinc-300 flex items-center justify-center shrink-0">
                      <span className="text-xs text-zinc-400 font-bold">No Image</span>
                    </div>
                  )}

                  <label className={`flex-1 py-3 border-2 border-dashed rounded-xl flex items-center justify-center gap-2 cursor-pointer transition ${
                    uploadStatus === 'uploading'
                      ? 'border-amber-400 bg-amber-50 cursor-not-allowed'
                      : uploadStatus === 'uploaded'
                      ? 'border-emerald-400 bg-emerald-50'
                      : 'border-zinc-300 hover:border-red-600 bg-zinc-50'
                  }`}>
                    {uploadStatus === 'uploading' ? (
                      <RefreshCw className="w-4 h-4 text-amber-600 animate-spin" />
                    ) : uploadStatus === 'uploaded' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Upload className="w-4 h-4 text-zinc-600" />
                    )}
                    <span className="font-bold text-zinc-700 text-xs sm:text-sm">
                      {uploadStatus === 'uploading'
                        ? `Uploading... ${uploadProgress !== null ? `${uploadProgress}%` : ''}`
                        : uploadStatus === 'uploaded'
                        ? 'Image Uploaded ✓'
                        : editingSlide.image
                        ? 'Replace Banner Image'
                        : 'Upload Banner Image'}
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                      disabled={uploadStatus === 'uploading'}
                    />
                  </label>
                </div>

                {/* Progress Bar when uploading */}
                {uploadStatus === 'uploading' && uploadProgress !== null && (
                  <div className="w-full bg-zinc-100 rounded-full h-1.5 mb-2 overflow-hidden">
                    <div
                      className="bg-red-600 h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                )}

                {/* Error Banner */}
                {uploadError && (
                  <div className="mb-3 p-3 bg-red-50 border border-red-200 rounded-xl space-y-2 text-red-700 text-xs">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
                      <div className="flex-1 font-semibold break-words">{uploadError}</div>
                    </div>
                  </div>
                )}

                <input
                  type="text"
                  placeholder="Or paste banner image URL..."
                  value={editingSlide.image || ''}
                  onChange={(e) => setEditingSlide({ ...editingSlide, image: e.target.value })}
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold uppercase text-zinc-700 mb-1">
                    Primary Button Label
                  </label>
                  <input
                    type="text"
                    value={editingSlide.primaryBtnText || ''}
                    onChange={(e) =>
                      setEditingSlide({ ...editingSlide, primaryBtnText: e.target.value })
                    }
                    className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5"
                  />
                </div>

                <div>
                  <label className="block font-bold uppercase text-zinc-700 mb-1">
                    Secondary Button Label
                  </label>
                  <input
                    type="text"
                    value={editingSlide.secondaryBtnText || ''}
                    onChange={(e) =>
                      setEditingSlide({ ...editingSlide, secondaryBtnText: e.target.value })
                    }
                    className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block font-bold uppercase text-zinc-700 mb-1">
                    Display Priority Order
                  </label>
                  <input
                    type="number"
                    value={editingSlide.order || 1}
                    onChange={(e) =>
                      setEditingSlide({ ...editingSlide, order: Number(e.target.value) })
                    }
                    className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 font-mono font-bold"
                  />
                </div>

                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 cursor-pointer font-bold">
                    <input
                      type="checkbox"
                      checked={editingSlide.isActive ?? true}
                      onChange={(e) =>
                        setEditingSlide({ ...editingSlide, isActive: e.target.checked })
                      }
                      className="accent-red-600 w-4 h-4"
                    />
                    <span>Active Slide</span>
                  </label>
                </div>
              </div>

              <div className="pt-4 border-t border-zinc-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={closeSlideModal}
                  disabled={uploadStatus === 'uploading'}
                  className="px-4 py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-bold rounded-xl disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={uploadStatus === 'uploading'}
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white font-black rounded-xl shadow disabled:opacity-50 flex items-center gap-2"
                >
                  {uploadStatus === 'uploading' ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Uploading Image...</span>
                    </>
                  ) : (
                    <span>Save Hero Slide</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
