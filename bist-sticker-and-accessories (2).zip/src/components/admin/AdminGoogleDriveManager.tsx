import React, { useState, useEffect } from 'react';
import { 
  HardDrive, 
  Search, 
  Upload, 
  Trash2, 
  ExternalLink, 
  RefreshCw, 
  FileText, 
  Image as ImageIcon, 
  File, 
  Loader2, 
  LogOut, 
  AlertTriangle,
  Folder,
  Download,
  Plus
} from 'lucide-react';
import { 
  googleDriveSignIn, 
  googleDriveLogout, 
  listDriveFiles, 
  uploadToDrive, 
  deleteFromDrive, 
  getDriveAccessToken,
  initDriveAuth,
  DriveFile 
} from '../../lib/googleDrive';

export const AdminGoogleDriveManager: React.FC = () => {
  const [token, setToken] = useState<string | null>(getDriveAccessToken());
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [uploading, setUploading] = useState<boolean>(false);
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'images' | 'docs' | 'sheets'>('all');
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Destructive Delete Confirmation State (MANDATORY for Workspace APIs)
  const [fileToDelete, setFileToDelete] = useState<DriveFile | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  useEffect(() => {
    const unsubscribe = initDriveAuth(
      (user, t) => {
        setToken(t);
        setUserEmail(user.email);
        loadFiles(t);
      },
      () => {
        setToken(null);
        setUserEmail(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const loadFiles = async (currentToken = token) => {
    if (!currentToken) return;
    setLoading(true);
    setError(null);
    try {
      let query = searchQuery;
      if (selectedFilter === 'images') {
        query += " and mimeType contains 'image/'";
      } else if (selectedFilter === 'docs') {
        query += " and (mimeType contains 'document' or mimeType contains 'pdf')";
      } else if (selectedFilter === 'sheets') {
        query += " and mimeType contains 'spreadsheet'";
      }

      const res = await listDriveFiles(query);
      setFiles(res.files);
    } catch (err: any) {
      console.error('[DRIVE_LOAD_ERROR]', err);
      setError(err?.message || 'Failed to load files from Google Drive');
    } finally {
      setLoading(false);
    }
  };

  const handleSignIn = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await googleDriveSignIn();
      if (result) {
        setToken(result.accessToken);
        setUserEmail(result.user.email);
        loadFiles(result.accessToken);
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to connect to Google Drive');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await googleDriveLogout();
    setToken(null);
    setUserEmail(null);
    setFiles([]);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setUploading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const newDriveFile = await uploadToDrive(selectedFile);
      setSuccessMsg(`Successfully uploaded "${newDriveFile.name}" to Google Drive.`);
      loadFiles();
    } catch (err: any) {
      setError(err?.message || 'Failed to upload file to Google Drive');
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const confirmDeleteFile = async () => {
    if (!fileToDelete) return;
    setIsDeleting(true);
    setError(null);

    try {
      await deleteFromDrive(fileToDelete.id);
      setSuccessMsg(`File "${fileToDelete.name}" was removed from Google Drive.`);
      setFileToDelete(null);
      loadFiles();
    } catch (err: any) {
      setError(err?.message || 'Failed to delete file from Google Drive');
    } finally {
      setIsDeleting(false);
    }
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith('image/')) {
      return <ImageIcon className="w-5 h-5 text-emerald-400" />;
    }
    if (mimeType.includes('pdf') || mimeType.includes('document')) {
      return <FileText className="w-5 h-5 text-blue-400" />;
    }
    if (mimeType.includes('spreadsheet')) {
      return <FileText className="w-5 h-5 text-green-400" />;
    }
    if (mimeType.includes('folder')) {
      return <Folder className="w-5 h-5 text-amber-400" />;
    }
    return <File className="w-5 h-5 text-slate-400" />;
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
        
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-2xl text-blue-400">
              <HardDrive className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                Google Drive Storage & Files
              </h2>
              <p className="text-sm text-slate-400 mt-0.5">
                Manage, upload, search, and link your store assets directly with Google Drive
              </p>
            </div>
          </div>

          {token ? (
            <div className="flex items-center gap-3 bg-slate-950 border border-slate-800 px-4 py-2.5 rounded-xl">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <div className="text-xs">
                <p className="text-slate-400">Connected Account</p>
                <p className="text-white font-medium truncate max-w-[180px]">{userEmail || 'Google Drive'}</p>
              </div>
              <button
                onClick={handleLogout}
                className="ml-2 p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition-colors"
                title="Disconnect Google Drive"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={handleSignIn}
              disabled={loading}
              className="gsi-material-button flex items-center gap-3 px-5 py-2.5 bg-white text-slate-900 hover:bg-slate-100 font-medium text-sm rounded-xl shadow-lg transition-all disabled:opacity-50"
            >
              <div className="gsi-material-button-icon">
                <svg className="w-5 h-5" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                </svg>
              </div>
              <span>Sign in with Google</span>
            </button>
          )}
        </div>
      </div>

      {/* Alert Messages */}
      {error && (
        <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-sm text-red-400 flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="text-red-400 hover:text-white text-xs">Dismiss</button>
        </div>
      )}

      {successMsg && (
        <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-sm text-emerald-400 flex items-center justify-between">
          <span>{successMsg}</span>
          <button onClick={() => setSuccessMsg(null)} className="text-emerald-400 hover:text-white text-xs">Dismiss</button>
        </div>
      )}

      {!token ? (
        /* Sign-in Callout State */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 mx-auto">
            <HardDrive className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-semibold text-white">Connect Google Drive to Access Your Workspace</h3>
          <p className="text-sm text-slate-400 max-w-lg mx-auto">
            Link your Google Drive account to view, upload, search, and integrate your store images and documents with permission.
          </p>
          <div className="pt-2">
            <button
              onClick={handleSignIn}
              disabled={loading}
              className="inline-flex items-center gap-3 px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-medium text-sm rounded-xl shadow-lg transition-all disabled:opacity-50"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <HardDrive className="w-5 h-5" />
              )}
              <span>Authorize Google Drive</span>
            </button>
          </div>
        </div>
      ) : (
        /* Main Drive Workspace */
        <div className="space-y-4">
          {/* Action Bar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search files in Google Drive..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && loadFiles()}
                className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-1.5 bg-slate-950 p-1 border border-slate-800 rounded-xl overflow-x-auto">
              <button
                onClick={() => { setSelectedFilter('all'); loadFiles(); }}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                  selectedFilter === 'all' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                All Files
              </button>
              <button
                onClick={() => { setSelectedFilter('images'); loadFiles(); }}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                  selectedFilter === 'images' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Images
              </button>
              <button
                onClick={() => { setSelectedFilter('docs'); loadFiles(); }}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                  selectedFilter === 'docs' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Docs/PDFs
              </button>
            </div>

            {/* Refresh & Upload Buttons */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => loadFiles()}
                disabled={loading}
                className="p-2.5 bg-slate-950 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl transition-colors disabled:opacity-50"
                title="Refresh Google Drive files"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-blue-400' : ''}`} />
              </button>

              <label className="cursor-pointer flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-medium text-sm rounded-xl shadow-lg transition-all disabled:opacity-50">
                {uploading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Upload className="w-4 h-4" />
                )}
                <span>Upload to Drive</span>
                <input
                  type="file"
                  onChange={handleFileUpload}
                  disabled={uploading}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* File Grid */}
          {loading ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400 space-y-3">
              <Loader2 className="w-8 h-8 animate-spin text-blue-500 mx-auto" />
              <p className="text-sm">Loading files from Google Drive...</p>
            </div>
          ) : files.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400 space-y-2">
              <Folder className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-white font-medium text-sm">No files found</p>
              <p className="text-xs text-slate-500">Try adjusting your search query or upload a file to Google Drive.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {files.map((file) => (
                <div
                  key={file.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between hover:border-slate-700 transition-all group"
                >
                  <div className="space-y-3">
                    {/* Thumbnail / File Icon Area */}
                    <div className="aspect-video bg-slate-950 border border-slate-800/80 rounded-xl overflow-hidden flex items-center justify-center relative">
                      {file.thumbnailLink ? (
                        <img
                          src={file.thumbnailLink}
                          alt={file.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="p-3 rounded-xl bg-slate-900">
                          {getFileIcon(file.mimeType)}
                        </div>
                      )}
                    </div>

                    {/* File Info */}
                    <div>
                      <h4 className="text-sm font-semibold text-white truncate" title={file.name}>
                        {file.name}
                      </h4>
                      <p className="text-xs text-slate-400 mt-0.5 truncate">
                        {file.size ? `${(parseInt(file.size) / 1024).toFixed(0)} KB` : 'Google Drive Doc'}
                      </p>
                    </div>
                  </div>

                  {/* Actions Footer */}
                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                    {file.webViewLink && (
                      <a
                        href={file.webViewLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs text-blue-400 hover:text-blue-300 transition-colors"
                      >
                        <span>Open Drive</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}

                    <button
                      onClick={() => setFileToDelete(file)}
                      className="p-1.5 text-slate-500 hover:text-red-400 hover:bg-slate-800 rounded-lg transition-colors ml-auto"
                      title="Delete file from Google Drive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* MANDATORY Explicit Confirmation Modal for Destructive Delete Action */}
      {fileToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center gap-3 text-amber-400">
              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">Delete File from Google Drive?</h3>
            </div>

            <p className="text-sm text-slate-300">
              Are you sure you want to permanently delete <strong className="text-white">"{fileToDelete.name}"</strong> from your Google Drive account? This action cannot be undone.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
              <button
                onClick={() => setFileToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-sm rounded-xl transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={confirmDeleteFile}
                disabled={isDeleting}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-medium text-sm rounded-xl transition-colors disabled:opacity-50 flex items-center gap-2"
              >
                {isDeleting && <Loader2 className="w-4 h-4 animate-spin" />}
                Delete File
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
