import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Download, 
  Upload, 
  RotateCcw, 
  ShieldCheck, 
  HardDrive, 
  History, 
  CheckCircle2, 
  AlertCircle,
  FileText,
  Clock,
  Sparkles
} from 'lucide-react';
import { AppDataStore } from '../../types';
import { fetchBackupsList, createManualBackup, restoreFromBackup, saveStoreData, fetchStoreData } from '../../lib/api';
import { syncStoreToFirestore } from '../../lib/firestoreSync';
import { auth } from '../../lib/firebase';

interface AdminBackupManagerProps {
  storeData: AppDataStore;
  onStoreUpdated: (updatedStore: AppDataStore) => void;
}

export const AdminBackupManager: React.FC<AdminBackupManagerProps> = ({
  storeData,
  onStoreUpdated,
}) => {
  const [backups, setBackups] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const loadBackups = async () => {
    setLoading(true);
    const list = await fetchBackupsList();
    setBackups(list);
    setLoading(false);
  };

  useEffect(() => {
    loadBackups();
  }, []);

  const handleCreateBackup = async () => {
    setStatusMessage(null);
    setLoading(true);
    const res = await createManualBackup();
    if (res.success) {
      setStatusMessage({ type: 'success', text: `Backup created successfully (${res.backupName})` });
      await loadBackups();
    } else {
      setStatusMessage({ type: 'error', text: 'Failed to create backup.' });
    }
    setLoading(false);
  };

  const handleRestore = async (filename: string) => {
    if (!window.confirm(`Are you sure you want to restore the database from backup: ${filename}? This will replace current products and settings with the backup version.`)) {
      return;
    }

    setStatusMessage(null);
    setLoading(true);
    const ok = await restoreFromBackup(filename);
    if (ok) {
      // Refresh global store data from server store file and sync to Firestore
      const res = await fetch('/api/data');
      if (res.ok) {
        const freshStore = await res.json();
        await syncStoreToFirestore(freshStore);
        const firestoreStore = await fetchStoreData();
        onStoreUpdated(firestoreStore);
      }
      setStatusMessage({ type: 'success', text: `Successfully restored database from ${filename}` });
      await loadBackups();
    } else {
      setStatusMessage({ type: 'error', text: 'Failed to restore backup.' });
    }
    setLoading(false);
  };

  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(storeData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `bist_sticker_database_export_${new Date().toISOString().slice(0,10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const parsedData = JSON.parse(event.target?.result as string);
        if (!parsedData || typeof parsedData !== 'object' || !Array.isArray(parsedData.products)) {
          alert('Invalid store backup file structure. Ensure it contains a valid products array.');
          return;
        }

        if (window.confirm(`Import JSON file with ${parsedData.products.length} products and replace current database?`)) {
          setLoading(true);
          const saved = await saveStoreData(parsedData);
          if (saved) {
            onStoreUpdated(parsedData);
            setStatusMessage({ type: 'success', text: 'Imported database successfully!' });
            await loadBackups();
          } else {
            setStatusMessage({ type: 'error', text: 'Failed to save imported database to server.' });
          }
          setLoading(false);
        }
      } catch (err) {
        alert('Failed to parse JSON file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 text-white space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-600/20 text-red-500 border border-red-500/30 flex items-center justify-center shrink-0">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-black uppercase tracking-tight text-white flex items-center gap-2">
              <span>Database & Safe Data Persistence</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold px-2 py-0.5 rounded-full">
                Active & Protected
              </span>
            </h3>
            <p className="text-xs text-zinc-400">
              Your products and categories are stored outside build code in <code className="text-amber-400 bg-zinc-950 px-1 py-0.5 rounded">.data_storage/store.json</code>.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCreateBackup}
            disabled={loading}
            className="flex items-center gap-1.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition shadow"
          >
            <Sparkles className="w-4 h-4" />
            <span>Instant Backup Now</span>
          </button>
        </div>
      </div>

      {statusMessage && (
        <div className={`p-4 rounded-xl flex items-start gap-3 border ${
          statusMessage.type === 'success' 
            ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300' 
            : 'bg-red-950/40 border-red-800 text-red-300'
        }`}>
          {statusMessage.type === 'success' ? <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" /> : <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />}
          <div className="text-xs font-medium">{statusMessage.text}</div>
        </div>
      )}

      {/* Firebase Cloud Integration Banner */}
      <div className="bg-gradient-to-r from-amber-950/40 via-zinc-950 to-amber-950/20 p-5 rounded-2xl border border-amber-500/30 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-black uppercase text-amber-300 tracking-wider flex items-center gap-2">
                <span>Firebase Cloud Database & Authentication</span>
                <span className="text-[9px] bg-amber-400/20 text-amber-300 border border-amber-400/30 px-1.5 py-0.5 rounded font-extrabold">
                  CONNECTED
                </span>
              </h4>
              <p className="text-[11px] text-zinc-400">
                Project: <code className="text-amber-300 bg-zinc-900 px-1 rounded font-mono">peak-thought-tds98</code> | Region: <code className="text-amber-300 bg-zinc-900 px-1 rounded font-mono">asia-southeast1</code>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={async () => {
                setLoading(true);
                const currentUser = auth.currentUser;
                console.log(`[ADMIN_SAVE_DIAGNOSTIC] Push to Firestore triggered. auth.currentUser exists: ${!!currentUser}`, {
                  uid: currentUser?.uid || 'unauthenticated',
                  email: currentUser?.email || null,
                  isAnonymous: currentUser?.isAnonymous || false,
                });
                const ok = await syncStoreToFirestore(storeData);
                if (ok) {
                  setStatusMessage({ type: 'success', text: 'All products, categories, and settings successfully synced to Firebase Firestore!' });
                } else {
                  setStatusMessage({ type: 'error', text: 'Failed to sync data to Firebase Firestore. Check connection or security rules.' });
                }
                setLoading(false);
              }}
              disabled={loading}
              className="flex items-center gap-1.5 bg-amber-600 hover:bg-amber-500 text-zinc-950 font-black text-xs px-3.5 py-2 rounded-xl transition shadow"
            >
              <Database className="w-4 h-4" />
              <span>Push to Firebase Firestore</span>
            </button>
          </div>
        </div>
      </div>

      {/* Persistence Rules Explanation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-1.5">
          <div className="flex items-center gap-2 text-red-400 text-xs font-bold">
            <ShieldCheck className="w-4 h-4" />
            <span>Zero Overwrite Guarantee</span>
          </div>
          <p className="text-[11px] text-zinc-400 leading-relaxed">
            Deleting products from Admin permanently removes them. Server restarts or code deployments will never restore deleted demo items.
          </p>
        </div>

        <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-1.5">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold">
            <HardDrive className="w-4 h-4" />
            <span>External Storage Path</span>
          </div>
          <p className="text-[11px] text-zinc-400 leading-relaxed">
            The JSON database lives in <code className="text-zinc-200 font-mono">.data_storage/store.json</code> safely separated from Vite frontend compilation outputs.
          </p>
        </div>

        <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-1.5">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
            <History className="w-4 h-4" />
            <span>Auto Timestamped Backups</span>
          </div>
          <p className="text-[11px] text-zinc-400 leading-relaxed">
            Every product save or edit automatically writes a timestamped snapshot in <code className="text-zinc-200 font-mono">.data_storage/backups</code>.
          </p>
        </div>
      </div>

      {/* Import / Export JSON Database Controls */}
      <div className="bg-zinc-950 p-5 rounded-2xl border border-zinc-800 space-y-3">
        <h4 className="text-xs font-black uppercase text-zinc-300 tracking-wider">
          Export / Import Offline Database
        </h4>
        <p className="text-xs text-zinc-400">
          Download a complete backup copy of your products, categories, and site settings to your phone or computer, or restore a saved JSON database file.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleExportJson}
            className="flex items-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl border border-zinc-700 transition"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Export Database JSON</span>
          </button>

          <label className="flex items-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl border border-zinc-700 transition cursor-pointer">
            <Upload className="w-4 h-4 text-sky-400" />
            <span>Import Database JSON</span>
            <input 
              type="file" 
              accept=".json" 
              onChange={handleImportJson} 
              className="hidden" 
            />
          </label>
        </div>
      </div>

      {/* Automatic Backups List */}
      <div className="bg-zinc-950 p-5 rounded-2xl border border-zinc-800 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-red-500" />
            <h4 className="text-xs font-black uppercase text-white tracking-wider">
              Server Backups History ({backups.length})
            </h4>
          </div>
          <button
            onClick={loadBackups}
            className="text-[11px] text-zinc-400 hover:text-white underline font-semibold"
          >
            Refresh List
          </button>
        </div>

        {loading ? (
          <div className="text-center py-6 text-xs text-zinc-500">Loading backups...</div>
        ) : backups.length === 0 ? (
          <div className="text-center py-6 text-xs text-zinc-500">No backups found yet. Click "Instant Backup Now" to create one.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-zinc-900 text-zinc-400 uppercase font-bold text-[10px]">
                <tr>
                  <th className="p-3">Backup File</th>
                  <th className="p-3">Item Count</th>
                  <th className="p-3">File Size</th>
                  <th className="p-3">Created Date</th>
                  <th className="p-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-900 text-zinc-300">
                {backups.map((bk) => (
                  <tr key={bk.filename} className="hover:bg-zinc-900/50">
                    <td className="p-3 font-mono text-[11px] font-bold text-white flex items-center gap-2">
                      <FileText className="w-3.5 h-3.5 text-zinc-500" />
                      <span>{bk.filename}</span>
                      {bk.isLatest && (
                        <span className="text-[9px] bg-red-600 text-white font-extrabold px-1.5 py-0.5 rounded">
                          LATEST
                        </span>
                      )}
                    </td>
                    <td className="p-3 font-bold text-emerald-400">{bk.itemCount} products</td>
                    <td className="p-3 text-zinc-400">{Math.round(bk.size / 1024)} KB</td>
                    <td className="p-3 text-zinc-400">{new Date(bk.mtime).toLocaleString()}</td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => handleRestore(bk.filename)}
                        className="flex items-center gap-1 text-[11px] bg-zinc-800 hover:bg-red-600 hover:text-white text-zinc-300 font-bold px-3 py-1.5 rounded-lg border border-zinc-700 transition ml-auto"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Restore</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
