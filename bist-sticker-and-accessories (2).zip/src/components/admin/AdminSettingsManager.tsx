import React, { useState, useRef } from 'react';
import { Save, Upload, Trash2, CheckCircle2, Image as ImageIcon, Sparkles, RefreshCw, AlertTriangle } from 'lucide-react';
import { SiteSettings } from '../../types';
import { uploadImageFile } from '../../lib/storage';

interface AdminSettingsManagerProps {
  settings: SiteSettings;
  onSaveSettings: (settings: SiteSettings) => void;
}

export const AdminSettingsManager: React.FC<AdminSettingsManagerProps> = ({
  settings,
  onSaveSettings,
}) => {
  const [formData, setFormData] = useState<SiteSettings>({ ...settings });
  const [isSaved, setIsSaved] = useState(false);
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);
  const [logoProgress, setLogoProgress] = useState<number | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  const handleChange = (field: keyof SiteSettings, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleLogoUpload = async (file: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setUploadError('Image upload failed: Selected file must be an image (JPG, PNG, WebP, SVG, etc.).');
      return;
    }

    setIsUploadingLogo(true);
    setLogoProgress(0);
    setUploadError(null);
    try {
      const res = await uploadImageFile(file, 'settings', 'site_logo', (p) => setLogoProgress(p));
      setFormData((prev) => ({
        ...prev,
        logoUrl: res.url,
        logoStoragePath: res.storagePath,
      }));
      setLogoProgress(100);
    } catch (err: any) {
      console.error('[LOGO_IMAGE_UPLOAD_ERROR]', err);
      const errMsg = err?.message || String(err || 'Unknown error');
      setUploadError(errMsg.startsWith('Image upload failed:') ? errMsg : `Image upload failed: ${errMsg}`);
      setLogoProgress(null);
    } finally {
      setIsUploadingLogo(false);
    }
  };

  const handleRemoveLogo = () => {
    setFormData((prev) => ({ ...prev, logoUrl: '', logoStoragePath: undefined }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-6 text-zinc-900">
      {/* Header card */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-zinc-200 shadow-sm">
        <div>
          <h2 className="text-xl font-black uppercase font-sans tracking-tight flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-red-600" />
            <span>Website & Shop Settings</span>
          </h2>
          <p className="text-xs text-zinc-500 mt-1">
            Manage your official shop logo, contact info, WhatsApp numbers, social media & store hours.
          </p>
        </div>

        {isSaved && (
          <div className="flex items-center gap-1.5 bg-emerald-100 text-emerald-800 text-xs font-bold px-3.5 py-2 rounded-xl animate-fadeIn border border-emerald-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Settings & Logo Saved!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 text-xs">
        {/* 1. Website Branding & Logo (Dedicated Section) */}
        <div id="logo-section" className="bg-white p-5 sm:p-6 rounded-2xl border border-zinc-200 shadow-sm space-y-5">
          <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-red-600 flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-red-600" />
                <span>1. Website Branding — Shop Logo</span>
              </h3>
              <p className="text-[11px] text-zinc-500 mt-0.5">
                Upload your official <strong>Bist Sticker and Accessories</strong> logo. Supports PNG with transparent background, JPG, WebP, SVG.
              </p>
            </div>
            {formData.logoUrl ? (
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-1 rounded-full uppercase border border-emerald-200">
                Custom Logo Active
              </span>
            ) : (
              <span className="bg-amber-100 text-amber-800 text-[10px] font-black px-2.5 py-1 rounded-full uppercase border border-amber-200">
                Default Badge Mode
              </span>
            )}
          </div>

          {/* Logo Live Preview Cards (Dark & Light) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Dark Header / Footer Preview */}
            <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 relative flex flex-col items-center justify-center min-h-[130px] overflow-hidden group">
              <span className="absolute top-2 left-2 text-[9px] font-extrabold uppercase tracking-widest text-zinc-400 bg-zinc-900/90 px-2 py-0.5 rounded border border-zinc-800">
                Header & Footer Preview (Dark)
              </span>

              {formData.logoUrl ? (
                <div className="mt-4 flex items-center justify-center p-2">
                  <img
                    src={formData.logoUrl}
                    alt="Logo Header Preview"
                    className="max-h-14 w-auto object-contain transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
              ) : (
                <div className="mt-4 text-center">
                  <span className="text-sm font-black text-white uppercase tracking-tight block">
                    BIST STICKER
                  </span>
                  <span className="text-[10px] font-black text-red-500 tracking-widest uppercase block">
                    & ACCESSORIES
                  </span>
                </div>
              )}
            </div>

            {/* Light Surface Preview */}
            <div className="bg-zinc-100/90 p-4 rounded-xl border border-zinc-300/80 relative flex flex-col items-center justify-center min-h-[130px] overflow-hidden group">
              <span className="absolute top-2 left-2 text-[9px] font-extrabold uppercase tracking-widest text-zinc-600 bg-white px-2 py-0.5 rounded border border-zinc-300">
                Light Background Preview
              </span>

              {formData.logoUrl ? (
                <div className="mt-4 flex items-center justify-center p-2">
                  <img
                    src={formData.logoUrl}
                    alt="Logo Light Preview"
                    className="max-h-14 w-auto object-contain transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
              ) : (
                <div className="mt-4 text-center">
                  <span className="text-sm font-black text-zinc-900 uppercase tracking-tight block">
                    BIST STICKER
                  </span>
                  <span className="text-[10px] font-black text-red-600 tracking-widest uppercase block">
                    & ACCESSORIES
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons: Upload & Remove */}
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <input
              type="file"
              ref={logoInputRef}
              accept="image/png,image/jpeg,image/webp,image/svg+xml"
              onChange={(e) => {
                const file = e.target.files?.[0];
                e.target.value = '';
                if (file) handleLogoUpload(file);
              }}
              className="hidden"
            />

            <button
              type="button"
              onClick={() => logoInputRef.current?.click()}
              disabled={isUploadingLogo}
              className="flex items-center gap-2 bg-red-600 hover:bg-red-700 active:scale-95 text-white font-extrabold px-4 py-2.5 rounded-xl shadow transition-all duration-200 uppercase tracking-wider text-xs"
            >
              {isUploadingLogo ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Uploading Logo... {logoProgress !== null ? `${logoProgress}%` : ''}</span>
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  <span>{formData.logoUrl ? 'Replace Logo from Mobile / PC' : 'Upload Logo from Mobile / PC'}</span>
                </>
              )}
            </button>

            {formData.logoUrl && (
              <button
                type="button"
                onClick={handleRemoveLogo}
                className="flex items-center gap-1.5 bg-zinc-100 hover:bg-red-50 text-red-600 hover:text-red-700 border border-zinc-200 hover:border-red-200 px-3.5 py-2.5 rounded-xl font-bold transition-all duration-200 active:scale-95"
              >
                <Trash2 className="w-4 h-4" />
                <span>Remove Logo</span>
              </button>
            )}
          </div>

          {isUploadingLogo && logoProgress !== null && (
            <div className="w-full bg-zinc-100 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-red-600 h-1.5 rounded-full transition-all duration-300"
                style={{ width: `${logoProgress}%` }}
              />
            </div>
          )}

          {uploadError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl space-y-2 text-red-700 text-xs">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
                <div className="flex-1 font-semibold break-words">{uploadError}</div>
              </div>
            </div>
          )}

          {/* Direct URL Field for manual paste */}
          <div className="pt-2 border-t border-zinc-100">
            <label className="block font-bold uppercase text-zinc-600 mb-1 text-[11px]">
              Logo Image URL (Optional Direct Paste)
            </label>
            <input
              type="text"
              placeholder="e.g. https://images.unsplash.com/... or https://..."
              value={formData.logoUrl || ''}
              onChange={(e) => handleChange('logoUrl', e.target.value)}
              className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2 font-mono text-xs focus:ring-2 focus:ring-red-500/20"
            />
          </div>
        </div>

        {/* 2. Basic Business Identification */}
        <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-sm space-y-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-red-600 border-b border-zinc-100 pb-2">
            2. Business Identification
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold uppercase text-zinc-700 mb-1">Shop Name *</label>
              <input
                type="text"
                required
                value={formData.shopName || ''}
                onChange={(e) => handleChange('shopName', e.target.value)}
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 font-bold"
              />
            </div>

            <div>
              <label className="block font-bold uppercase text-zinc-700 mb-1">Tagline</label>
              <input
                type="text"
                value={formData.tagline || ''}
                onChange={(e) => handleChange('tagline', e.target.value)}
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5"
              />
            </div>
          </div>
        </div>

        {/* 3. Contact & WhatsApp */}
        <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-sm space-y-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-red-600 border-b border-zinc-100 pb-2">
            3. Contact & WhatsApp Configuration
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-bold uppercase text-zinc-700 mb-1">Phone Number</label>
              <input
                type="text"
                value={formData.phone || ''}
                onChange={(e) => handleChange('phone', e.target.value)}
                placeholder="e.g. 9848419968"
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 font-mono"
              />
            </div>

            <div>
              <label className="block font-bold uppercase text-zinc-700 mb-1">
                WhatsApp Int. Format *
              </label>
              <input
                type="text"
                required
                value={formData.whatsappNumber || ''}
                onChange={(e) => handleChange('whatsappNumber', e.target.value)}
                placeholder="e.g. 9779848419968"
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 font-mono font-bold text-emerald-700"
              />
            </div>

            <div>
              <label className="block font-bold uppercase text-zinc-700 mb-1">
                WhatsApp Display Format
              </label>
              <input
                type="text"
                value={formData.whatsappDisplay || ''}
                onChange={(e) => handleChange('whatsappDisplay', e.target.value)}
                placeholder="e.g. 9848419968"
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold uppercase text-zinc-700 mb-1">Shop Address</label>
              <input
                type="text"
                value={formData.address || ''}
                onChange={(e) => handleChange('address', e.target.value)}
                placeholder="Main Chowk, Attariya, Kailali"
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5"
              />
            </div>

            <div>
              <label className="block font-bold uppercase text-zinc-700 mb-1">Opening Hours</label>
              <input
                type="text"
                value={formData.openingHours || ''}
                onChange={(e) => handleChange('openingHours', e.target.value)}
                placeholder="Sun - Fri: 8:00 AM - 7:00 PM"
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5"
              />
            </div>
          </div>
        </div>

        {/* 4. About & Footer Info */}
        <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-sm space-y-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-red-600 border-b border-zinc-100 pb-2">
            4. About Us & Footer Text
          </h3>

          <div>
            <label className="block font-bold uppercase text-zinc-700 mb-1">About Us Description</label>
            <textarea
              rows={3}
              value={formData.aboutText || ''}
              onChange={(e) => handleChange('aboutText', e.target.value)}
              className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5"
            />
          </div>

          <div>
            <label className="block font-bold uppercase text-zinc-700 mb-1">Footer Description</label>
            <input
              type="text"
              value={formData.footerText || ''}
              onChange={(e) => handleChange('footerText', e.target.value)}
              className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5"
            />
          </div>

          <div>
            <label className="block font-bold uppercase text-zinc-700 mb-1">Google Maps Embed URL</label>
            <input
              type="text"
              value={formData.googleMapsEmbedUrl || ''}
              onChange={(e) => handleChange('googleMapsEmbedUrl', e.target.value)}
              placeholder="https://www.google.com/maps/embed?pb=..."
              className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 font-mono text-[11px]"
            />
          </div>
        </div>

        {/* 5. Social Links */}
        <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-sm space-y-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-red-600 border-b border-zinc-100 pb-2">
            5. Social Media Links
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-bold uppercase text-zinc-700 mb-1">Facebook URL</label>
              <input
                type="text"
                value={formData.facebookUrl || ''}
                onChange={(e) => handleChange('facebookUrl', e.target.value)}
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5"
              />
            </div>

            <div>
              <label className="block font-bold uppercase text-zinc-700 mb-1">TikTok URL</label>
              <input
                type="text"
                value={formData.tiktokUrl || ''}
                onChange={(e) => handleChange('tiktokUrl', e.target.value)}
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5"
              />
            </div>

            <div>
              <label className="block font-bold uppercase text-zinc-700 mb-1">Instagram URL</label>
              <input
                type="text"
                value={formData.instagramUrl || ''}
                onChange={(e) => handleChange('instagramUrl', e.target.value)}
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5"
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-black text-xs px-6 py-3.5 rounded-xl shadow-xl transition-all duration-200 hover:scale-102 active:scale-98 uppercase tracking-wider"
          >
            <Save className="w-4 h-4" />
            <span>Save Store Settings & Logo</span>
          </button>
        </div>
      </form>
    </div>
  );
};

