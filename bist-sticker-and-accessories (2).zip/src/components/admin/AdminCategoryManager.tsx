import React, { useState } from 'react';
import { Plus, Edit3, Trash2, Upload, X, AlertTriangle, RefreshCw, CheckCircle2, HardDrive } from 'lucide-react';
import { Category } from '../../types';
import { uploadImageFile, deleteStorageImage } from '../../lib/storage';
import { GoogleDriveImagePicker } from './GoogleDriveImagePicker';

interface AdminCategoryManagerProps {
  categories: Category[];
  onSaveCategory: (category: Category) => void;
  onDeleteCategory: (categoryId: string) => void;
  isAddModalOpenInitially?: boolean;
}

export const AdminCategoryManager: React.FC<AdminCategoryManagerProps> = ({
  categories,
  onSaveCategory,
  onDeleteCategory,
  isAddModalOpenInitially = false,
}) => {
  const [editingCategory, setEditingCategory] = useState<Partial<Category> | null>(
    isAddModalOpenInitially ? createEmptyCategory() : null
  );
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Upload state
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'uploaded' | 'error'>('idle');
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isDrivePickerOpen, setIsDrivePickerOpen] = useState(false);

  function createEmptyCategory(): Partial<Category> {
    return {
      id: `cat_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: '',
      slug: '',
      description: '',
      image: 'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?w=600',
    };
  }

  const openCategoryModal = (cat?: Partial<Category>) => {
    setEditingCategory(cat || createEmptyCategory());
    setUploadStatus('idle');
    setUploadProgress(null);
    setUploadError(null);
  };

  const closeCategoryModal = () => {
    setEditingCategory(null);
    setUploadStatus('idle');
    setUploadProgress(null);
    setUploadError(null);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';

    // Validate file
    if (!file.type.startsWith('image/')) {
      setUploadStatus('error');
      setUploadError('Image upload failed: Selected file must be an image (JPG, PNG, WebP, etc.).');
      return;
    }

    setUploadStatus('uploading');
    setUploadProgress(0);
    setUploadError(null);

    const oldStoragePath = editingCategory?.storagePath;
    const docId = editingCategory?.id || `cat_${Date.now()}`;

    try {
      // 1. Upload new image first to Firebase Storage with real-time progress
      const res = await uploadImageFile(file, 'categories', docId, (progress) => {
        setUploadProgress(progress);
      });

      // 2. Save new imageUrl and storagePath in local form state
      setEditingCategory((prev) => ({
        ...prev,
        image: res.url,
        storagePath: res.storagePath,
      }));

      setUploadStatus('uploaded');
      setUploadProgress(100);

      // 3. Keep old image until upload succeeds, then delete old Storage object safely
      if (oldStoragePath && oldStoragePath !== res.storagePath) {
        deleteStorageImage(oldStoragePath);
      }
    } catch (err: any) {
      console.error('[CATEGORY_IMAGE_UPLOAD_ERROR]', err);
      const errMsg = err?.message || String(err || 'Unknown error');
      setUploadStatus('error');
      setUploadProgress(null);
      setUploadError(errMsg.startsWith('Image upload failed:') ? errMsg : `Image upload failed: ${errMsg}`);
    } finally {
      if (e.target) {
        e.target.value = '';
      }
    }
  };

  const handleRemoveImage = () => {
    setEditingCategory((prev) => ({
      ...prev,
      image: '',
      storagePath: undefined,
    }));
    setUploadStatus('idle');
    setUploadProgress(null);
    setUploadError(null);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (uploadStatus === 'uploading') return;

    if (!editingCategory?.name) {
      alert('Please enter category name.');
      return;
    }

    const finalCat: Category = {
      id: editingCategory.id || `cat_${Date.now()}`,
      name: editingCategory.name,
      slug: editingCategory.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      description: editingCategory.description || '',
      image: editingCategory.image || 'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?w=600',
      storagePath: editingCategory.storagePath,
    };

    onSaveCategory(finalCat);
    closeCategoryModal();
  };

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6 text-zinc-900">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-zinc-200 shadow-sm">
        <div>
          <h2 className="text-xl font-black uppercase font-sans tracking-tight">
            Category Manager ({categories.length})
          </h2>
          <p className="text-xs text-zinc-500 mt-0.5">
            Organize products under Bike Stickers, Helmets, PPF, Neon Sign Boards, etc.
          </p>
        </div>

        <button
          onClick={() => openCategoryModal()}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white text-xs font-black px-4 py-2.5 rounded-xl shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>Add Category</span>
        </button>
      </div>

      {/* Grid of Categories */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {categories.map((cat) => (
          <div
            key={cat.id}
            className="bg-white border border-zinc-200 rounded-2xl p-4 shadow-sm flex flex-col justify-between space-y-3"
          >
            <div className="space-y-3">
              <img
                src={cat.image}
                alt={cat.name}
                className="w-full h-32 object-cover rounded-xl border border-zinc-200"
              />
              <div>
                <h3 className="text-sm font-black uppercase text-zinc-950">{cat.name}</h3>
                <p className="text-xs text-zinc-500 line-clamp-2 mt-1">{cat.description}</p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-100">
              <button
                onClick={() => openCategoryModal(cat)}
                className="p-2 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-800 transition"
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setDeleteConfirmId(cat.id)}
                className="p-2 rounded-lg bg-red-50 hover:bg-red-600 hover:text-white text-red-600 transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black uppercase text-zinc-900">Delete Category?</h3>
            <p className="text-xs text-zinc-500">
              Deleting this category will remove its group view from storefront filters.
            </p>
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 py-2.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteCategory(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Category Modal */}
      {editingCategory && (
        <div className="fixed inset-0 z-50 bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl relative text-zinc-900 border border-zinc-200">
            <button
              onClick={closeCategoryModal}
              className="absolute top-4 right-4 p-2 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-600"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-black uppercase font-sans tracking-tight mb-4">
              {editingCategory.id && categories.some((c) => c.id === editingCategory.id)
                ? 'Edit Category'
                : 'Add Category'}
            </h3>

            <form onSubmit={handleFormSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold uppercase text-zinc-700 mb-1">
                  Category Name *
                </label>
                <input
                  type="text"
                  required
                  value={editingCategory.name || ''}
                  onChange={(e) =>
                    setEditingCategory({ ...editingCategory, name: e.target.value })
                  }
                  placeholder="e.g. Radium / Reflective Stickers"
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div>
                <label className="block font-bold uppercase text-zinc-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={editingCategory.description || ''}
                  onChange={(e) =>
                    setEditingCategory({ ...editingCategory, description: e.target.value })
                  }
                  placeholder="Short description of products in this category..."
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div>
                <label className="block font-bold uppercase text-zinc-700 mb-1">Category Image</label>
                <div className="flex items-center gap-3 mb-2">
                  {editingCategory.image ? (
                    <div className="relative w-20 h-20 rounded-xl overflow-hidden border border-zinc-300 group shrink-0 bg-zinc-50">
                      <img
                        src={editingCategory.image}
                        alt="Category Preview"
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={handleRemoveImage}
                        title="Remove image"
                        className="absolute top-1 right-1 bg-red-600 hover:bg-red-700 text-white p-1 rounded-full shadow transition"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="w-20 h-20 rounded-xl bg-zinc-100 border border-zinc-300 flex items-center justify-center shrink-0">
                      <span className="text-xs text-zinc-400 font-bold">No Image</span>
                    </div>
                  )}

                  <div className="flex-1 space-y-2">
                    <label
                      className={`w-full py-3 px-3 border-2 border-dashed rounded-xl flex items-center justify-center gap-2 cursor-pointer transition ${
                        uploadStatus === 'uploading'
                          ? 'border-red-400 bg-red-50/50 cursor-wait'
                          : uploadStatus === 'uploaded'
                          ? 'border-emerald-500 bg-emerald-50'
                          : 'border-zinc-300 hover:border-red-600 bg-zinc-50'
                      }`}
                    >
                      {uploadStatus === 'uploading' ? (
                        <RefreshCw className="w-4 h-4 text-red-600 animate-spin shrink-0" />
                      ) : uploadStatus === 'uploaded' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : (
                        <Upload className="w-4 h-4 text-zinc-600 shrink-0" />
                      )}

                      <span className="font-bold text-xs sm:text-sm text-zinc-800">
                        {uploadStatus === 'uploading'
                          ? `Uploading... ${uploadProgress !== null ? `${uploadProgress}%` : '0%'}`
                          : uploadStatus === 'uploaded'
                          ? 'Uploaded ✓'
                          : editingCategory.image
                          ? 'Replace Image File'
                          : 'Upload Image File'}
                      </span>

                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                        disabled={uploadStatus === 'uploading'}
                      />
                    </label>

                    <button
                      type="button"
                      onClick={() => setIsDrivePickerOpen(true)}
                      className="w-full py-2 px-3 bg-blue-50 border border-blue-200 hover:bg-blue-100 text-blue-700 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition"
                    >
                      <HardDrive className="w-4 h-4 text-blue-600" />
                      <span>Pick from Google Drive</span>
                    </button>

                    {/* Progress Bar when uploading */}
                    {uploadStatus === 'uploading' && uploadProgress !== null && (
                      <div className="w-full bg-zinc-200 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="bg-red-600 h-1.5 rounded-full transition-all duration-300"
                          style={{ width: `${uploadProgress}%` }}
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Display Upload Error if any */}
                {uploadError && (
                  <div className="mb-3 p-3 bg-red-50 border border-red-200 rounded-xl space-y-2 text-red-700 text-xs">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
                      <div className="flex-1 font-semibold break-words">{uploadError}</div>
                    </div>
                  </div>
                )}

                <input
                  type="text"
                  placeholder="Or paste hosted image URL (Unsplash, HTTP...)"
                  value={editingCategory.image || ''}
                  onChange={(e) => {
                    setEditingCategory({ ...editingCategory, image: e.target.value });
                    setUploadStatus('idle');
                    setUploadError(null);
                  }}
                  className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div className="pt-4 border-t border-zinc-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={closeCategoryModal}
                  className="px-4 py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={uploadStatus === 'uploading'}
                  className={`px-5 py-2 font-black rounded-xl shadow transition ${
                    uploadStatus === 'uploading'
                      ? 'bg-zinc-300 text-zinc-500 cursor-not-allowed'
                      : 'bg-red-600 hover:bg-red-700 text-white'
                  }`}
                >
                  {uploadStatus === 'uploading' ? 'Uploading Image...' : 'Save Category'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Google Drive Image Picker Modal */}
      <GoogleDriveImagePicker
        isOpen={isDrivePickerOpen}
        onClose={() => setIsDrivePickerOpen(false)}
        onSelectImage={(dataUrl) => {
          setEditingCategory((prev) => ({
            ...prev,
            image: dataUrl,
          }));
          setUploadStatus('uploaded');
        }}
      />
    </div>
  );
};
