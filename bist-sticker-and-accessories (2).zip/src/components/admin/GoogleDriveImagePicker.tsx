import React, { useState, useEffect } from 'react';
import { X, Search, Image as ImageIcon, Loader2, LogIn, ExternalLink, Check } from 'lucide-react';
import { googleDriveSignIn, listDriveFiles, getDriveFileAsDataUrl, getDriveAccessToken, DriveFile } from '../../lib/googleDrive';

interface GoogleDriveImagePickerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectImage: (dataUrl: string) => void;
}

export const GoogleDriveImagePicker: React.FC<GoogleDriveImagePickerProps> = ({
  isOpen,
  onClose,
  onSelectImage,
}) => {
  const [token, setToken] = useState<string | null>(getDriveAccessToken());
  const [loading, setLoading] = useState<boolean>(false);
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && token) {
      loadDriveImages();
    }
  }, [isOpen, token]);

  const handleSignIn = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await googleDriveSignIn();
      if (res?.accessToken) {
        setToken(res.accessToken);
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to sign in with Google');
    } finally {
      setLoading(false);
    }
  };

  const loadDriveImages = async () => {
    setLoading(true);
    setError(null);
    try {
      // Filter for image mimeTypes
      const res = await listDriveFiles(searchQuery);
      const imageFiles = res.files.filter((f) => 
        f.mimeType.startsWith('image/') || 
        f.mimeType === 'application/vnd.google-apps.photo'
      );
      setFiles(imageFiles);
    } catch (err: any) {
      setError(err?.message || 'Failed to fetch files from Google Drive');
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = async (file: DriveFile) => {
    setDownloadingId(file.id);
    try {
      const dataUrl = await getDriveFileAsDataUrl(file.id);
      onSelectImage(dataUrl);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to download image from Google Drive');
    } finally {
      setDownloadingId(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400">
              <ImageIcon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">Select Image from Google Drive</h3>
              <p className="text-xs text-slate-400">Pick an image file directly from your connected Google Drive</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex-1 overflow-y-auto space-y-4">
          {!token ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="w-16 h-16 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-400 mb-4 border border-blue-500/20">
                <ImageIcon className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-medium text-white mb-2">Connect Google Drive</h4>
              <p className="text-sm text-slate-400 max-w-md mb-6">
                Sign in with your Google account to access and select image files stored in your Google Drive with your permission.
              </p>
              <button
                onClick={handleSignIn}
                disabled={loading}
                className="flex items-center gap-3 px-6 py-3 bg-white text-slate-900 hover:bg-slate-100 font-medium rounded-xl shadow-lg transition-all disabled:opacity-50"
              >
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <svg className="w-5 h-5" viewBox="0 0 48 48">
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                  </svg>
                )}
                <span>Sign in with Google</span>
              </button>
            </div>
          ) : (
            <>
              {/* Search Bar */}
              <div className="flex items-center gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search images in Google Drive..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && loadDriveImages()}
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-blue-500"
                  />
                </div>
                <button
                  onClick={loadDriveImages}
                  disabled={loading}
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-medium text-sm rounded-xl transition-colors disabled:opacity-50 flex items-center gap-2"
                >
                  {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                  Search
                </button>
              </div>

              {error && (
                <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-400">
                  {error}
                </div>
              )}

              {loading ? (
                <div className="flex flex-col items-center justify-center py-12 text-slate-400 gap-3">
                  <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
                  <span className="text-sm">Fetching files from Google Drive...</span>
                </div>
              ) : files.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-sm">
                  No image files found in your Google Drive.
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 pt-2">
                  {files.map((file) => (
                    <div
                      key={file.id}
                      onClick={() => handleSelect(file)}
                      className="group relative bg-slate-950 border border-slate-800 rounded-xl p-3 hover:border-blue-500/50 hover:bg-slate-900 transition-all cursor-pointer flex flex-col justify-between"
                    >
                      <div className="aspect-square rounded-lg bg-slate-900 border border-slate-800/80 overflow-hidden mb-3 flex items-center justify-center relative">
                        {file.thumbnailLink ? (
                          <img
                            src={file.thumbnailLink}
                            alt={file.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <ImageIcon className="w-8 h-8 text-slate-600" />
                        )}

                        {downloadingId === file.id && (
                          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center">
                            <Loader2 className="w-6 h-6 animate-spin text-blue-400" />
                          </div>
                        )}
                      </div>

                      <div className="space-y-1">
                        <p className="text-xs font-medium text-white truncate" title={file.name}>
                          {file.name}
                        </p>
                        <p className="text-[10px] text-slate-500 truncate">
                          {file.size ? `${(parseInt(file.size) / 1024).toFixed(0)} KB` : 'Drive Asset'}
                        </p>
                      </div>

                      <div className="mt-2 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-blue-400 group-hover:text-blue-300">
                        <span>Select</span>
                        <Check className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
