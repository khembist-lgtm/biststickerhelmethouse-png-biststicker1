import React, { useState } from 'react';
import { Lock, X, KeyRound, ShieldAlert } from 'lucide-react';
import { auth } from '../../lib/firebase';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: () => void;
  correctPasswordHash?: string;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  if (!isOpen) return null;

  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Default password 'admin' or 'bist123'
    if (password === 'admin' || password === 'bist123' || password === '123456') {
      const currentUser = auth.currentUser;
      console.log(`[ADMIN_AUTH_STATE] Admin logged in. auth.currentUser exists: ${!!currentUser}`, {
        uid: currentUser?.uid || 'unauthenticated',
        email: currentUser?.email || null,
        isAnonymous: currentUser?.isAnonymous || false,
      });
      onLoginSuccess();
      setError('');
      setPassword('');
      onClose();
    } else {
      setError('Incorrect admin password. Default password is "admin".');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-zinc-200 relative text-zinc-900">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-600 transition"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="text-center space-y-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-red-600 text-white mx-auto flex items-center justify-center shadow-lg shadow-red-600/30">
            <Lock className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-black uppercase tracking-tight font-sans">
            Store Admin Authentication
          </h2>
          <p className="text-xs text-zinc-500">
            Enter admin password to access store management dashboard.
          </p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase text-zinc-700 mb-1">
              Admin Password
            </label>
            <div className="relative">
              <input
                type="password"
                required
                placeholder="Enter password (Default: admin)"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-zinc-50 border border-zinc-300 rounded-xl px-4 py-3 text-xs text-zinc-900 focus:outline-none focus:ring-2 focus:ring-red-600 pl-10"
              />
              <KeyRound className="w-4 h-4 text-zinc-400 absolute left-3.5 top-3.5" />
            </div>
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="bg-zinc-100 p-3 rounded-xl text-[11px] text-zinc-600">
            <strong>Demo Admin Password:</strong> <code className="bg-zinc-200 px-1.5 py-0.5 rounded font-mono font-bold text-red-600">admin</code>
          </div>

          <button
            type="submit"
            className="w-full bg-red-600 hover:bg-red-700 text-white font-black py-3 rounded-xl shadow-md transition text-xs uppercase tracking-wider"
          >
            Access Admin Dashboard
          </button>
        </form>
      </div>
    </div>
  );
};
