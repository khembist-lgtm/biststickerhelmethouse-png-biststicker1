import React from 'react';
import { 
  Package, 
  Layers, 
  Image as ImageIcon, 
  Settings, 
  ShoppingBag, 
  Eye, 
  Plus, 
  RotateCcw, 
  LogOut, 
  TrendingUp,
  Sparkles,
  Database,
  HardDrive
} from 'lucide-react';
import { AppDataStore } from '../../types';
import { formatNPR } from '../../lib/api';

interface AdminDashboardProps {
  storeData: AppDataStore;
  activeTab: 'overview' | 'products' | 'categories' | 'hero' | 'settings' | 'backups' | 'drive';
  setActiveTab: (tab: 'overview' | 'products' | 'categories' | 'hero' | 'settings' | 'backups' | 'drive') => void;
  onExitAdmin: () => void;
  onResetDemo: () => void;
  onOpenAddProduct: () => void;
  onOpenAddCategory: () => void;
  onOpenAddSlide: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  storeData,
  activeTab,
  setActiveTab,
  onExitAdmin,
  onResetDemo,
  onOpenAddProduct,
  onOpenAddCategory,
  onOpenAddSlide,
}) => {
  const totalProducts = storeData.products.length;
  const activeProducts = storeData.products.filter((p) => p.isActive).length;
  const totalCategories = storeData.categories.length;
  const totalSlides = storeData.heroSlides.length;
  const totalOrders = storeData.orders.length;
  const totalPageViews = storeData.pageViews || 150;

  return (
    <div className="bg-zinc-900 text-white border-b border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 py-4">
        {/* Top Header Bar */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            {storeData.settings.logoUrl && storeData.settings.logoUrl.trim() !== '' ? (
              <img
                src={storeData.settings.logoUrl}
                alt={storeData.settings.shopName}
                className="h-10 w-auto max-w-[130px] object-contain rounded-xl bg-zinc-950 p-1 border border-zinc-800 shadow"
              />
            ) : (
              <div className="w-9 h-9 rounded-xl bg-red-600 text-white flex items-center justify-center font-black shadow-md shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
            )}
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black uppercase tracking-tight font-sans">
                  {storeData.settings.shopName} — Admin Editor
                </h2>
                <span className="text-[10px] bg-amber-500/20 text-amber-400 border border-amber-500/30 font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
                  Firebase Cloud Active
                </span>
              </div>
              <p className="text-[11px] text-zinc-400">
                Manage products, categories, hero banner slides & store contact settings in real-time.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              onClick={onResetDemo}
              className="flex items-center gap-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold px-3 py-1.5 rounded-lg border border-zinc-700 transition"
              title="Reset all store data to default demo products"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Demo Data</span>
            </button>

            <button
              onClick={onExitAdmin}
              className="flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Exit Admin</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 overflow-x-auto pt-3 no-scrollbar">
          {[
            { id: 'overview', label: 'Dashboard Overview', icon: TrendingUp },
            { id: 'products', label: `Products (${totalProducts})`, icon: Package },
            { id: 'categories', label: `Categories (${totalCategories})`, icon: Layers },
            { id: 'hero', label: `Hero Slides (${totalSlides})`, icon: ImageIcon },
            { id: 'settings', label: 'Store Settings', icon: Settings },
            { id: 'drive', label: 'Google Drive', icon: HardDrive },
            { id: 'backups', label: 'Database & Backups', icon: Database },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                  isActive
                    ? 'bg-red-600 text-white shadow'
                    : 'bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Overview Widgets Section */}
        {activeTab === 'overview' && (
          <div className="mt-6 space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800">
                <span className="text-[10px] font-extrabold uppercase text-zinc-400 block">Total Products</span>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="text-2xl font-black text-white">{totalProducts}</span>
                  <span className="text-[10px] text-emerald-400 font-bold">{activeProducts} Active</span>
                </div>
              </div>

              <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800">
                <span className="text-[10px] font-extrabold uppercase text-zinc-400 block">Categories</span>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="text-2xl font-black text-white">{totalCategories}</span>
                  <span className="text-[10px] text-zinc-400 font-bold">Categories</span>
                </div>
              </div>

              <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800">
                <span className="text-[10px] font-extrabold uppercase text-zinc-400 block">Hero Slides</span>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="text-2xl font-black text-white">{totalSlides}</span>
                  <span className="text-[10px] text-red-400 font-bold">Banner</span>
                </div>
              </div>

              <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800">
                <span className="text-[10px] font-extrabold uppercase text-zinc-400 block">WhatsApp Orders</span>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="text-2xl font-black text-emerald-400">{totalOrders}</span>
                  <span className="text-[10px] text-zinc-400 font-bold">Logged</span>
                </div>
              </div>

              <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800">
                <span className="text-[10px] font-extrabold uppercase text-zinc-400 block">Store Visits</span>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="text-2xl font-black text-amber-400">{totalPageViews}</span>
                  <span className="text-[10px] text-zinc-400 font-bold">Views</span>
                </div>
              </div>
            </div>

            {/* Quick Actions Bar */}
            <div className="bg-zinc-950 p-5 rounded-2xl border border-zinc-800 flex flex-wrap items-center justify-between gap-4">
              <div className="space-y-1">
                <h4 className="text-xs font-black text-white uppercase">Quick Content Actions</h4>
                <p className="text-[11px] text-zinc-400">
                  Add new inventory items, categories, or banner slides instantly.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={onOpenAddProduct}
                  className="flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold px-3.5 py-2 rounded-xl shadow transition"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Product</span>
                </button>

                <button
                  onClick={onOpenAddCategory}
                  className="flex items-center gap-1.5 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition border border-zinc-700"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Category</span>
                </button>

                <button
                  onClick={onOpenAddSlide}
                  className="flex items-center gap-1.5 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition border border-zinc-700"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Hero Slide</span>
                </button>
              </div>
            </div>

            {/* Recent WhatsApp Orders Log */}
            {storeData.orders && storeData.orders.length > 0 && (
              <div className="bg-zinc-950 p-5 rounded-2xl border border-zinc-800 space-y-3">
                <h4 className="text-xs font-black uppercase text-white tracking-wider flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4 text-emerald-400" />
                  <span>Recent WhatsApp Orders ({storeData.orders.length})</span>
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-zinc-900 text-zinc-400 uppercase font-bold text-[10px]">
                      <tr>
                        <th className="p-2.5">Customer</th>
                        <th className="p-2.5">Phone</th>
                        <th className="p-2.5">Location</th>
                        <th className="p-2.5">Items</th>
                        <th className="p-2.5">Total</th>
                        <th className="p-2.5">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-900 text-zinc-300">
                      {storeData.orders.slice(0, 5).map((ord) => (
                        <tr key={ord.id} className="hover:bg-zinc-900/50">
                          <td className="p-2.5 font-bold text-white">{ord.customerName}</td>
                          <td className="p-2.5">{ord.customerPhone}</td>
                          <td className="p-2.5">{ord.deliveryAddress}, {ord.cityArea}</td>
                          <td className="p-2.5 font-mono">{ord.items?.length || 0} items</td>
                          <td className="p-2.5 font-black text-emerald-400">{formatNPR(ord.totalAmount)}</td>
                          <td className="p-2.5 text-zinc-500">{new Date(ord.createdAt).toLocaleDateString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
