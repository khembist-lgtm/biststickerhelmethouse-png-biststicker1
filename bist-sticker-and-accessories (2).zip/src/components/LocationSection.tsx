import React from 'react';
import { MapPin, Phone, Clock, MessageCircle } from 'lucide-react';
import { SiteSettings } from '../types';
import { formatWhatsAppUrl } from '../lib/api';

interface LocationSectionProps {
  settings: SiteSettings;
}

export const LocationSection: React.FC<LocationSectionProps> = ({ settings }) => {
  const directWhatsAppUrl = formatWhatsAppUrl(
    settings.whatsappNumber,
    `Hello ${settings.shopName}, I am visiting your shop in Attariya and need directions.`
  );

  return (
    <section id="contact" className="py-16 sm:py-24 bg-[#1a1a1a] text-[#f8f7f4] relative overflow-hidden border-t border-[#f8f7f4]/15">
      <div className="max-w-[1600px] mx-auto px-6 sm:px-10 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          {/* Info Card Column */}
          <div className="lg:col-span-5 bg-[#242424] border-2 border-[#f8f7f4]/20 p-6 sm:p-8 flex flex-col justify-between space-y-8">
            <div className="space-y-6">
              <div className="font-mono-meta text-[11px] uppercase tracking-[0.2em] text-[#ff3300]">
                STUDIO LOCATION & HOURS
              </div>

              <h2 className="text-3xl sm:text-5xl font-black uppercase tracking-tighter font-sans leading-none text-[#f8f7f4]">
                Visit Bist Sticker Studio<span className="text-[#ff3300]">.</span>
              </h2>

              <p className="text-xs sm:text-sm text-[#f8f7f4]/70 leading-relaxed font-sans">
                Stop by our main shop in Attariya for custom bike sticker installations, helmet fittings, PPF wraps and motorcycle styling accessories.
              </p>

              <div className="space-y-4 pt-2 border-t border-[#f8f7f4]/15">
                <div className="flex items-start gap-3.5">
                  <div className="w-8 h-8 bg-[#1a1a1a] border border-[#f8f7f4]/20 flex items-center justify-center shrink-0 text-[#ff3300]">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="font-mono-meta text-[10px] uppercase text-[#f8f7f4]/50">Location / Address</h5>
                    <p className="text-xs font-bold text-[#f8f7f4] mt-0.5">{settings.address}, Nepal</p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-8 h-8 bg-[#1a1a1a] border border-[#f8f7f4]/20 flex items-center justify-center shrink-0 text-[#ff3300]">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="font-mono-meta text-[10px] uppercase text-[#f8f7f4]/50">Phone / Direct</h5>
                    <p className="text-xs font-bold text-[#f8f7f4] mt-0.5">{settings.phone}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-8 h-8 bg-[#1a1a1a] border border-[#f8f7f4]/20 flex items-center justify-center shrink-0 text-emerald-400">
                    <MessageCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="font-mono-meta text-[10px] uppercase text-[#f8f7f4]/50">WhatsApp Direct</h5>
                    <p className="text-xs font-bold text-[#f8f7f4] mt-0.5">{settings.whatsappDisplay}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-8 h-8 bg-[#1a1a1a] border border-[#f8f7f4]/20 flex items-center justify-center shrink-0 text-amber-400">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="font-mono-meta text-[10px] uppercase text-[#f8f7f4]/50">Opening Hours</h5>
                    <p className="text-xs font-bold text-[#f8f7f4] mt-0.5">{settings.openingHours}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-[#f8f7f4]/15">
              <a
                href={directWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 bg-[#ff3300] hover:bg-[#d92b00] text-white font-mono-meta text-[11px] font-bold uppercase tracking-widest py-3 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Get Directions on WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Google Maps Embed Frame */}
          <div className="lg:col-span-7 bg-[#242424] border-2 border-[#f8f7f4]/20 overflow-hidden min-h-[380px] relative">
            {settings.googleMapsEmbedUrl ? (
              <iframe
                title="Bist Sticker Location Map"
                src={settings.googleMapsEmbedUrl}
                className="w-full h-full min-h-[400px] border-0"
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            ) : (
              <div className="w-full h-full min-h-[400px] flex items-center justify-center bg-[#1a1a1a] text-[#f8f7f4]/60 font-mono-meta text-xs p-6 text-center">
                Map preview available once Google Maps embed URL is set in Admin.
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

