import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Category } from '../types';

interface CategoryCardProps {
  category: Category;
  onSelectCategory: (categoryName: string) => void;
}

export const CategoryCard: React.FC<CategoryCardProps> = ({ category, onSelectCategory }) => {
  return (
    <div className="group bg-[#f8f7f4] border-t-2 border-[#1a1a1a] pt-4 pb-2 flex flex-col justify-between transition-all duration-300">
      {/* Category Image with Hover Blend */}
      <div className="relative h-48 sm:h-52 overflow-hidden bg-[#e5e4e1] mb-4">
        <img
          src={category.image}
          alt={category.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out mix-blend-multiply opacity-95"
          loading="lazy"
        />
        <div className="absolute top-2 left-2 bg-[#1a1a1a] text-white px-2 py-0.5 font-mono-meta text-[9px] uppercase tracking-wider">
          LINE ITEM
        </div>
      </div>

      {/* Details */}
      <div className="space-y-2 flex-1 flex flex-col justify-between">
        <div>
          <h3 className="text-sm font-black text-[#1a1a1a] group-hover:text-[#ff3300] transition-colors duration-200 uppercase tracking-wider font-sans">
            {category.name}
          </h3>
          <p className="text-[11px] text-[#1a1a1a]/60 line-clamp-2 mt-1 leading-snug">
            {category.description}
          </p>
        </div>

        <button
          onClick={() => onSelectCategory(category.name)}
          className="inline-flex items-center gap-1.5 border-b border-[#1a1a1a] pb-0.5 text-[10px] font-black uppercase tracking-wider text-[#1a1a1a] group-hover:text-[#ff3300] group-hover:border-[#ff3300] transition-colors pt-2 cursor-pointer"
        >
          <span>Explore Collection</span>
          <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
};

