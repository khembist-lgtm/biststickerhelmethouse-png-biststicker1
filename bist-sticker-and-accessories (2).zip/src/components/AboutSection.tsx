import React from 'react';
import { ShieldCheck, Award, MapPin } from 'lucide-react';
import { SiteSettings } from '../types';

interface AboutSectionProps {
  settings: SiteSettings;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ settings }) => {
  return (
    <section id="about" className="py-16 sm:py-24 bg-[#1a1a1a] text-[#f8f7f4] relative overflow-hidden">
      <div className="max-w-[1600px] mx-auto px-6 sm:px-10 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
          {/* Image Frame */}
          <div className="lg:col-span-5 relative border-2 border-[#f8f7f4]/20 p-2 group bg-[#242424]">
            <img
              src={settings.aboutImage || 'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?w=800'}
              alt="Bist Sticker Workshop"
              className="w-full h-[380px] sm:h-[460px] object-cover mix-blend-luminosity group-hover:mix-blend-normal transition-all duration-700 opacity-90"
            />

            <div className="absolute bottom-4 left-4 right-4 p-4 bg-[#1a1a1a]/95 border border-[#f8f7f4]/20">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-[#ff3300] text-white flex items-center justify-center shrink-0 font-mono-meta font-black text-xs">
                  <Award className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-[#f8f7f4] uppercase tracking-wider font-sans">
                    Trusted Motorcycle Styling Hub
                  </h4>
                  <p className="text-[10px] text-[#f8f7f4]/60 font-mono-meta uppercase">Attariya, Kailali, Nepal</p>
                </div>
              </div>
            </div>
          </div>

          {/* Text Content */}
          <div className="lg:col-span-7 space-y-6">
            <div className="font-mono-meta text-[11px] uppercase tracking-[0.2em] text-[#ff3300]">
              STUDIO PHILOSOPHY
            </div>

            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-tighter font-sans leading-none text-[#f8f7f4]">
              {settings.shopName}<span className="text-[#ff3300]">.</span>
            </h2>

            <p className="text-[#f8f7f4]/80 text-sm sm:text-base leading-relaxed font-sans font-medium">
              {settings.aboutText}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-[#f8f7f4]/15">
              <div className="border-t-2 border-[#ff3300] pt-3">
                <ShieldCheck className="w-5 h-5 text-[#ff3300] mb-2" />
                <h5 className="text-xs font-black text-[#f8f7f4] uppercase tracking-wider font-sans">Industrial Vinyl & PPF</h5>
                <p className="text-[11px] text-[#f8f7f4]/60 mt-1 font-sans leading-snug">
                  Imported vinyl wraps, 3D resin tank pads, and certified safety helmets.
                </p>
              </div>

              <div className="border-t-2 border-[#f8f7f4] pt-3">
                <MapPin className="w-5 h-5 text-[#f8f7f4] mb-2" />
                <h5 className="text-xs font-black text-[#f8f7f4] uppercase tracking-wider font-sans">Prime Studio Hub</h5>
                <p className="text-[11px] text-[#f8f7f4]/60 mt-1 font-sans leading-snug">
                  Conveniently located at Main Chowk, Attariya, Kailali.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

