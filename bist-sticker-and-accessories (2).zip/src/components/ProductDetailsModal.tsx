import React, { useState } from 'react';
import { 
  X, 
  ShoppingCart, 
  MessageCircle, 
  Heart, 
  CheckCircle2, 
  Truck, 
  ShieldCheck, 
  Share2, 
  Sparkles,
  Plus,
  Minus
} from 'lucide-react';
import { Product, SiteSettings } from '../types';
import { formatNPR, formatWhatsAppUrl, generateProductWhatsAppMessage } from '../lib/api';

interface ProductDetailsModalProps {
  product: Product | null;
  onClose: () => void;
  settings: SiteSettings;
  onAddToCart: (product: Product, quantity: number) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
  relatedProducts: Product[];
  onSelectProduct: (product: Product) => void;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  product,
  onClose,
  settings,
  onAddToCart,
  onToggleWishlist,
  isWishlisted,
  relatedProducts,
  onSelectProduct,
}) => {
  if (!product) return null;

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [copied, setCopied] = useState(false);

  const images = product.images && product.images.length > 0
    ? product.images
    : ['https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=800'];

  const currentImage = images[activeImageIndex] || images[0];

  const whatsappMessage = generateProductWhatsAppMessage(settings.shopName, product);
  const whatsappUrl = formatWhatsAppUrl(settings.whatsappNumber, whatsappMessage);

  const handleCopyShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 md:p-6 animate-fadeIn">
      <div className="bg-white/95 backdrop-blur-2xl rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-zinc-200/80 relative text-zinc-900">
        {/* Sticky Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-zinc-100/90 hover:bg-red-600 hover:text-white transition-all duration-200 hover:scale-110 active:scale-95 shadow-md border border-zinc-200/80"
          aria-label="Close details modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 sm:p-8 lg:p-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
            {/* Gallery Column */}
            <div className="space-y-4">
              {/* Main Image Frame */}
              <div className="relative aspect-square rounded-2xl overflow-hidden bg-zinc-950/5 border border-zinc-200/80 shadow-inner group">
                <img
                  src={currentImage}
                  alt={product.name}
                  className="w-full h-full object-cover object-center transition-transform duration-500 ease-out group-hover:scale-108"
                />
                {product.discount && product.discount > 0 && (
                  <span className="absolute top-4 left-4 bg-red-600/90 text-white text-xs font-black px-3 py-1 rounded-full uppercase shadow-lg backdrop-blur-md border border-red-400/30 glow-red-sm">
                    {product.discount}% OFF
                  </span>
                )}
              </div>

              {/* Thumbnails */}
              {images.length > 1 && (
                <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar">
                  {images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIndex(idx)}
                      className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all duration-200 shrink-0 ${
                        activeImageIndex === idx ? 'border-red-600 scale-105 shadow-md glow-red-sm' : 'border-zinc-200/80 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Product Details Column */}
            <div className="flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                {/* Meta */}
                <div className="flex items-center justify-between text-xs font-bold text-zinc-500 uppercase tracking-wider">
                  <span className="text-red-600 font-extrabold bg-red-50/80 border border-red-100 px-3 py-1 rounded-full">
                    {product.category}
                  </span>
                  <span className="text-zinc-400 font-mono">SKU: {product.sku || 'N/A'}</span>
                </div>

                {/* Title */}
                <h1 className="text-xl sm:text-2xl lg:text-3xl font-black text-zinc-950 uppercase tracking-tight font-sans leading-snug">
                  {product.name}
                </h1>

                {/* Pricing & Stock */}
                <div className="flex items-center gap-4 bg-zinc-50/80 backdrop-blur-sm p-4 rounded-2xl border border-zinc-200/80 shadow-2xs">
                  <div>
                    <span className="text-2xl sm:text-3xl font-black text-zinc-950 font-sans tracking-tight">
                      {formatNPR(product.price)}
                    </span>
                    {product.oldPrice && product.oldPrice > product.price && (
                      <span className="ml-2 text-sm text-zinc-400 line-through font-medium">
                        {formatNPR(product.oldPrice)}
                      </span>
                    )}
                  </div>
                  <div className="ml-auto">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-black shadow-2xs ${
                        product.stockStatus === 'In Stock'
                          ? 'bg-emerald-100/90 text-emerald-800 border border-emerald-200'
                          : 'bg-amber-100/90 text-amber-800 border border-amber-200'
                      }`}
                    >
                      {product.stockStatus}
                    </span>
                  </div>
                </div>

                {/* Description */}
                <div>
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-zinc-400 mb-1">
                    Product Details
                  </h4>
                  <p className="text-xs sm:text-sm text-zinc-600 leading-relaxed font-normal">
                    {product.description}
                  </p>
                </div>

                {/* Highlights */}
                <div className="grid grid-cols-2 gap-2 text-xs font-semibold text-zinc-800 pt-2">
                  <div className="flex items-center gap-2 bg-zinc-50/80 p-2.5 rounded-xl border border-zinc-200/80">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Guaranteed Quality</span>
                  </div>
                  <div className="flex items-center gap-2 bg-zinc-50/80 p-2.5 rounded-xl border border-zinc-200/80">
                    <Truck className="w-4 h-4 text-red-600 shrink-0" />
                    <span>In-Store Pickup Attariya</span>
                  </div>
                </div>
              </div>

              {/* Order Controls */}
              <div className="space-y-4 pt-4 border-t border-zinc-200/80">
                {/* Quantity Selector */}
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold uppercase text-zinc-700">Quantity</span>
                  <div className="flex items-center border border-zinc-200/80 rounded-xl bg-zinc-50/90 p-1">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="p-1.5 hover:bg-zinc-200/80 rounded-lg transition-all duration-200 active:scale-90"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-4 h-4 text-zinc-700" />
                    </button>
                    <span className="px-4 text-sm font-black text-zinc-900">{quantity}</span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="p-1.5 hover:bg-zinc-200/80 rounded-lg transition-all duration-200 active:scale-90"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-4 h-4 text-zinc-700" />
                    </button>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      onAddToCart(product, quantity);
                      onClose();
                    }}
                    className="flex-1 flex items-center justify-center gap-2 bg-zinc-950 hover:bg-zinc-800 text-white font-black py-3.5 px-4 rounded-2xl shadow-xl transition-all duration-200 hover:scale-102 active:scale-98"
                  >
                    <ShoppingCart className="w-4 h-4 text-red-500" />
                    <span>Add To Cart</span>
                  </button>

                  <button
                    onClick={() => onToggleWishlist(product)}
                    className={`p-3.5 rounded-2xl border transition-all duration-200 hover:scale-105 active:scale-95 shadow-md ${
                      isWishlisted
                        ? 'bg-red-600 text-white border-red-600 glow-red-sm'
                        : 'bg-zinc-100 hover:bg-zinc-200 text-zinc-800 border-zinc-200/80'
                    }`}
                    title="Wishlist"
                  >
                    <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
                  </button>

                  <button
                    onClick={handleCopyShare}
                    className="p-3.5 rounded-2xl bg-zinc-100/90 hover:bg-zinc-200 text-zinc-800 border border-zinc-200/80 transition-all duration-200 hover:scale-105 active:scale-95 shadow-sm"
                    title="Share product link"
                  >
                    {copied ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> : <Share2 className="w-5 h-5" />}
                  </button>
                </div>

                {/* Direct WhatsApp Order */}
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold py-3.5 px-4 rounded-2xl shadow-xl transition-all duration-200 hover:scale-102 active:scale-98 border border-emerald-400/20"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Order Directly on WhatsApp</span>
                </a>
              </div>
            </div>
          </div>

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <div className="mt-12 pt-8 border-t border-zinc-200/80">
              <h3 className="text-lg font-black text-zinc-950 uppercase tracking-tight mb-4 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-red-600 animate-pulse" />
                <span>Related Products</span>
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {relatedProducts.slice(0, 4).map((rel) => (
                  <div
                    key={rel.id}
                    onClick={() => {
                      onSelectProduct(rel);
                      setActiveImageIndex(0);
                    }}
                    className="group bg-zinc-50/80 backdrop-blur-sm border border-zinc-200/80 rounded-2xl p-3 cursor-pointer hover:border-red-500/60 transition-all duration-300 hover:-translate-y-1 shadow-2xs hover:shadow-lg"
                  >
                    <img
                      src={rel.images?.[0] || 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=300'}
                      alt=""
                      className="w-full h-28 object-cover rounded-xl mb-2 group-hover:scale-108 transition-transform duration-300"
                    />
                    <h4 className="text-xs font-bold text-zinc-900 line-clamp-1 group-hover:text-red-600 transition-colors">
                      {rel.name}
                    </h4>
                    <span className="text-xs font-black text-zinc-950 mt-1 block">
                      {formatNPR(rel.price)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
