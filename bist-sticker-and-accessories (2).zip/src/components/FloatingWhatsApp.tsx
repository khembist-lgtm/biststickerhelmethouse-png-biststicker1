import React from 'react';
import { motion } from 'motion/react';
import { MessageCircle } from 'lucide-react';
import { SiteSettings } from '../types';
import { formatWhatsAppUrl } from '../lib/api';

interface FloatingWhatsAppProps {
  settings: SiteSettings;
}

export const FloatingWhatsApp: React.FC<FloatingWhatsAppProps> = ({ settings }) => {
  const directWhatsAppUrl = formatWhatsAppUrl(
    settings.whatsappNumber,
    `Hello ${settings.shopName}, I am browsing your website and have a question.`
  );

  return (
    <motion.a
      href={directWhatsAppUrl}
      target="_blank"
      rel="noopener noreferrer"
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      transition={{ type: 'spring', stiffness: 260, damping: 20 }}
      className="fixed bottom-6 right-6 z-40 group flex items-center gap-2.5 bg-emerald-600/95 hover:bg-emerald-500 text-white p-3.5 sm:px-5 sm:py-3.5 rounded-full shadow-2xl backdrop-blur-md transition-colors duration-300 border border-emerald-400/30"
      aria-label="Chat on WhatsApp"
      title="Chat with Bist Sticker on WhatsApp"
    >
      <div className="relative flex items-center justify-center">
        <MessageCircle className="w-6 h-6 fill-current text-white" />
        <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-emerald-600 animate-ping" />
        <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-emerald-600" />
      </div>
      <span className="hidden sm:inline font-black text-xs uppercase tracking-wider pr-1 text-white">
        Order On WhatsApp
      </span>
    </motion.a>
  );
};
