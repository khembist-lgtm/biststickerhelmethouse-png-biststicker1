import React, { useState } from 'react';
import { 
  Search, 
  ShoppingBag, 
  Heart, 
  Menu, 
  X, 
  PhoneCall, 
  MessageCircle, 
  ShieldCheck, 
  ChevronDown,
  Sparkles,
  Lock
} from 'lucide-react';
import { SiteSettings } from '../types';
import { formatWhatsAppUrl } from '../lib/api';

interface HeaderProps {
  settings: SiteSettings;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onSelectCategory: (categoryName: string) => void;
  selectedCategory: string;
  onOpenAdmin: () => void;
  isAdminMode: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  searchQuery,
  setSearchQuery,
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onSelectCategory,
  selectedCategory,
  onOpenAdmin,
  isAdminMode,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);

  const mainCategories = [
    { label: 'Home', cat: 'All' },
    { label: 'Bike Stickers', cat: 'Bike Stickers' },
    { label: 'Helmets', cat: 'Helmet' },
    { label: 'Accessories', cat: 'Bike Accessories' },
    { label: 'Number Plates', cat: 'Number Plates' },
    { label: 'PPF', cat: 'PPF' },
    { label: 'Keyrings', cat: 'Keyrings' },
    { label: 'Neon Sign', cat: 'Neon Sign Board' },
    { label: 'Bus & Truck Stickers', cat: 'Bus & Truck Stickers' },
  ];

  const secondaryCategories = [
    { label: 'Radium / Reflective', cat: 'Radium / Reflective Stickers' },
    { label: 'Duplicate Keys', cat: 'Duplicate Keys' },
    { label: 'Our Services', cat: 'services' },
    { label: 'About Us', cat: 'about' },
    { label: 'Store Location', cat: 'contact' },
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const productsSection = document.getElementById('featured-products');
    if (productsSection) {
      productsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCategoryClick = (cat: string) => {
    if (cat === 'services' || cat === 'about' || cat === 'contact') {
      const el = document.getElementById(cat);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else {
      onSelectCategory(cat);
      const el = document.getElementById('featured-products');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
    setIsMoreMenuOpen(false);
  };

  const directWhatsAppUrl = formatWhatsAppUrl(
    settings.whatsappNumber,
    `Hello ${settings.shopName}, I would like to inquire about your products.`
  );

  return (
    <header className="sticky top-0 z-50 transition-all duration-300">
      {/* Top Mini Bar - Deep Gradient & Metallic Accents */}
      <div className="bg-gradient-to-r from-zinc-950 via-zinc-900 to-black text-white text-[10px] font-extrabold uppercase tracking-widest py-1.5 px-4 sm:px-6 border-b border-zinc-800/60">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
          <div className="flex items-center gap-2 sm:gap-4">
            <span className="text-zinc-300 flex items-center gap-1">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
              ATTARIYA, KAILALI, NEPAL
            </span>
            <span className="text-zinc-700">•</span>
            <a href={`tel:${settings.phone}`} className="hover:text-red-400 transition-colors duration-200 flex items-center gap-1">
              <PhoneCall className="w-2.5 h-2.5 text-red-500" />
              <span>WHATSAPP: {settings.phone}</span>
            </a>
          </div>
          <div className="flex items-center gap-3 sm:gap-5 text-[10px]">
            {settings.facebookUrl && (
              <a
                href={settings.facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-red-400 transition-colors duration-200 hover:scale-105 transform inline-block"
              >
                FACEBOOK
              </a>
            )}
            {settings.instagramUrl && (
              <a
                href={settings.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-red-400 transition-colors duration-200 hover:scale-105 transform inline-block"
              >
                INSTAGRAM
              </a>
            )}
            {settings.tiktokUrl && (
              <a
                href={settings.tiktokUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-red-400 transition-colors duration-200 hover:scale-105 transform inline-block font-bold text-red-400"
              >
                TIKTOK
              </a>
            )}
            <button
              onClick={onOpenAdmin}
              className={`flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[9px] font-bold transition-all duration-300 uppercase shadow-sm ${
                isAdminMode
                  ? 'bg-red-600 text-white glow-red-sm ring-1 ring-red-400/50'
                  : 'bg-zinc-800/90 text-zinc-300 hover:bg-zinc-700 hover:text-white border border-zinc-700/50'
              }`}
            >
              <Lock className="w-2.5 h-2.5" />
              <span>{isAdminMode ? 'EDIT MODE' : 'ADMIN'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Header Container - Deep-Toned Glassmorphism */}
      <div className="bg-gradient-to-r from-zinc-950/95 via-zinc-900/95 to-zinc-950/95 backdrop-blur-xl border-b border-zinc-800/80 text-white shadow-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Logo - Custom Image or Clean Styled Badge */}
          <div 
            onClick={() => handleCategoryClick('All')} 
            className="flex items-center gap-2.5 cursor-pointer group shrink-0"
            title={settings.shopName}
          >
            {settings.logoUrl && settings.logoUrl.trim() !== '' ? (
              <div className="flex items-center gap-2">
                <img
                  src={settings.logoUrl}
                  alt={settings.shopName}
                  className="h-10 sm:h-12 w-auto max-w-[150px] sm:max-w-[210px] object-contain transition-transform duration-300 group-hover:scale-105 filter drop-shadow-md"
                />
              </div>
            ) : (
              <div className="flex items-center gap-2.5">
                <div className="flex h-10 w-10 items-center justify-center bg-gradient-to-br from-red-600 to-zinc-950 text-white rounded-xl shadow-lg border border-red-500/30 group-hover:scale-105 group-hover:border-red-500 transition-all duration-300 group-hover:glow-red-sm">
                  <span className="text-xl font-black italic font-sans group-hover:rotate-3 transition-transform duration-300">B</span>
                </div>
                <div>
                  <h1 className="text-sm sm:text-base font-black leading-none tracking-tighter text-white uppercase font-sans group-hover:text-red-400 transition-colors duration-200">
                    BIST STICKER
                  </h1>
                  <p className="text-[9px] sm:text-[10px] font-black text-red-500 tracking-widest uppercase mt-0.5 flex items-center gap-1">
                    <span>& ACCESSORIES</span>
                    <Sparkles className="w-2.5 h-2.5 text-red-400 animate-pulse" />
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Search Bar - Desktop Deep Glass */}
          <form
            onSubmit={handleSearchSubmit}
            className="hidden md:flex flex-1 max-w-md mx-6 items-center relative"
          >
            <input
              type="text"
              placeholder="I am shopping for bike stickers, helmets, PPF..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-full border border-zinc-700/80 bg-zinc-900/90 py-2 pl-4 pr-10 text-xs text-white placeholder-zinc-400 focus:border-red-500 focus:bg-zinc-950 focus:outline-none focus:ring-2 focus:ring-red-500/30 transition-all duration-300 shadow-inner"
            />
            <button
              type="submit"
              className="absolute right-3 text-zinc-400 hover:text-red-500 transition-colors duration-200 hover:scale-110 active:scale-95 transform"
              aria-label="Search"
            >
              <Search className="w-4 h-4" />
            </button>
          </form>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-5 text-[11px] font-bold uppercase tracking-tight">
            {mainCategories.slice(0, 6).map((item) => {
              const isActive = selectedCategory === item.cat;
              return (
                <button
                  key={item.label}
                  onClick={() => handleCategoryClick(item.cat)}
                  className={`transition-all duration-200 whitespace-nowrap py-1 relative group/nav ${
                    isActive
                      ? 'text-red-400 font-extrabold'
                      : 'text-zinc-300 hover:text-white'
                  }`}
                >
                  {item.label}
                  <span className={`absolute bottom-0 left-0 w-full h-0.5 bg-red-500 rounded-full transition-all duration-300 ${
                    isActive ? 'opacity-100 scale-x-100' : 'opacity-0 scale-x-0 group-hover/nav:opacity-100 group-hover/nav:scale-x-100'
                  }`} />
                </button>
              );
            })}

            {/* More Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsMoreMenuOpen(!isMoreMenuOpen)}
                className="flex items-center gap-1 text-zinc-300 hover:text-white transition-colors duration-200 py-1"
              >
                <span>More</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isMoreMenuOpen ? 'rotate-180 text-red-500' : ''}`} />
              </button>

              {isMoreMenuOpen && (
                <div className="absolute top-full right-0 mt-2 w-56 bg-zinc-950/95 text-white rounded-2xl shadow-2xl border border-zinc-800/80 backdrop-blur-xl py-2 z-50 animate-fadeIn">
                  {mainCategories.slice(6).concat(secondaryCategories).map((item) => (
                    <button
                      key={item.label}
                      onClick={() => handleCategoryClick(item.cat)}
                      className="w-full text-left px-4 py-2 text-xs font-bold text-zinc-300 hover:bg-red-600/20 hover:text-red-400 transition-colors duration-150 flex items-center justify-between"
                    >
                      <span>{item.label}</span>
                      <Sparkles className="w-3 h-3 text-red-500/0 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </nav>

          {/* Right Action Icons with Micro-Animations */}
          <div className="flex items-center gap-3 sm:gap-4 border-l border-zinc-800/80 pl-4 sm:pl-6">
            <button
              onClick={onOpenWishlist}
              className="relative cursor-pointer text-zinc-300 hover:text-red-500 transition-all duration-200 hover:scale-110 active:scale-95 p-1.5 rounded-xl hover:bg-zinc-800/50"
              title="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-600 text-[9px] font-black text-white glow-red-sm animate-pulse">
                  {wishlistCount}
                </span>
              )}
            </button>

            <button
              onClick={onOpenCart}
              className="relative cursor-pointer text-zinc-300 hover:text-red-500 transition-all duration-200 hover:scale-110 active:scale-95 p-1.5 rounded-xl hover:bg-zinc-800/50"
              title="Shopping Cart"
            >
              <div className="relative">
                <ShoppingBag className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-600 text-[9px] font-black text-white glow-red-sm animate-pulse">
                  {cartCount}
                </span>
              </div>
            </button>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-1.5 lg:hidden rounded-xl text-zinc-300 hover:text-white hover:bg-zinc-800/80 transition-all active:scale-95"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6 text-red-500" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        <div className="md:hidden px-4 pb-3">
          <form onSubmit={handleSearchSubmit} className="flex items-center relative">
            <input
              type="text"
              placeholder="I'm shopping for..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-zinc-900/90 border border-zinc-700/80 rounded-full py-2 pl-4 pr-10 text-xs text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-red-500/50"
            />
            <button
              type="submit"
              className="absolute right-1 p-1.5 bg-red-600 text-white rounded-full shadow-md active:scale-95 transition"
            >
              <Search className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>

      {/* Desktop Sticky Navbar - Deep Multitone Gradient */}
      <nav className="hidden md:block bg-gradient-to-r from-zinc-950 via-black to-zinc-950 text-white border-t border-zinc-800/80 shadow-md">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between text-xs font-bold uppercase tracking-wider overflow-x-auto no-scrollbar">
          <div className="flex items-center space-x-1 py-1.5">
            {mainCategories.map((item) => {
              const isActive = selectedCategory === item.cat;
              return (
                <button
                  key={item.label}
                  onClick={() => handleCategoryClick(item.cat)}
                  className={`px-3.5 py-2 rounded-xl whitespace-nowrap transition-all duration-200 transform hover:scale-102 ${
                    isActive
                      ? 'bg-gradient-to-r from-red-600 to-red-700 text-white font-black shadow-md glow-red-sm border border-red-500/40'
                      : 'text-zinc-300 hover:text-white hover:bg-zinc-800/80'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}

            {/* More Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsMoreMenuOpen(!isMoreMenuOpen)}
                className="flex items-center gap-1 px-3.5 py-2 rounded-xl text-zinc-300 hover:text-white hover:bg-zinc-800/80 whitespace-nowrap transition-colors duration-200"
              >
                <span>More</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {isMoreMenuOpen && (
                <div className="absolute top-full right-0 mt-1 w-56 bg-zinc-950/95 text-white rounded-2xl shadow-2xl border border-zinc-800/80 backdrop-blur-xl py-2 z-50 animate-fadeIn">
                  {secondaryCategories.map((item) => (
                    <button
                      key={item.label}
                      onClick={() => handleCategoryClick(item.cat)}
                      className="w-full text-left px-4 py-2 text-xs font-bold text-zinc-300 hover:bg-red-600/30 hover:text-red-400 transition-colors duration-150"
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="hidden xl:flex items-center gap-2 text-zinc-400 text-[11px] font-semibold tracking-normal lowercase py-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span className="text-zinc-300 font-medium">Official Shop in Attariya Chowk</span>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-zinc-950/98 backdrop-blur-2xl text-white border-t border-zinc-800/80 px-4 py-5 space-y-4 shadow-2xl animate-fadeIn">
          <div className="text-xs uppercase font-black text-red-500 tracking-widest flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Categories & Menu</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs font-bold">
            {mainCategories.map((item) => (
              <button
                key={item.label}
                onClick={() => handleCategoryClick(item.cat)}
                className={`text-left px-3.5 py-2.5 rounded-xl transition-all duration-200 ${
                  selectedCategory === item.cat
                    ? 'bg-red-600 text-white font-black shadow-md glow-red-sm'
                    : 'bg-zinc-900/90 text-zinc-300 hover:bg-zinc-800 hover:text-white border border-zinc-800/60'
                }`}
              >
                {item.label}
              </button>
            ))}
            {secondaryCategories.map((item) => (
              <button
                key={item.label}
                onClick={() => handleCategoryClick(item.cat)}
                className="text-left px-3.5 py-2.5 rounded-xl bg-zinc-900/90 text-zinc-300 hover:bg-zinc-800 hover:text-white transition-all border border-zinc-800/60"
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-zinc-800/80 flex flex-col gap-2">
            <a
              href={directWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white py-3 rounded-xl text-xs font-extrabold shadow-lg transition-transform active:scale-95"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Order via WhatsApp (9848419968)</span>
            </a>
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenAdmin();
              }}
              className="flex items-center justify-center gap-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 py-2.5 rounded-xl text-xs font-bold border border-zinc-800"
            >
              <Lock className="w-3.5 h-3.5 text-red-500" />
              <span>Admin Panel Login</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
