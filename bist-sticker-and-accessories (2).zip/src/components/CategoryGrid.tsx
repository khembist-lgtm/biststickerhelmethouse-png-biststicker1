import React from 'react';
import { Category } from '../types';
import { CategoryCard } from './CategoryCard';

interface CategoryGridProps {
  categories: Category[];
  onSelectCategory: (categoryName: string) => void;
}

export const CategoryGrid: React.FC<CategoryGridProps> = ({ categories, onSelectCategory }) => {
  return (
    <section id="categories" className="py-14 sm:py-20 bg-[#f8f7f4] border-b border-[#1a1a1a]/10">
      <div className="max-w-[1600px] mx-auto px-6 sm:px-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 sm:mb-14 gap-6 pb-6 border-b border-[#1a1a1a]/10">
          <div>
            <div className="font-mono-meta text-[11px] uppercase tracking-[0.2em] text-[#1a1a1a]/60 mb-2">
              CURATED PRODUCT LINES
            </div>
            <h2 className="text-3xl sm:text-5xl font-black text-[#1a1a1a] uppercase tracking-tighter font-sans">
              Shop By Category<span className="text-[#ff3300]">.</span>
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-[#1a1a1a]/70 max-w-md font-medium leading-relaxed">
            From precision bike graphics & certified helmets to industrial PPF wraps, neon boards and duplicate keys — explore our specialized inventory in Attariya.
          </p>
        </div>

        {/* Category Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {categories.map((category) => (
            <CategoryCard
              key={category.id}
              category={category}
              onSelectCategory={onSelectCategory}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

