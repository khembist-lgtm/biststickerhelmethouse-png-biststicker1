import React, { useState, useMemo } from 'react';
import { Product, Category, SiteSettings } from '../types';
import { ProductCard } from './ProductCard';
import { SlidersHorizontal, PackageSearch, RefreshCw } from 'lucide-react';

interface ProductGridProps {
  products: Product[];
  categories: Category[];
  settings: SiteSettings;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onAddToCart: (product: Product) => void;
  onViewDetails: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: string[];
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  categories,
  settings,
  selectedCategory,
  setSelectedCategory,
  searchQuery,
  setSearchQuery,
  onAddToCart,
  onViewDetails,
  onToggleWishlist,
  wishlistIds,
}) => {
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'newest'>('featured');

  // Filter and Sort Products
  const filteredProducts = useMemo(() => {
    return products
      .filter((product) => product.isActive)
      .filter((product) => {
        // Category Filter
        if (selectedCategory !== 'All' && selectedCategory !== '') {
          if (product.category.toLowerCase() !== selectedCategory.toLowerCase()) {
            return false;
          }
        }
        // Search Filter
        if (searchQuery.trim().length > 0) {
          const q = searchQuery.toLowerCase();
          const nameMatch = product.name.toLowerCase().includes(q);
          const catMatch = product.category.toLowerCase().includes(q);
          const descMatch = product.description.toLowerCase().includes(q);
          const tagMatch = product.tags?.some((t) => t.toLowerCase().includes(q));
          return nameMatch || catMatch || descMatch || tagMatch;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-asc') return a.price - b.price;
        if (sortBy === 'price-desc') return b.price - a.price;
        if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        // Default 'featured'
        return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
      });
  }, [products, selectedCategory, searchQuery, sortBy]);

  return (
    <section id="featured-products" className="py-14 sm:py-20 bg-[#f8f7f4] border-b border-[#1a1a1a]/10">
      <div className="max-w-[1600px] mx-auto px-6 sm:px-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6 border-b border-[#1a1a1a]/10 pb-6">
          <div>
            <div className="font-mono-meta text-[11px] uppercase tracking-[0.2em] text-[#1a1a1a]/60 mb-2">
              CATALOGUE ARCHIVE
            </div>
            <h2 className="text-3xl sm:text-5xl font-black text-[#1a1a1a] uppercase tracking-tighter font-sans">
              Featured Products & Accessories<span className="text-[#ff3300]">.</span>
            </h2>
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-3 self-start md:self-auto font-mono-meta text-[11px] uppercase">
            <SlidersHorizontal className="w-4 h-4 text-[#1a1a1a]" />
            <span className="font-bold text-[#1a1a1a]/70">Sort By:</span>
            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              className="bg-[#f8f7f4] border border-[#1a1a1a]/30 text-[11px] font-bold text-[#1a1a1a] rounded-none px-3 py-2 focus:outline-none focus:border-[#1a1a1a] cursor-pointer"
            >
              <option value="featured">Featured First</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="newest">Newest Arrivals</option>
            </select>
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar font-mono-meta">
          <button
            onClick={() => setSelectedCategory('All')}
            className={`px-4 py-2 text-[11px] font-bold uppercase tracking-wider whitespace-nowrap transition-all ${
              selectedCategory === 'All' || selectedCategory === ''
                ? 'bg-[#1a1a1a] text-white'
                : 'bg-[#1a1a1a]/5 hover:bg-[#1a1a1a] hover:text-white text-[#1a1a1a] border border-[#1a1a1a]/10'
            }`}
          >
            All Products ({products.filter((p) => p.isActive).length})
          </button>
          {categories.map((cat) => {
            const count = products.filter((p) => p.isActive && p.category.toLowerCase() === cat.name.toLowerCase()).length;
            const isSelected = selectedCategory.toLowerCase() === cat.name.toLowerCase();
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.name)}
                className={`px-4 py-2 text-[11px] font-bold uppercase tracking-wider whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-[#1a1a1a] text-white'
                    : 'bg-[#1a1a1a]/5 hover:bg-[#1a1a1a] hover:text-white text-[#1a1a1a] border border-[#1a1a1a]/10'
                }`}
              >
                {cat.name} ({count})
              </button>
            );
          })}
        </div>

        {/* Active Filter Notice */}
        {(selectedCategory !== 'All' || searchQuery.trim().length > 0) && (
          <div className="mb-8 flex flex-wrap items-center justify-between gap-3 p-4 bg-[#e5e4e1] border border-[#1a1a1a]/20 text-[11px] font-mono-meta uppercase">
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-[#1a1a1a]/60 font-bold">Active Filter:</span>
              {selectedCategory !== 'All' && (
                <span className="bg-[#1a1a1a] text-white px-3 py-1 font-bold">
                  Category: {selectedCategory}
                </span>
              )}
              {searchQuery.trim().length > 0 && (
                <span className="bg-[#ff3300] text-white px-3 py-1 font-bold">
                  Query: "{searchQuery}"
                </span>
              )}
            </div>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSearchQuery('');
              }}
              className="flex items-center gap-1.5 text-[#1a1a1a] font-bold hover:text-[#ff3300]"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>
        )}

        {/* Product Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                settings={settings}
                onAddToCart={onAddToCart}
                onViewDetails={onViewDetails}
                onToggleWishlist={onToggleWishlist}
                isWishlisted={wishlistIds.includes(product.id)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-[#e5e4e1] border border-[#1a1a1a]/20 p-8 max-w-lg mx-auto">
            <PackageSearch className="w-12 h-12 text-[#1a1a1a]/40 mx-auto mb-3" />
            <h3 className="text-sm font-black text-[#1a1a1a] uppercase tracking-wider font-mono-meta">No Items Match Query</h3>
            <p className="text-xs text-[#1a1a1a]/70 mt-2 font-sans">
              No product items match your search or selected category.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSearchQuery('');
              }}
              className="mt-5 btn-black inline-flex items-center gap-2"
            >
              <span>Show Entire Archive</span>
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

