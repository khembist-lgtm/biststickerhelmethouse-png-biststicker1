import { signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User } from 'firebase/auth';
import { auth, googleProvider } from './firebase';

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  thumbnailLink?: string;
  webViewLink?: string;
  iconLink?: string;
  size?: string;
  createdTime?: string;
  modifiedTime?: string;
}

// Add Google Drive scopes to the Google Auth Provider
googleProvider.addScope('https://www.googleapis.com/auth/drive.file');
googleProvider.addScope('https://www.googleapis.com/auth/drive.readonly');
googleProvider.addScope('https://www.googleapis.com/auth/drive');

let isSigningIn = false;
let cachedAccessToken: string | null = null;

/**
 * Initialize Google Drive auth listener
 */
export const initDriveAuth = (
  onSuccess?: (user: User, token: string) => void,
  onFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user) => {
    if (user) {
      if (cachedAccessToken && onSuccess) {
        onSuccess(user, cachedAccessToken);
      } else if (!isSigningIn && onFailure) {
        onFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onFailure) onFailure();
    }
  });
};

/**
 * Sign in with Google to get an access token with Drive scopes
 */
export const googleDriveSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, googleProvider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to get access token for Google Drive');
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('[GOOGLE_DRIVE_SIGNIN_ERROR]', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getDriveAccessToken = (): string | null => cachedAccessToken;

export const setDriveAccessToken = (token: string | null) => {
  cachedAccessToken = token;
};

export const googleDriveLogout = async () => {
  cachedAccessToken = null;
  await auth.signOut();
};

/**
 * List files from user's Google Drive
 */
export async function listDriveFiles(searchQuery?: string, pageToken?: string): Promise<{ files: DriveFile[]; nextPageToken?: string }> {
  if (!cachedAccessToken) {
    throw new Error('Not authenticated with Google Drive. Please sign in.');
  }

  let q = "trashed = false";
  if (searchQuery && searchQuery.trim()) {
    const escaped = searchQuery.trim().replace(/'/g, "\\'");
    q += ` and name contains '${escaped}'`;
  }

  const fields = 'nextPageToken, files(id, name, mimeType, thumbnailLink, webViewLink, iconLink, size, createdTime, modifiedTime)';
  const params = new URLSearchParams({
    pageSize: '30',
    fields,
    q,
    orderBy: 'modifiedTime desc',
  });

  if (pageToken) {
    params.append('pageToken', pageToken);
  }

  const res = await fetch(`https://www.googleapis.com/drive/v3/files?${params.toString()}`, {
    headers: {
      Authorization: `Bearer ${cachedAccessToken}`,
    },
  });

  if (!res.ok) {
    const errText = await res.text();
    if (res.status === 401) {
      cachedAccessToken = null;
      throw new Error('Google Drive session expired. Please sign in again.');
    }
    throw new Error(`Google Drive API error (${res.status}): ${errText}`);
  }

  const data = await res.json();
  return {
    files: data.files || [],
    nextPageToken: data.nextPageToken,
  };
}

/**
 * Upload a file to Google Drive
 */
export async function uploadToDrive(file: File, customName?: string): Promise<DriveFile> {
  if (!cachedAccessToken) {
    throw new Error('Not authenticated with Google Drive. Please sign in.');
  }

  const metadata = {
    name: customName || file.name,
    mimeType: file.type || 'application/octet-stream',
  };

  const formData = new FormData();
  formData.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
  formData.append('file', file);

  const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,thumbnailLink,webViewLink,iconLink,size,createdTime,modifiedTime', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${cachedAccessToken}`,
    },
    body: formData,
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Failed to upload to Google Drive (${res.status}): ${errText}`);
  }

  return await res.json();
}

/**
 * Delete a file from Google Drive
 */
export async function deleteFromDrive(fileId: string): Promise<boolean> {
  if (!cachedAccessToken) {
    throw new Error('Not authenticated with Google Drive. Please sign in.');
  }

  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${cachedAccessToken}`,
    },
  });

  if (!res.ok && res.status !== 204 && res.status !== 404) {
    const errText = await res.text();
    throw new Error(`Failed to delete file from Google Drive: ${errText}`);
  }

  return true;
}

/**
 * Fetch a image/media file from Google Drive and convert to base64 Data URL for use in store
 */
export async function getDriveFileAsDataUrl(fileId: string): Promise<string> {
  if (!cachedAccessToken) {
    throw new Error('Not authenticated with Google Drive. Please sign in.');
  }

  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
    headers: {
      Authorization: `Bearer ${cachedAccessToken}`,
    },
  });

  if (!res.ok) {
    throw new Error(`Failed to fetch Drive file content (${res.status})`);
  }

  const blob = await res.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (e) => reject(e);
    reader.readAsDataURL(blob);
  });
}
