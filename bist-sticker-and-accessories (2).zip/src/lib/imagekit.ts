export interface ImageKitUploadResult {
  url: string;
  fileId?: string;
  filePath?: string;
  storagePath?: string;
}

export interface ImageKitAuthParams {
  token: string;
  expire: number;
  signature: string;
  publicKey?: string;
  urlEndpoint?: string;
}

/**
 * Fetches ImageKit authentication parameters from /api/imagekit/auth
 */
export async function fetchImageKitAuthParams(): Promise<ImageKitAuthParams> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

  try {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000';
    const res = await fetch(`${origin}/api/imagekit/auth`, {
      method: 'GET',
      headers: { 'Accept': 'application/json' },
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`ImageKit auth endpoint returned HTTP ${res.status}: ${text}`);
    }

    const data = await res.json();
    if (!data.token || !data.signature || !data.expire) {
      throw new Error('Invalid ImageKit authentication parameters returned from server.');
    }

    return data;
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') {
      throw new Error('ImageKit auth request timed out after 10 seconds.');
    }
    throw err;
  }
}

/**
 * Uploads file to ImageKit using server proxy or direct client upload.
 */
export async function uploadToImageKit(
  fileOrBase64: File | string,
  folder: string = 'general',
  docId: string = 'temp',
  onProgress?: (progress: number) => void
): Promise<ImageKitUploadResult> {
  onProgress?.(10);

  const cleanFolder = folder.replace(/[^a-zA-Z0-9_\-]/g, '_');
  const cleanDocId = docId.replace(/[^a-zA-Z0-9_\-]/g, '_');
  const fileName = `img_${cleanDocId}_${Date.now()}`;

  // Strategy 1: Server-side ImageKit proxy route (/api/imagekit/upload)
  try {
    let base64Payload = '';
    if (typeof fileOrBase64 === 'string') {
      base64Payload = fileOrBase64;
    } else {
      if (typeof FileReader !== 'undefined') {
        base64Payload = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = (e) => reject(e);
          reader.readAsDataURL(fileOrBase64);
        });
      } else {
        const buf = await fileOrBase64.arrayBuffer();
        const b64 = Buffer.from(buf).toString('base64');
        const mime = fileOrBase64.type || 'image/png';
        base64Payload = `data:${mime};base64,${b64}`;
      }
    }

    onProgress?.(25);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 20000); // 20s timeout

    const origin = typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000';
    const response = await fetch(`${origin}/api/imagekit/upload`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        image: base64Payload,
        fileName,
        folder: cleanFolder,
        docId: cleanDocId,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      const resData = await response.json();
      if (resData && resData.url) {
        onProgress?.(100);
        return {
          url: resData.url,
          fileId: resData.fileId || resData.storagePath || resData.url,
          filePath: resData.filePath || resData.storagePath,
          storagePath: resData.storagePath || resData.filePath,
        };
      }
    } else {
      const errorText = await response.text();
      console.warn('[IMAGEKIT_SERVER_UPLOAD_NOTICE] Server ImageKit upload returned status:', response.status, errorText);
    }
  } catch (serverErr: any) {
    console.warn('[IMAGEKIT_SERVER_UPLOAD_NOTICE] Server proxy failed:', serverErr?.message || serverErr);
  }

  // Strategy 2: Direct ImageKit upload via browser using auth params
  try {
    onProgress?.(40);
    const authParams = await fetchImageKitAuthParams();
    const publicKey = authParams.publicKey || (import.meta as any).env?.VITE_IMAGEKIT_PUBLIC_KEY || '';

    if (publicKey && authParams.token && authParams.signature) {
      const formData = new FormData();
      if (typeof fileOrBase64 === 'string') {
        formData.append('file', fileOrBase64);
      } else {
        formData.append('file', fileOrBase64);
      }
      formData.append('fileName', fileName);
      formData.append('publicKey', publicKey);
      formData.append('signature', authParams.signature);
      formData.append('expire', String(authParams.expire));
      formData.append('token', authParams.token);
      formData.append('folder', `/${cleanFolder}`);
      formData.append('useUniqueFileName', 'true');

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 20000);

      onProgress?.(60);
      const ikRes = await fetch('https://upload.imagekit.io/api/v1/files/upload', {
        method: 'POST',
        body: formData,
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (ikRes.ok) {
        const ikData = await ikRes.json();
        if (ikData && ikData.url) {
          onProgress?.(100);
          return {
            url: ikData.url,
            fileId: ikData.fileId,
            filePath: ikData.filePath,
            storagePath: ikData.filePath,
          };
        }
      } else {
        const ikErrText = await ikRes.text();
        console.warn('[IMAGEKIT_DIRECT_UPLOAD_NOTICE] Direct ImageKit upload returned status:', ikRes.status, ikErrText);
      }
    }
  } catch (directErr: any) {
    console.warn('[IMAGEKIT_DIRECT_UPLOAD_NOTICE] Direct ImageKit upload failed:', directErr?.message || directErr);
  }

  throw new Error('ImageKit upload service unavailable or unauthenticated.');
}
