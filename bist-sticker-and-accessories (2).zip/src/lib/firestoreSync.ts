import { 
  collection, 
  doc, 
  setDoc, 
  getDoc,
  getDocFromServer,
  getDocs, 
  deleteDoc,
  onSnapshot, 
  writeBatch 
} from 'firebase/firestore';
import { 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged, 
  User 
} from 'firebase/auth';
import { db, auth, googleProvider, handleFirestoreError, logFirestoreError, OperationType } from './firebase';
import { AppDataStore, Product, Category, HeroSlide, Order, SiteSettings } from '../types';
import { initialCategories, initialHeroSlides, initialProducts, initialSiteSettings } from '../data/initialData';

const META_DOC_PATH = '_meta_/initialized';

// One-time initial seeding ONLY for categories/slides/settings if database was never initialized before
async function seedInitialDataIfNeeded(): Promise<AppDataStore> {
  const metaRef = doc(db, '_meta_', 'initialized');
  const metaSnap = await getDoc(metaRef);

  if (metaSnap.exists()) {
    // Already initialized! Do not seed.
    return {
      products: [],
      categories: initialCategories,
      heroSlides: initialHeroSlides,
      settings: initialSiteSettings,
      orders: [],
      pageViews: 100,
      initialized: true,
    };
  }

  // First time ever setup: Seed initial categories/slides/settings into Firestore. Products remain EMPTY [].
  console.log('[FIRESTORE_INIT] Setting up initial Firestore metadata and collections...');
  const batch = writeBatch(db);

  for (const cat of initialCategories) {
    batch.set(doc(db, 'categories', cat.id), cat);
  }
  for (const slide of initialHeroSlides) {
    batch.set(doc(db, 'heroSlides', slide.id), slide);
  }
  batch.set(doc(db, 'settings', 'site'), initialSiteSettings);
  batch.set(metaRef, { initialized: true, seededAt: new Date().toISOString() });

  await batch.commit();

  return {
    products: [],
    categories: initialCategories,
    heroSlides: initialHeroSlides,
    settings: initialSiteSettings,
    orders: [],
    pageViews: 100,
    initialized: true,
  };
}

// Fetch complete store directly from Firestore as SINGLE SOURCE OF TRUTH
export async function fetchStoreFromFirestore(): Promise<AppDataStore | null> {
  try {
    const metaRef = doc(db, '_meta_', 'initialized');
    const metaSnap = await getDoc(metaRef);

    if (!metaSnap.exists()) {
      return await seedInitialDataIfNeeded();
    }

    const [productsSnap, categoriesSnap, slidesSnap, ordersSnap, settingsSnap] = await Promise.all([
      getDocs(collection(db, 'products')),
      getDocs(collection(db, 'categories')),
      getDocs(collection(db, 'heroSlides')),
      getDocs(collection(db, 'orders')),
      getDocs(collection(db, 'settings')),
    ]);

    const products: Product[] = [];
    productsSnap.forEach((d) => {
      const data = d.data();
      if (data) products.push({ ...data, id: d.id } as Product);
    });

    console.log(`[PRODUCT_READ_SOURCE] FIRESTORE (Count: ${products.length})`);

    const categories: Category[] = [];
    categoriesSnap.forEach((d) => {
      const data = d.data();
      if (data) categories.push({ ...data, id: d.id } as Category);
    });

    const heroSlides: HeroSlide[] = [];
    slidesSnap.forEach((d) => {
      const data = d.data();
      if (data) heroSlides.push({ ...data, id: d.id } as HeroSlide);
    });

    const orders: Order[] = [];
    ordersSnap.forEach((d) => {
      const data = d.data();
      if (data) orders.push({ ...data, id: d.id } as Order);
    });

    let settings: SiteSettings = initialSiteSettings;
    settingsSnap.forEach((d) => {
      if (d.id === 'site' && d.data()) {
        settings = d.data() as SiteSettings;
      }
    });

    return {
      products, // Strictly whatever is in Firestore
      categories, // Strictly whatever is in Firestore (if deleted, stays deleted)
      heroSlides, // Strictly whatever is in Firestore (if deleted, stays deleted)
      settings,
      orders,
      pageViews: 100,
      initialized: true,
    };
  } catch (error) {
    logFirestoreError(error, OperationType.GET, 'store_collections');
    return null;
  }
}

// Helper to sanitize objects for Firestore (removes undefined fields which Firestore rejects)
function cleanObject<T>(obj: T): T {
  if (obj === null || obj === undefined) return obj;
  return JSON.parse(JSON.stringify(obj));
}

// Validation helper to strictly prevent base64 strings from entering Firestore
export function assertNoBase64Image(obj: any, path: string): void {
  const str = JSON.stringify(obj);
  if (str.includes('data:image/') || str.includes('base64,')) {
    throw new Error(`[REJECTED_BASE64_IMAGE] Cannot save raw base64 image data to Firestore at "${path}". Images must be uploaded to Storage/Server first.`);
  }
}

export interface FirestoreOpResult {
  success: boolean;
  error?: string;
  verified?: boolean;
}

// Single Product Operations
export async function saveProductToFirestore(product: Product): Promise<FirestoreOpResult> {
  const path = `products/${product.id}`;
  const op = OperationType.WRITE;
  const userExists = !!auth.currentUser;
  console.log(`[FIRESTORE_WRITE_ATTEMPT] Operation: ${op} | Path: ${path} | ID: ${product.id} | AUTH_USER_EXISTS: ${userExists}`);
  try {
    const cleanProd = cleanObject(product);
    assertNoBase64Image(cleanProd, path);
    const docRef = doc(db, 'products', product.id);
    await setDoc(docRef, cleanProd);

    // Verification Read directly from server
    const checkSnap = await getDocFromServer(docRef);
    if (!checkSnap.exists()) {
      const msg = `Document ${path} does not exist in Firestore after setDoc!`;
      console.error(`[PRODUCT_WRITE_VERIFICATION_FAILED] ${msg}`);
      return { success: false, verified: false, error: msg };
    }

    console.log(`[PRODUCT_WRITE_SUCCESS] Operation: ${op} | Path: ${path} | ID: ${product.id} | Code: ok | Verified: true`);
    return { success: true, verified: true };
  } catch (error) {
    const errCode = (error as any)?.code || 'unknown';
    const errMessage = error instanceof Error ? error.message : String(error);
    console.error(`[FIRESTORE_WRITE_ERROR] Code: "${errCode}" | Operation: ${op} | Path: ${path} | Details: ${errMessage}`);
    logFirestoreError(error, op, path);
    return { success: false, error: `[${errCode}] ${errMessage}` };
  }
}

export async function deleteProductFromFirestore(productId: string): Promise<FirestoreOpResult> {
  const path = `products/${productId}`;
  const op = OperationType.DELETE;
  const userExists = !!auth.currentUser;
  console.log(`[FIRESTORE_DELETE_ATTEMPT] Operation: ${op} | Path: ${path} | ID: ${productId} | AUTH_USER_EXISTS: ${userExists}`);
  try {
    const docRef = doc(db, 'products', productId);
    await deleteDoc(docRef);

    // Immediate Verification Read directly from server
    const checkSnap = await getDocFromServer(docRef);
    if (checkSnap.exists()) {
      const msg = `VERIFICATION FAILED: Document ${path} STILL EXISTS in Firestore after deleteDoc!`;
      console.error(`[PRODUCT_DELETE_VERIFICATION_FAILED] ${msg}`);
      return { success: false, verified: false, error: msg };
    }

    console.log(`[PRODUCT_DELETE_SUCCESS] Operation: ${op} | Path: ${path} | ID: ${productId} | Code: ok | VerifiedDeleted: true`);
    return { success: true, verified: true };
  } catch (error) {
    const errCode = (error as any)?.code || 'unknown';
    const errMessage = error instanceof Error ? error.message : String(error);
    console.error(`[FIRESTORE_DELETE_ERROR] Code: "${errCode}" | Operation: ${op} | Path: ${path} | Details: ${errMessage}`);
    logFirestoreError(error, op, path);
    return { success: false, error: `[${errCode}] ${errMessage}` };
  }
}

// Single Category Operations
export async function saveCategoryToFirestore(category: Category): Promise<FirestoreOpResult> {
  const path = `categories/${category.id}`;
  const op = OperationType.WRITE;
  const userExists = !!auth.currentUser;
  console.log(`[FIRESTORE_WRITE_ATTEMPT] Operation: ${op} | Path: ${path} | AUTH_USER_EXISTS: ${userExists}`);
  try {
    const cleanCat = cleanObject(category);
    assertNoBase64Image(cleanCat, path);
    const docRef = doc(db, 'categories', category.id);
    await setDoc(docRef, cleanCat);

    const checkSnap = await getDocFromServer(docRef);
    if (!checkSnap.exists()) {
      const msg = `Document ${path} does not exist in Firestore after setDoc!`;
      return { success: false, verified: false, error: msg };
    }

    console.log(`[CATEGORY_WRITE_SUCCESS] Operation: ${op} | Path: ${path} | Code: ok`);
    return { success: true, verified: true };
  } catch (error) {
    const errCode = (error as any)?.code || 'unknown';
    const errMessage = error instanceof Error ? error.message : String(error);
    logFirestoreError(error, op, path);
    return { success: false, error: `[${errCode}] ${errMessage}` };
  }
}

export async function deleteCategoryFromFirestore(categoryId: string): Promise<FirestoreOpResult> {
  const path = `categories/${categoryId}`;
  const op = OperationType.DELETE;
  const userExists = !!auth.currentUser;
  console.log(`[FIRESTORE_DELETE_ATTEMPT] Operation: ${op} | Path: ${path} | AUTH_USER_EXISTS: ${userExists}`);
  try {
    const docRef = doc(db, 'categories', categoryId);
    await deleteDoc(docRef);

    const checkSnap = await getDocFromServer(docRef);
    if (checkSnap.exists()) {
      const msg = `VERIFICATION FAILED: Document ${path} STILL EXISTS after deleteDoc!`;
      return { success: false, verified: false, error: msg };
    }

    console.log(`[CATEGORY_DELETE_SUCCESS] Operation: ${op} | Path: ${path} | Code: ok`);
    return { success: true, verified: true };
  } catch (error) {
    const errCode = (error as any)?.code || 'unknown';
    const errMessage = error instanceof Error ? error.message : String(error);
    logFirestoreError(error, op, path);
    return { success: false, error: `[${errCode}] ${errMessage}` };
  }
}

// Hero Slide Operations
export async function saveHeroSlideToFirestore(slide: HeroSlide): Promise<FirestoreOpResult> {
  const path = `heroSlides/${slide.id}`;
  const op = OperationType.WRITE;
  const userExists = !!auth.currentUser;
  console.log(`[FIRESTORE_WRITE_ATTEMPT] Operation: ${op} | Path: ${path} | AUTH_USER_EXISTS: ${userExists}`);
  try {
    const cleanSlide = cleanObject(slide);
    assertNoBase64Image(cleanSlide, path);
    const docRef = doc(db, 'heroSlides', slide.id);
    await setDoc(docRef, cleanSlide);

    const checkSnap = await getDocFromServer(docRef);
    if (!checkSnap.exists()) {
      const msg = `Document ${path} does not exist after setDoc!`;
      return { success: false, verified: false, error: msg };
    }

    console.log(`[SLIDE_WRITE_SUCCESS] Operation: ${op} | Path: ${path} | Code: ok`);
    return { success: true, verified: true };
  } catch (error) {
    const errCode = (error as any)?.code || 'unknown';
    const errMessage = error instanceof Error ? error.message : String(error);
    logFirestoreError(error, op, path);
    return { success: false, error: `[${errCode}] ${errMessage}` };
  }
}

export async function deleteHeroSlideFromFirestore(slideId: string): Promise<FirestoreOpResult> {
  const path = `heroSlides/${slideId}`;
  const op = OperationType.DELETE;
  const userExists = !!auth.currentUser;
  console.log(`[FIRESTORE_DELETE_ATTEMPT] Operation: ${op} | Path: ${path} | AUTH_USER_EXISTS: ${userExists}`);
  try {
    const docRef = doc(db, 'heroSlides', slideId);
    await deleteDoc(docRef);

    const checkSnap = await getDocFromServer(docRef);
    if (checkSnap.exists()) {
      const msg = `VERIFICATION FAILED: Document ${path} STILL EXISTS after deleteDoc!`;
      return { success: false, verified: false, error: msg };
    }

    console.log(`[SLIDE_DELETE_SUCCESS] Operation: ${op} | Path: ${path} | Code: ok`);
    return { success: true, verified: true };
  } catch (error) {
    const errCode = (error as any)?.code || 'unknown';
    const errMessage = error instanceof Error ? error.message : String(error);
    logFirestoreError(error, op, path);
    return { success: false, error: `[${errCode}] ${errMessage}` };
  }
}

// Settings Operation
export async function saveSettingsToFirestore(settings: SiteSettings): Promise<FirestoreOpResult> {
  const path = `settings/site`;
  const op = OperationType.WRITE;
  const userExists = !!auth.currentUser;
  console.log(`[FIRESTORE_WRITE_ATTEMPT] Operation: ${op} | Path: ${path} | AUTH_USER_EXISTS: ${userExists}`);
  try {
    const cleanSettings = cleanObject(settings);
    assertNoBase64Image(cleanSettings, path);
    const docRef = doc(db, 'settings', 'site');
    await setDoc(docRef, cleanSettings);

    const checkSnap = await getDocFromServer(docRef);
    if (!checkSnap.exists()) {
      const msg = `Document ${path} does not exist after setDoc!`;
      return { success: false, verified: false, error: msg };
    }

    console.log(`[SETTINGS_WRITE_SUCCESS] Operation: ${op} | Path: ${path} | Code: ok`);
    return { success: true, verified: true };
  } catch (error) {
    const errCode = (error as any)?.code || 'unknown';
    const errMessage = error instanceof Error ? error.message : String(error);
    logFirestoreError(error, op, path);
    return { success: false, error: `[${errCode}] ${errMessage}` };
  }
}

// Push order to Firestore
export async function pushOrderToFirestore(order: Order): Promise<boolean> {
  const path = `orders/${order.id}`;
  const op = OperationType.WRITE;
  console.log(`[FIRESTORE_WRITE_ATTEMPT] Operation: ${op} | Path: ${path} | Auth: ${auth.currentUser?.uid || 'unauthenticated'}`);
  try {
    await setDoc(doc(db, 'orders', order.id), cleanObject(order));
    console.log(`[ORDER_WRITE_SUCCESS] Operation: ${op} | Path: ${path} | Code: ok`);
    return true;
  } catch (error) {
    logFirestoreError(error, op, path);
    return false;
  }
}

// Sync entire store snapshot (e.g. import or restore)
export async function syncStoreToFirestore(store: AppDataStore): Promise<boolean> {
  const path = `batch_sync_all`;
  const op = OperationType.WRITE;
  console.log(`[FIRESTORE_WRITE_ATTEMPT] Operation: ${op} | Path: ${path} | Auth: ${auth.currentUser?.uid || 'unauthenticated'}`);
  try {
    const batch = writeBatch(db);

    if (Array.isArray(store.products)) {
      // First get existing product docs and remove those no longer present
      const existing = await getDocs(collection(db, 'products'));
      const activeIds = new Set(store.products.map((p) => p.id));
      existing.forEach((d) => {
        if (!activeIds.has(d.id)) {
          batch.delete(doc(db, 'products', d.id));
        }
      });
      for (const prod of store.products) {
        if (prod.id) {
          batch.set(doc(db, 'products', prod.id), cleanObject(prod));
        }
      }
    }

    if (Array.isArray(store.categories)) {
      for (const cat of store.categories) {
        if (cat.id) {
          batch.set(doc(db, 'categories', cat.id), cleanObject(cat));
        }
      }
    }

    if (Array.isArray(store.heroSlides)) {
      for (const slide of store.heroSlides) {
        if (slide.id) {
          batch.set(doc(db, 'heroSlides', slide.id), cleanObject(slide));
        }
      }
    }

    if (store.settings) {
      batch.set(doc(db, 'settings', 'site'), cleanObject(store.settings));
    }

    await batch.commit();
    console.log(`[BATCH_SYNC_SUCCESS] Operation: WRITE | Path: ${path} | Code: ok`);
    return true;
  } catch (error) {
    logFirestoreError(error, OperationType.WRITE, path);
    return false;
  }
}

// Real-time Firestore Subscription for Instant Cross-Browser Updates
export function subscribeToStoreChanges(onStoreUpdate: (store: AppDataStore) => void) {
  let currentProducts: Product[] = [];
  let currentCategories: Category[] = initialCategories;
  let currentHeroSlides: HeroSlide[] = initialHeroSlides;
  let currentSettings: SiteSettings = initialSiteSettings;
  let currentOrders: Order[] = [];

  const updateStore = () => {
    onStoreUpdate({
      products: currentProducts,
      categories: currentCategories,
      heroSlides: currentHeroSlides,
      settings: currentSettings,
      orders: currentOrders,
      pageViews: 100,
      initialized: true,
    });
  };

  const unsubProducts = onSnapshot(collection(db, 'products'), (snap) => {
    const list: Product[] = [];
    snap.forEach((d) => {
      const data = d.data();
      if (data) list.push({ ...data, id: d.id } as Product);
    });
    currentProducts = list;
    updateStore();
  }, (error) => {
    logFirestoreError(error, OperationType.LIST, 'products');
  });

  const unsubCategories = onSnapshot(collection(db, 'categories'), (snap) => {
    const list: Category[] = [];
    snap.forEach((d) => {
      const data = d.data();
      if (data) list.push({ ...data, id: d.id } as Category);
    });
    currentCategories = list;
    updateStore();
  }, (error) => {
    logFirestoreError(error, OperationType.LIST, 'categories');
  });

  const unsubSlides = onSnapshot(collection(db, 'heroSlides'), (snap) => {
    const list: HeroSlide[] = [];
    snap.forEach((d) => {
      const data = d.data();
      if (data) list.push({ ...data, id: d.id } as HeroSlide);
    });
    currentHeroSlides = list;
    updateStore();
  }, (error) => {
    logFirestoreError(error, OperationType.LIST, 'heroSlides');
  });

  const unsubSettings = onSnapshot(collection(db, 'settings'), (snap) => {
    snap.forEach((d) => {
      if (d.id === 'site' && d.data()) {
        currentSettings = d.data() as SiteSettings;
      }
    });
    updateStore();
  }, (error) => {
    logFirestoreError(error, OperationType.LIST, 'settings');
  });

  const unsubOrders = onSnapshot(collection(db, 'orders'), (snap) => {
    const list: Order[] = [];
    snap.forEach((d) => {
      const data = d.data();
      if (data) list.push({ ...data, id: d.id } as Order);
    });
    currentOrders = list;
    updateStore();
  }, (error) => {
    logFirestoreError(error, OperationType.LIST, 'orders');
  });

  return () => {
    unsubProducts();
    unsubCategories();
    unsubSlides();
    unsubSettings();
    unsubOrders();
  };
}

// Google Auth Helpers
export async function signInWithGoogle(): Promise<User | null> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error) {
    console.error('Error signing in with Google:', error);
    return null;
  }
}

export async function signOutFirebase(): Promise<void> {
  try {
    await signOut(auth);
  } catch (error) {
    console.error('Error signing out:', error);
  }
}

export function subscribeToAuthChanges(callback: (user: User | null) => void) {
  return onAuthStateChanged(auth, callback);
}
