import { AppDataStore, CartItem, Product } from '../types';
import { initialCategories, initialHeroSlides, initialProducts, initialSiteSettings } from '../data/initialData';
import { syncStoreToFirestore, pushOrderToFirestore, fetchStoreFromFirestore } from './firestoreSync';

const LOCAL_STORAGE_KEY = 'bist_sticker_app_store_v1';

export function formatNPR(amount: number): string {
  return `रु ${amount.toLocaleString('en-IN')}`;
}

export function formatWhatsAppUrl(whatsappNumber: string, message: string): string {
  const cleanNumber = whatsappNumber.replace(/[^0-9]/g, '');
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${cleanNumber}?text=${encoded}`;
}

export function generateProductWhatsAppMessage(shopName: string, product: Product): string {
  return `Hello ${shopName}, I am interested in ${product.name} (Price: ${formatNPR(product.price)}). Please provide availability and details.`;
}

export function generateCartWhatsAppMessage(
  shopName: string,
  customer: { name: string; phone: string; address: string; cityArea: string; notes?: string },
  items: CartItem[],
  totalAmount: number
): string {
  const itemLines = items
    .map(
      (item) =>
        `• ${item.product.name} (Qty: ${item.quantity}) - ${formatNPR(item.product.price * item.quantity)}`
    )
    .join('\n');

  let msg = `Hello ${shopName}, I would like to place an order:\n\n`;
  msg += `👤 Customer: ${customer.name}\n`;
  msg += `📞 Phone: ${customer.phone}\n`;
  msg += `📍 Address: ${customer.address}, ${customer.cityArea}\n`;
  if (customer.notes && customer.notes.trim().length > 0) {
    msg += `📝 Notes: ${customer.notes.trim()}\n`;
  }
  msg += `\n📦 ORDER ITEMS:\n${itemLines}\n\n`;
  msg += `💰 TOTAL AMOUNT: ${formatNPR(totalAmount)}\n\n`;
  msg += `Please confirm my order and payment/delivery details. Thank you!`;

  return msg;
}

// Fetch store directly from Firestore as STRICT SINGLE SOURCE OF TRUTH (No fallbacks allowed)
export async function fetchStoreData(): Promise<AppDataStore> {
  // Always clear stale local storage products cache
  try {
    localStorage.removeItem(LOCAL_STORAGE_KEY);
  } catch (e) {
    // ignore
  }

  try {
    const firestoreData = await fetchStoreFromFirestore();
    if (firestoreData && Array.isArray(firestoreData.products)) {
      console.log(`[PRODUCT_READ_SOURCE] FIRESTORE (Count: ${firestoreData.products.length})`);
      return firestoreData;
    }
  } catch (err) {
    const errCode = (err as any)?.code || 'unknown';
    const errMessage = err instanceof Error ? err.message : String(err);
    console.error(`[FIRESTORE_FETCH_ERROR] Code: "${errCode}" | Operation: READ | Path: store_collections | Details: ${errMessage}`);
  }

  console.warn('[UNEXPECTED_FALLBACK_SOURCE] Firestore unavailable. Prohibiting stale fallbacks. Returning empty products.');
  return {
    products: [],
    categories: initialCategories,
    heroSlides: initialHeroSlides,
    settings: initialSiteSettings,
    orders: [],
    pageViews: 100,
    initialized: true,
  };
}

// Save store payload to backend Express storage (.data_storage/store.json)
export async function saveBackendStoreData(store: AppDataStore): Promise<boolean> {
  try {
    const res = await fetch('/api/data', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(store),
    });
    return res.ok;
  } catch (err) {
    console.error('Error persisting store to backend:', err);
    return false;
  }
}

// Save store to backend & sync Firestore (used for full backups/restores)
export async function saveStoreData(store: AppDataStore): Promise<boolean> {
  // Await Firestore sync first to guarantee database success
  try {
    const syncSuccess = await syncStoreToFirestore(store);
    if (!syncSuccess) {
      console.error('[SAVE_STORE_FAILED] Firestore sync returned false.');
      return false;
    }
  } catch (err) {
    const errCode = (err as any)?.code || 'unknown';
    const errMessage = err instanceof Error ? err.message : String(err);
    console.error(`[FIRESTORE_SYNC_ERROR] Code: "${errCode}" | Operation: WRITE | Path: batch_sync_all | Details: ${errMessage}`);
    return false;
  }

  // Optionally persist to Express backend mirror if running with dev server (non-blocking)
  saveBackendStoreData(store).catch(() => {});
  return true;
}

// Backup & Restore API Handlers
export async function fetchBackupsList(): Promise<any[]> {
  try {
    const res = await fetch('/api/admin/backups');
    if (res.ok) {
      const data = await res.json();
      return data.backups || [];
    }
  } catch (err) {
    console.error('Error fetching backups list:', err);
  }
  return [];
}

export async function createManualBackup(): Promise<{ success: boolean; backupName?: string }> {
  try {
    const res = await fetch('/api/admin/backup', { method: 'POST' });
    if (res.ok) {
      const data = await res.json();
      return { success: true, backupName: data.backupName };
    }
  } catch (err) {
    console.error('Error creating manual backup:', err);
  }
  return { success: false };
}

export async function restoreFromBackup(filename: string): Promise<boolean> {
  try {
    const res = await fetch('/api/admin/restore', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename }),
    });
    return res.ok;
  } catch (err) {
    console.error('Error restoring backup:', err);
    return false;
  }
}

import { uploadImageFile as storageUploadImageFile } from './storage';

// Upload image file
export async function uploadImageFile(file: File | string, folder = 'general', docId = 'temp'): Promise<string> {
  const result = await storageUploadImageFile(file, folder, docId);
  return result.url;
}

// Post new order
export async function submitOrder(orderData: any): Promise<boolean> {
  // Push asynchronously to Firestore
  pushOrderToFirestore(orderData).catch((err) => console.warn('Firestore pushOrder warning:', err));

  try {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData),
    });
    return res.ok;
  } catch (err) {
    console.error('Error submitting order to API:', err);
    return false;
  }
}
