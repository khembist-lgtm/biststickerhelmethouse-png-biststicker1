import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);

/* CRITICAL: Explicitly pass custom database ID to getFirestore to avoid (default) database error */
export const FIRESTORE_DATABASE_ID = (firebaseConfig as any).firestoreDatabaseId || 'ai-studio-biststickerandac-750edb13-9cba-48ca-8aa4-d83ba641c7aa';
export const db = getFirestore(app, FIRESTORE_DATABASE_ID);

console.log(`[FIRESTORE_INIT] Connected to named Firestore database ID: "${FIRESTORE_DATABASE_ID}" (Project: ${firebaseConfig.projectId})`);
export const auth = getAuth(app);

const rawBucket = (firebaseConfig as any).storageBucket || 'peak-thought-tds98.firebasestorage.app';
const cleanBucket = rawBucket.startsWith('gs://') ? rawBucket.substring(5) : rawBucket;
export const storage = getStorage(app, cleanBucket ? `gs://${cleanBucket}` : undefined);
storage.maxUploadRetryTime = 8000;
storage.maxOperationRetryTime = 8000;
export const googleProvider = new GoogleAuthProvider();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function logFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errCode = (error as any)?.code || 'unknown';
  const errMessage = error instanceof Error ? error.message : String(error);
  const authInfo = {
    userId: auth.currentUser?.uid || 'unauthenticated',
    email: auth.currentUser?.email || null,
  };
  
  console.error(`[FIRESTORE_WRITE_ERROR] Code: "${errCode}" | Operation: ${operationType} | Path: ${path} | Auth: ${authInfo.userId} | Message: ${errMessage}`);
  
  return {
    error: errMessage,
    code: errCode,
    operationType,
    path,
    authInfo,
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo = logFirestoreError(error, operationType, path);
  throw new Error(JSON.stringify(errInfo));
}

export async function testFirestoreConnection() {
  try {
    await getDocFromServer(doc(db, '_connection_test_', 'ping'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration.");
    }
  }
}

testFirestoreConnection().catch(() => {});

