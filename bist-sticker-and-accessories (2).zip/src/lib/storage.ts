import { ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { storage, auth } from './firebase';
import { uploadToImageKit } from './imagekit';

export interface UploadResult {
  url: string;
  storagePath?: string;
  fileId?: string;
}

/**
 * Converts a base64 or Data URL string into a File object for clean uploading.
 */
export function dataURLtoFile(dataurl: string, filename: string): File {
  const arr = dataurl.split(',');
  const mimeMatch = arr[0].match(/:(.*?);/);
  const mime = mimeMatch ? mimeMatch[1] : 'image/png';
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new File([u8arr], filename, { type: mime });
}

export function fileToDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
}

/**
 * Automatically optimizes/compresses large images on the client before upload.
 * Preserves original aspect ratio and visual quality.
 */
export async function compressImageIfNeeded(
  file: File,
  maxDimension = 2048,
  quality = 0.88
): Promise<File> {
  // SVG or small files (< 2MB) do not need canvas compression
  if (
    !file.type.startsWith('image/') ||
    file.type === 'image/svg+xml' ||
    file.size <= 2 * 1024 * 1024
  ) {
    return file;
  }

  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return file;
  }

  return new Promise((resolve) => {
    const img = new Image();
    const url = URL.createObjectURL(file);

    img.onload = () => {
      URL.revokeObjectURL(url);
      let { width, height } = img;

      if (width > maxDimension || height > maxDimension) {
        if (width > height) {
          height = Math.round((height * maxDimension) / width);
          width = maxDimension;
        } else {
          width = Math.round((width * maxDimension) / height);
          height = maxDimension;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(file);
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);

      const outputType = file.type === 'image/png' ? 'image/png' : 'image/jpeg';

      canvas.toBlob(
        (blob) => {
          if (!blob || blob.size >= file.size) {
            resolve(file);
          } else {
            const ext = outputType === 'image/png' ? 'png' : 'jpg';
            const nameParts = file.name.split('.');
            nameParts.pop();
            const newName = `${nameParts.join('.')}_opt.${ext}`;
            const optimizedFile = new File([blob], newName, { type: outputType });
            console.log(
              `[IMAGE_CLIENT_OPTIMIZED] Original: ${(file.size / 1024 / 1024).toFixed(2)}MB -> Optimized: ${(optimizedFile.size / 1024 / 1024).toFixed(2)}MB (${width}x${height})`
            );
            resolve(optimizedFile);
          }
        },
        outputType,
        quality
      );
    };

    img.onerror = () => {
      URL.revokeObjectURL(url);
      resolve(file);
    };

    img.src = url;
  });
}

/**
 * Helper to map Firebase Storage error codes to detailed, human-readable error messages.
 */
function formatStorageError(err: any): string {
  const code = err?.code || '';
  const message = err?.message || String(err || 'Unknown error');

  if (code === 'storage/unauthorized') {
    return 'Permission denied by Firebase Storage security rules (storage/unauthorized). Please verify Storage rules in Firebase Console.';
  }
  if (code === 'storage/unauthenticated') {
    return 'User is not authenticated with Firebase Auth (storage/unauthenticated). Please log in before uploading.';
  }
  if (code === 'storage/bucket-not-found') {
    const bucket = storage.app.options.storageBucket || 'configured bucket';
    return `Firebase Storage bucket "${bucket}" not found (storage/bucket-not-found). Please ensure Firebase Storage is enabled in Firebase Console for project "${storage.app.options.projectId}".`;
  }
  if (code === 'storage/object-not-found') {
    return 'Storage object not found (storage/object-not-found).';
  }
  if (code === 'storage/quota-exceeded') {
    return 'Firebase Storage quota exceeded (storage/quota-exceeded).';
  }
  if (code === 'storage/retry-limit-exceeded') {
    const bucket = storage.app.options.storageBucket || 'peak-thought-tds98.firebasestorage.app';
    const projectId = storage.app.options.projectId || 'peak-thought-tds98';
    return `Firebase Storage upload retry limit exceeded (storage/retry-limit-exceeded). The storage bucket "${bucket}" is not enabled or provisioned in Firebase Console for project "${projectId}". Please ensure Cloud Storage for Firebase is enabled in Firebase Console.`;
  }
  if (code === 'storage/network-request-failed') {
    return 'Network request failed (storage/network-request-failed). Please check network connection.';
  }
  if (code) {
    return `Firebase Storage error (${code}): ${message}`;
  }
  return message;
}

/**
 * Uploads an image file directly to Firebase Storage using uploadBytesResumable.
 * Folder structure in Firebase Storage:
 * - products/
 * - categories/
 * - heroSlides/
 * - settings/
 */
export async function uploadImageFile(
  input: File | string,
  folder: 'heroSlides' | 'products' | 'categories' | 'settings' | string = 'general',
  docId: string = 'temp',
  onProgress?: (progress: number) => void
): Promise<UploadResult> {
  let fileToUpload: File;
  let dataUrlForFallback = '';

  // Monotonic progress reporter to prevent 40% -> 0% resets
  let highestProgress = 0;
  const reportProgress = (pct: number) => {
    if (!isNaN(pct)) {
      const target = Math.min(100, Math.max(highestProgress, Math.round(pct)));
      if (target > highestProgress) {
        highestProgress = target;
        onProgress?.(target);
      }
    }
  };

  if (typeof input === 'string') {
    if (input.startsWith('data:image/') || input.includes('base64,')) {
      dataUrlForFallback = input;
      const mime = input.split(';')[0]?.split(':')[1] || 'image/png';
      const ext = mime.split('/')[1] || 'png';
      const fileName = `img_${docId}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}.${ext}`;
      fileToUpload = dataURLtoFile(input, fileName);
    } else {
      // Input is already a hosted HTTP/HTTPS URL
      reportProgress(100);
      return { url: input, storagePath: input, fileId: input };
    }
  } else {
    fileToUpload = input;
  }

  if (!fileToUpload || fileToUpload.size === 0) {
    const err = new Error('Image upload failed: Selected file is empty or invalid.');
    console.error('[STORAGE_UPLOAD_VALIDATION_ERROR]', err);
    throw err;
  }

  // File type validation (JPG, PNG, WEBP, GIF, SVG)
  const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'];
  if (fileToUpload.type && !validTypes.includes(fileToUpload.type.toLowerCase())) {
    const err = new Error('Image upload failed: Unsupported image format. Please select a JPG, PNG, WEBP, GIF, or SVG image.');
    console.error('[STORAGE_UPLOAD_TYPE_ERROR]', err);
    throw err;
  }

  // Safely optimize/compress large images on the client before upload while preserving visual quality & aspect ratio
  try {
    fileToUpload = await compressImageIfNeeded(fileToUpload);
  } catch (compressErr) {
    console.warn('[STORAGE_COMPRESS_WARN] Auto-compression skipped:', compressErr);
  }

  const currentUser = auth.currentUser;
  const projectId = storage.app.options.projectId || 'peak-thought-tds98';
  const configuredBucket = storage.app.options.storageBucket || 'peak-thought-tds98.firebasestorage.app';

  const rawExt = fileToUpload.name ? fileToUpload.name.split('.').pop() : 'png';
  const ext = rawExt && rawExt.length <= 4 ? rawExt.toLowerCase() : 'png';
  const cleanDocId = docId.replace(/[^a-zA-Z0-9_\-]/g, '_');
  const uniqueFileName = `img_${cleanDocId}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}.${ext}`;

  let targetSubFolder = folder;
  if (folder === 'heroSlides' || folder === 'heroes') {
    targetSubFolder = 'heroSlides';
  }
  const storagePath = `${targetSubFolder}/${uniqueFileName}`;

  // PRINT MANDATORY DIAGNOSTIC (No credentials exposed)
  console.log('[FIREBASE_STORAGE_UPLOAD_DIAGNOSTIC]', {
    projectId,
    configuredStorageBucket: configuredBucket,
    authenticatedUserState: currentUser
      ? { uid: currentUser.uid, email: currentUser.email, isAnonymous: currentUser.isAnonymous }
      : 'unauthenticated',
    uploadPath: storagePath,
    fileSize: fileToUpload.size,
    mimeType: fileToUpload.type || 'unknown',
  });

  reportProgress(10);

  // Ensure dataUrlForFallback is prepared for server upload payload
  if (!dataUrlForFallback && fileToUpload) {
    try {
      dataUrlForFallback = await fileToDataURL(fileToUpload);
    } catch (e) {
      console.warn('[STORAGE_DATA_URL_CONVERT_WARN]', e);
    }
  }

  // Attempt 1: ImageKit Upload (if configured)
  try {
    console.log(`[STORAGE_UPLOAD_IK_ATTEMPT] Trying ImageKit upload for ${targetSubFolder}...`);
    const ikResult = await uploadToImageKit(fileToUpload, targetSubFolder, cleanDocId, reportProgress);
    if (ikResult && ikResult.url) {
      console.log(`[STORAGE_UPLOAD_IK_SUCCESS] Path: ${ikResult.filePath || ikResult.fileId} -> URL: ${ikResult.url}`);
      return {
        url: ikResult.url,
        storagePath: ikResult.filePath || ikResult.fileId || ikResult.url,
        fileId: ikResult.fileId || ikResult.url,
      };
    }
  } catch (ikErr: any) {
    console.warn('[STORAGE_UPLOAD_IK_NOTICE] ImageKit upload skipped/unavailable:', ikErr?.message || ikErr);
  }

  // Attempt 2: Server Storage Endpoint (/api/upload)
  try {
    console.log(`[STORAGE_UPLOAD_SERVER_ATTEMPT] Attempting server upload for ${targetSubFolder}...`);
    reportProgress(40);

    const uploadEndpoint = typeof window !== 'undefined' ? '/api/upload' : 'http://localhost:3000/api/upload';
    
    let lastServerError: any = null;
    let serverSuccessResult: any = null;

    // Bounded retries: Max 3 retries with backoff for transient network issues
    for (let attempt = 1; attempt <= 3; attempt++) {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 12000); // 12s timeout

      try {
        const response = await fetch(uploadEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            image: dataUrlForFallback,
            folder: targetSubFolder,
            docId: cleanDocId,
          }),
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (response.ok) {
          const resData = await response.json();
          if (resData && resData.url) {
            serverSuccessResult = resData;
            break;
          }
        } else {
          lastServerError = new Error(`Server returned HTTP ${response.status}`);
          // Do not retry 4xx errors
          if (response.status >= 400 && response.status < 500) {
            console.warn(`[SERVER_UPLOAD_4XX_STOP] Non-retryable HTTP ${response.status} from server endpoint.`);
            break;
          }
        }
      } catch (fetchErr: any) {
        clearTimeout(timeoutId);
        lastServerError = fetchErr;
        console.warn(`[SERVER_UPLOAD_ATTEMPT_${attempt}_WARN] Request failed:`, fetchErr?.message || fetchErr);
      }

      if (attempt < 3) {
        await new Promise((r) => setTimeout(r, attempt * 500));
      }
    }

    if (serverSuccessResult) {
      reportProgress(100);
      console.log(`[SERVER_UPLOAD_SUCCESS] Path: ${serverSuccessResult.storagePath} -> URL: ${serverSuccessResult.url}`);
      return {
        url: serverSuccessResult.url,
        storagePath: serverSuccessResult.storagePath || storagePath,
        fileId: serverSuccessResult.fileId || storagePath,
      };
    }
    console.warn(`[SERVER_UPLOAD_NOTICE] Server endpoint did not succeed (${lastServerError?.message || 'unknown'}). Attempting Firebase Storage...`);
  } catch (serverErr: any) {
    console.warn('[SERVER_UPLOAD_NOTICE] Server storage unavailable, attempting Firebase Storage:', serverErr?.message || serverErr);
  }

  // Attempt 3: Firebase Storage Upload (uploadBytesResumable)
  return new Promise<UploadResult>((resolve, reject) => {
    let isSettled = false;
    let storageTimeoutTimer: any = null;

    const handleUploadError = (reason: string, errObj?: any) => {
      if (isSettled) return;
      isSettled = true;
      if (storageTimeoutTimer) clearTimeout(storageTimeoutTimer);

      const formattedErr = formatStorageError(errObj || reason);
      console.error(`[STORAGE_UPLOAD_ERROR] Path: ${storagePath} | Error: ${formattedErr}`, errObj);
      reject(new Error(`Image upload failed: ${formattedErr}`));
    };

    // Safety timeout: 15s limit for Firebase Storage task to prevent hanging
    storageTimeoutTimer = setTimeout(() => {
      if (!isSettled) {
        console.warn('[STORAGE_TIMEOUT] Firebase Storage task timed out after 15s.');
        handleUploadError('Firebase Storage operation timed out after 15 seconds.');
      }
    }, 15000);

    try {
      const storageRef = ref(storage, storagePath);
      const uploadTask = uploadBytesResumable(storageRef, fileToUpload, {
        contentType: fileToUpload.type || 'image/png',
      });

      uploadTask.on(
        'state_changed',
        (snapshot) => {
          if (!isSettled) {
            console.log(`[STORAGE_UPLOAD_STATE] Path: ${storagePath} | State: ${snapshot.state} | Bytes: ${snapshot.bytesTransferred}/${snapshot.totalBytes}`);
            if (snapshot.totalBytes > 0) {
              const rawPct = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
              if (!isNaN(rawPct) && rawPct >= 0 && rawPct <= 100) {
                const scaledPct = 40 + Math.round((rawPct * 60) / 100);
                reportProgress(scaledPct);
              }
            }
          }
        },
        (error: any) => {
          console.error('[STORAGE_UPLOAD_TASK_ERROR] Task error received:', error);
          handleUploadError(`Firebase Storage error (${error?.code || 'unknown'}): ${error?.message}`, error);
        },
        async () => {
          if (isSettled) return;
          if (storageTimeoutTimer) clearTimeout(storageTimeoutTimer);

          try {
            const currentSnapshot = uploadTask.snapshot;
            console.log(`[STORAGE_UPLOAD_COMPLETE] Upload state: ${currentSnapshot.state}. Fetching download URL...`);

            const downloadUrl = await getDownloadURL(currentSnapshot.ref);

            if (!downloadUrl) {
              handleUploadError('Received empty download URL from Firebase Storage');
              return;
            }

            isSettled = true;
            reportProgress(100);
            console.log(`[STORAGE_UPLOAD_SUCCESS] Path: ${storagePath} -> URL: ${downloadUrl}`);

            resolve({
              url: downloadUrl,
              storagePath: storagePath,
              fileId: storagePath,
            });
          } catch (completeErr: any) {
            console.error('[STORAGE_COMPLETE_HANDLER_ERROR]', completeErr);
            handleUploadError('Error retrieving download URL after upload completion', completeErr);
          }
        }
      );
    } catch (initErr: any) {
      console.error('[STORAGE_INIT_ERROR]', initErr);
      handleUploadError('Failed to initialize Firebase Storage upload task', initErr);
    }
  });
}

/**
 * Helper to extract Firebase Storage path from download URL or return storagePath.
 */
function extractPathFromUrl(url?: string): string | undefined {
  if (!url) return undefined;
  if (url.includes('firebasestorage.googleapis.com')) {
    try {
      const decodedUrl = decodeURIComponent(url);
      const match = decodedUrl.match(/\/o\/([^?]+)/);
      if (match && match[1]) {
        return match[1];
      }
    } catch (e) {
      // ignore
    }
  }
  if (!url.startsWith('http://') && !url.startsWith('https://') && !url.startsWith('data:')) {
    return url;
  }
  return undefined;
}

/**
 * Deletes an image file from Firebase Storage given its storagePath or full URL.
 */
export async function deleteStorageImage(storagePath?: string, imageUrl?: string): Promise<boolean> {
  const pathToDelete = storagePath || extractPathFromUrl(imageUrl);
  if (!pathToDelete) return false;

  try {
    const imageRef = ref(storage, pathToDelete);
    await deleteObject(imageRef);
    console.log(`[FIREBASE_STORAGE_DELETE_SUCCESS] Deleted ${pathToDelete}`);
    return true;
  } catch (err: any) {
    console.warn(`[FIREBASE_STORAGE_DELETE_NOTICE] ${pathToDelete}:`, err?.message || err);
    return false;
  }
}
